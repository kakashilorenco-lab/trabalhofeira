# Direção final — Macaé, uma história em movimento

Revisão concluída em 21/10/2026. Esta documentação descreve o refinamento do projeto existente; os relatórios em `docs/refinement`, `docs/brief` e `docs/acervo/upload` registram versões anteriores.

## Resultado e limites

Os sete temas, 12 imagens distintas, fontes e condições de uso foram preservados. São 15 posições de exibição, incluindo documentos reutilizados em temas relacionados. A fotografia ausente da estação em 1978 permanece no catálogo e no painel S, sem interromper a sessão com uma tela vazia. Não foi substituída pela fotografia de 1917. Não houve nova pesquisa histórica nem alteração das datas nesta revisão.

O ciclo automático gravado, sem teclado ou aceleração, durou **80,25 segundos**, percorreu abertura, sete temas, encerramento e retorno à abertura, sem erros de JavaScript ou requisições externas. O alvo nominal do controlador é 79,65 segundos; carregamento inicial e quantização dos quadros explicam a diferença. A gravação é `final/complete-normal-speed.mp4`; os 556 quadros capturados e estados estão documentados em `final/cycle-results.json`.

Não houve teste em televisão física nem ensaio de várias horas. As fotografias pequenas de 1978 e do pátio mantêm sua resolução legítima: em 4K ocupam uma área relativamente menor. Arquivos originais melhores, com a mesma verificação de procedência, continuam sendo a principal oportunidade de melhoria. As datas provisórias e as autorizações declaradas pelo usuário continuam identificadas no painel S e na documentação do acervo.

## Auditoria e três rodadas reais

Antes de editar, foi criado `/workspace/backups/macae-before-creative-refinement-20261020.tar.gz`. A leitura do backup e a comparação byte a byte dos 16 arquivos de catálogo e mídia constam em `preservation.json`. Não foram alterados os pixels das imagens históricas.

1. **Direção de arte e tipografia.** Capturas anteriores em `../visual-review/creative-baseline`; primeira revisão em `../visual-review/creative-pass-1`. Problemas observados: títulos pouco presentes, itálico aplicado mecanicamente, molduras com muita sobra vertical e cabeçalho repetindo o título da abertura. Foram ampliados os títulos, compostas quebras específicas para vila e ferrovia, destacados anos curtos e ajustadas proporções de mídia por capítulo. A abertura cresceu e perdeu a identificação repetida. Fotografias permanecem inteiras, sem cortes de informação.
2. **Movimento.** Capturas em `../visual-review/creative-pass-2` e quadros de transição em `pass-2`. O relógio da apresentação passou a dirigir também a revelação tipográfica e o pulso do marco. A faísca interpola a geometria entre amostras, evitando passos visíveis. A curva de viagem reserva mais tempo à desaceleração. Névoa e partículas diminuem nas pausas. O rasgo ganhou uma faixa da própria fotografia curvada na borda, espessura, fibras e sombra de contato. A observação passou a 3,3 s por imagem, com 3,8 s para o capítulo de imagem única. A captura 4K desta rodada foi feita antes de a câmera concluir o redimensionamento e saiu vazia; a ferramenta foi corrigida para aguardar a posição real, sem tratar esse arquivo como uma validação aprovada.
3. **Polimento e confiabilidade.** Capturas em `../visual-review/creative-pass-3` e `pass-3`. Foi identificado que a legenda nova aparecia enquanto a foto anterior ainda predominava no rasgo: agora a legenda fica oculta durante a troca e retorna com a imagem estabilizada. O marcador só acende ao chegar; o cabeçalho desaparece durante a viagem para não se sobrepor ao conteúdo que cruza a borda. O grupo de fotos do petróleo foi aproximado da linha. Escritas repetidas de estilo em quadros estáticos foram eliminadas. Todas as mídias são decodificadas antes do relógio começar; falhas usam o fallback nomeado, sem bloquear a sessão. A revisão final inclui nove cenas, rasgo em 12/50/88/100%, viagem, chegada e SENAI em 4K.

As nove telas foram inspecionadas também em montagem reduzida, `overview.jpg`, para avaliar leitura à distância. Os quadros temporizados do filme foram inspecionados para continuidade e ritmo; isso não equivale a um teste de percepção numa TV real.

## Autoavaliação crítica

Notas subjetivas de revisão visual, não avaliações independentes nem medidas instrumentais. As limitações não desapareceram por o código passar nos testes.

| Critério | Rodada 1 | Rodada 2 | Rodada 3 | Observação |
| --- | ---: | ---: | ---: | --- |
| Direção de arte | 7,8 | 8,0 | 8,0 | Linguagem coerente; estrutura editorial deliberadamente contida |
| Tipografia | 8,0 | 8,2 | 8,2 | Títulos mais claros; créditos exigem aproximação em fotos pequenas |
| Composição | 7,5 | 7,6 | 7,9 | Petróleo melhor posicionado; limitação nativa ainda evidente |
| Movimento | 7,0 | 8,0 | 8,1 | Chegadas e pausas coordenadas; viagem conserva a geometria original |
| Linha congelada | 7,0 | 7,6 | 7,7 | Núcleo definido; névoa intencionalmente muito discreta |
| Rasgo | 6,8 | 7,6 | 7,7 | Dobra e fibras visíveis; continua uma aproximação gráfica, não simulação física |
| Apresentação histórica | 8,0 | 8,0 | 8,4 | Correção das legendas durante a troca; pendências continuam explícitas |
| Minimalismo | 8,0 | 8,3 | 8,4 | Sem paginação e sem tela de arquivo ausente na sequência normal |
| Confiabilidade técnica | 8,0 | 8,2 | 8,5 | Um relógio, pausa coerente, predecode, validação automática e offline |
| Impacto geral | 7,6 | 8,0 | 8,1 | Refinamento consistente, sem prometer a qualidade de acervos inexistentes |

## Sistema visual editável

`src/exhibition.css` concentra a direção final sobre os estilos existentes. Fundo `#171411`, texto `#f2e9da`, datas `#d6c3a4`, linha branca fria. Cormorant Garamond 500 nos títulos e Manrope no restante; apenas duas famílias, licenciadas em OFL e incorporadas ao HTML. Título de evento de referência: 105,6 px em 1080p; data regular: 34,6 px; ano isolado: 65,3 px. Legendas: aproximadamente 20 px. Os tamanhos crescem para 4K.

Os títulos e quebras estão em `src/data/presentation.ts`; o texto de pesquisa completo continua em `src/data/events.ts`. As imagens vêm de `data/image-sources.json`, a ordem de `mediaIds` e a seleção em `src/data/media.ts`. Para substituir um arquivo, siga `docs/media-guide.md` e preserve procedência, dimensões e direitos. Nunca renomeie uma fotografia de 1917 para simular 1978.

O arquivo `src/motion/config.ts` controla pausas, viagem, densidade e rasgo. `IMAGE_HOLD_DURATION = 3300`, `SECTION_HOLD_DURATION = 3800`, `PAPER_TEAR_DURATION = 1200`. A viagem mantém 3400 / 2,8 ms, com rampas de aceleração 0,18 e desaceleração 0,48. `Presentation.loop` começa em `true`; o controlador inicia automaticamente depois de decodificar as mídias. Não há áudio nem dependência de autoplay de vídeo. Em `prefers-reduced-motion`, partículas e rasgo são desativados.

## Validação executada

- `npm test`: **14 testes passaram**, em 44,8 s. Inclui autoplay sem interação, três imagens dos pescadores, pausas, rasgo real em camadas, congelamento e limpeza da dobra, legendas, teclado, fullscreen, três ciclos acelerados, recursos locais, fontes e direitos, fallback de erro e geometria dos sete temas em 1080p e 4K.
- A primeira execução registrou uma falha no teste de teclado: ele pressionava Espaço antes de o React instalar o listener. O teste passou a aguardar a inicialização real e confirmar o estado EM PAUSA. Nenhuma asserção funcional foi removida. A execução completa posterior passou.
- Ciclo gravado a velocidade normal: 80,25 s, ordem `0,1,2,3,4,5,6,7,8,0`, zero erros e zero requisições externas.
- Produção e exportação offline: aprovadas; 17 links de créditos, fontes e imagens incorporadas, fullscreen e loop, zero erros e zero solicitações externas. Resultados em `final/validation-results.json`.
- Desempenho: 59,5 fps médios em 8,2 s; mediana e percentil 95 de 16,7 ms, pior quadro de 50,1 ms. Após 12 ciclos acelerados, DOM permaneceu em 465 elementos e os ouvintes em 7; heap após coleta variou de 7.199.148 para 7.566.356 bytes. Não foi observado acúmulo de elementos/ouvintes; essa amostra não demonstra ausência absoluta de vazamento. Os resultados estão em `final/performance-results.json`. O ensaio acelerado verifica crescimento de DOM, ouvintes e heap; não substitui um ensaio contínuo de várias horas.

## Abrir e entregar

Execute `npm run export` para gerar `exports/macae-exposicao-final.html` (e o nome compatível `macae-exposicao.html`). Extraia o pacote de TV, abra o HTML no Chrome ou Edge e pressione **F**. **Espaço** pausa, **←/→** navegam, **R** reinicia, **H** abre controles e **S** abre fontes. Para editar: `npm ci`, `npm run dev` e depois novo export.

O navegador gerenciado bloqueia a navegação direta `file://`. O ensaio offline usa os bytes exatos exportados num documento com rede desabilitada, verifica fontes, imagens, fullscreen e loop. A abertura por duplo clique deve ser conferida no computador da TV. A prévia animada do ChatGPT permanece indisponível neste ambiente.

Esta revisão não foi publicada. A instrução de não publicar automaticamente prevalece sobre a autorização anterior, que dizia respeito ao pacote da edição anterior. Os arquivos locais são reais; links locais não são apresentados como anexos para download.
