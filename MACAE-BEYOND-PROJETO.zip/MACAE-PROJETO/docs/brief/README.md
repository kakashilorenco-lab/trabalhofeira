# Macaé — Uma história em imagens

Refinamento breve sobre o projeto existente, em 19/10/2026. A aplicação foi reduzida a período, acontecimento, mídia e créditos. Os parágrafos foram retirados do DOM da apresentação principal, não escondidos com letras menores ou CSS.

## Resultado atual

- Abertura: **MACAÉ** e **UMA HISTÓRIA EM IMAGENS**, durante quatro segundos.
- Sete temas na mesma ordem, com nomes diretos conforme o briefing.
- Sem descrições, notas de pesquisa, capítulos auxiliares, textos dentro das composições, barra de progresso ou blocos introdutórios na exibição normal.
- Área de mídia de 44,25% da largura da tela: cerca de 850 px em 1080p, ante 725 px na versão anterior. A largura e a altura aumentaram aproximadamente 17%; a área, aproximadamente 37%.
- Datas e títulos grandes, layouts alternados e fundo escuro. A paleta global, as duas famílias tipográficas, a geometria da timeline e os efeitos de gelo foram mantidos.
- Papel rasgado preservado, com contemplação de três segundos entre itens de uma sequência. A mídia continua preparada para receber registros reais, sem alterar suas cores ou conteúdo.
- Encerramento: somente **MACAÉ**, por 3,5 segundos, seguido do reinício suave.
- Controles de manutenção e pesquisa continuam em H e S; Espaço, setas, F e R permanecem disponíveis.

## Conteúdo exibido

| Período | Acontecimento |
| --- | --- |
| Séculos XVII–XVIII | Vila dos Pescadores |
| 29 de julho de 1813 | Criação da Vila São João de Macaé |
| Nenhuma data exibida | Macaé se torna cidade |
| 1844–1875 | Porto da Imbetiba |
| 1875 | Chegada da ferrovia — Vila da Imbetiba |
| 1978–1980 | Macaé, cidade do petróleo |
| 1995–2008 | SESI / SENAI em Macaé |

Os períodos são os fornecidos no briefing, não uma nova verificação documental. A elevação à cidade não recebe ano nem o enquadramento anterior “século XIX”, porque a data não foi confirmada. Os detalhes sobre 1995/1996, construção, inauguração e expansão do SESI/SENAI permanecem nos dados e na pesquisa. O período do petróleo não é identificado como fundação da Petrobras.

## Dados e fontes preservados

`src/data/events.ts`, `data/image-sources.json` e a documentação histórica continuam preservados. Os nomes/períodos da exibição ficam separados em `src/data/presentation.ts`. Descrições, ressalvas e referências de duração do roteiro longo não foram apagadas; apenas deixaram de controlar o que aparece na TV.

Hashes SHA-256 inalterados dos arquivos preservados:

```text
src/data/events.ts
9da176d87e0033477af4d4ff7e343b56565d66969e25341ce4774c582e3d5ca4

data/image-sources.json
37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570
```

**Acervo ainda pendente:** não há fotografias, mapas ou documentos autenticados no catálogo. As áreas de mídia usam gráficos contemporâneos explicitamente identificados, sem parágrafos ou alegação documental. As três variações do primeiro marco são gráficos, não fotografias dos séculos XVII/XVIII. Nenhuma imagem de IA foi usada. A aplicação não deve ser apresentada como versão final de curadoria histórica verificada.

## Temporização

| Etapa | Duração configurada |
| --- | --- |
| Abertura | 4 s |
| Deslocamento | Aproximadamente 1,42 s por viagem |
| Retomada | 0,18 s |
| Primeiro marco | 3 × 3 s + 2 × 1,2 s de rasgo = 11,4 s |
| Outros seis marcos | 6 s cada |
| Encerramento | 3,5 s |
| Cortina de reinício | 1,4 s |
| Ciclo nominal total | 69,1 s |
| **Ciclo real medido** | **69,412 s** |

O deslocamento ficou um pouco mais rápido que os 1,7 s da versão anterior. O rasgo continua com 1,2 s e compartilha o relógio principal; nenhuma temporização concorrente foi criada. O ciclo real inclui pequenos arredondamentos de frames nas transições.

## Validação executada

`npm run build` passou. `npm test`: **10 testes aprovados, 0 falhas, 0 ignorados**, em aproximadamente 41 segundos. A suíte confirma ordem, orçamento de 60–90 s, duração de três segundos nas sequências, pausa no rasgo, camadas sobrepostas, limpeza de máscara, movimento reduzido, teclado/fullscreen, múltiplos loops e geometria em 1080p/4K.

Depois da exportação final, os testes de produção e do conteúdo HTML autossuficiente também passaram: loop automático, fontes locais, fullscreen e zero requisições externas ou erros de navegador. O teste offline renderiza os bytes exportados por `setContent`; a abertura direta via `file://` permanece bloqueada pela política do Chromium gerenciado desta máquina, conforme documentado na validação anterior.

Um teste específico da exibição verifica a ausência dos antigos parágrafos e subtítulos, o limite de 24 palavras por marco incluindo crédito, somente data/título no bloco de texto, área de mídia ampliada e ausência da data não confirmada da cidade.

Além dos testes acelerados, `node tests/brief-cycle.mjs` registrou **um ciclo integral em 1920 × 1080, velocidade normal, sem interação, sem `seek`, sem pausa e sem parâmetro de aceleração**. A sequência observada foi `0,1,2,3,4,5,6,7,8,0`, com 46 mudanças de estado e duração de 69,412 s. Zero exceções JavaScript e zero solicitações externas. Foram capturados 491 frames reais do Chromium e preservados seus tempos na codificação do vídeo; a taxa de amostragem da gravação não deve ser confundida com o FPS de renderização.

A revisão inspecionou as nove cenas extraídas da gravação completa e uma sequência de frames do rasgo. As telas têm somente nome, período e mídia com crédito, sem aparência de artigo dividido em seções. Não houve cortes nas caixas dos elementos em 1080p; a suíte também verificou o layout em 4K. O primeiro ensaio de screenshots ocorreu antes de o servidor de desenvolvimento subir e retornou conexão recusada; o servidor foi iniciado e as nove capturas foram executadas com sucesso. Esse erro de preparação não foi contado como validação visual.

## Evidências

- [Gravação integral em velocidade normal](complete-normal-speed.mp4).
- [Prancha das nove telas reais](overview.jpg).
- [Frames do papel rasgado na gravação](paper-frames.jpg).
- [Medição e histórico de estados](cycle-results.json).
- Exemplos individuais: [pescadores](01-pescadores.jpg), [vila](02-vila.jpg), [cidade sem data](03-cidade.jpg), [ferrovia](05-ferrovia.jpg), [petróleo](06-petroleo.jpg).
- Capturas adicionais da inspeção pausada: `docs/visual-review/brief-round-1/`.

## Editar e reproduzir

Os textos curtos ficam em `displayCopy`, no arquivo `src/data/presentation.ts`. `period: null` omite a data. Não preencha a data da cidade sem comprovação. Mantenha textos completos, fontes e ressalvas em `src/data/events.ts` e `docs/historical-sources.md`.

Os tempos ficam em `src/motion/config.ts`: `INTRO_DURATION`, `OUTRO_DURATION`, `SECTION_HOLD_DURATION`, `IMAGE_HOLD_DURATION`, `RESUME_DURATION` e `SCROLL_SPEED_MULTIPLIER`. `nominalCycleDuration` calcula o orçamento total, e a suíte exige que ele permaneça entre 60 e 90 segundos. Se o acervo ganhar registros adicionais, o número de itens pode aumentar a duração; revise o orçamento sem reduzir a contemplação abaixo do necessário.

```bash
cd /workspace/trabalhofeira
npm run dev -- --port 5173
# Em outro terminal:
npm test
node tests/capture.mjs brief-round-1
node tests/brief-cycle.mjs
npm run export
```

O comando de gravação precisa de Chromium e FFmpeg. `exports/macae-exposicao.html` é a versão autossuficiente para transferir ao computador da TV. A pesquisa do acervo e o teste físico na televisão permanecem pendentes. Os relatórios das versões anteriores foram mantidos em `docs/refinement/` e `docs/validation.md`; seus tempos antigos não descrevem esta versão breve.
