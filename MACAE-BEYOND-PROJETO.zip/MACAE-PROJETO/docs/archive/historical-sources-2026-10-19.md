# Pesquisa histórica — situação documental

Data da tentativa: **19 de outubro de 2026**. Escopo: os sete temas fornecidos no roteiro de “Macaé — Uma história em movimento”.

## O que foi efetivamente consultado

O roteiro fornecido pelo solicitante foi a única fonte textual acessível para a narrativa desta edição. Não foi possível ler as fontes externas abaixo: o proxy retornou **403 Forbidden ao estabelecer o túnel HTTPS**. Não se trata de uma resposta editorial dos acervos nem de evidência de inexistência dos materiais.

Estes links são **endereços de consulta tentados**, não referências lidas ou verificadas:

| Instituição / destino | Endereço tentado | Resultado |
| --- | --- | --- |
| IBGE Cidades — histórico de Macaé | https://cidades.ibge.gov.br/brasil/rj/macae/historico | Túnel HTTPS bloqueado, 403 |
| Biblioteca do IBGE — endereço de monografia municipal a conferir | https://biblioteca.ibge.gov.br/visualizacao/dtbs/riodejaneiro/macae.pdf | Túnel HTTPS bloqueado, 403; existência e conteúdo do arquivo não confirmados |
| Prefeitura de Macaé — endereço de página de história a conferir | https://www.macae.rj.gov.br/conteudo/leitura/titulo/historia | Túnel HTTPS bloqueado, 403; título e conteúdo não lidos |
| Wikimedia Commons — API, busca de arquivos por “Macae” | https://commons.wikimedia.org/w/api.php | Túnel HTTPS bloqueado, 403; nenhum resultado ou licença obtido |

As consultas foram repetidas após salvar a necessidade de acesso no rascunho do ambiente. O bloqueio persistiu. Nenhum conteúdo retornado por essas fontes foi usado como comprovação. Os endereços não devem ser citados como documentos consultados em uma publicação final sem nova pesquisa.

## Relatório das datas

**Datas verificadas documentalmente nesta sessão: nenhuma.** Não há correção silenciosa do roteiro. Os anos fornecidos foram conservados com ressalvas visíveis. A ordem narrativa solicitada também foi preservada; ela não equivale a uma cronologia rigorosamente validada, especialmente quando os intervalos de porto e ferrovia se sobrepõem.

| Tema obrigatório | Informação do roteiro | Tratamento nesta edição | Pesquisa necessária |
| --- | --- | --- | --- |
| Vila dos Pescadores | Séculos XVII e XVIII | Período provisório; três leituras tipográficas contemporâneas | Verificar a denominação “vila dos pescadores”, ocupações indígenas, atividades pesqueiras, espacialidade e períodos. Não reduzir a formação do território a uma origem única. |
| Criação da Vila São João de Macaé | 29/07/1813 | Data fornecida, identificada como pendente de confirmação | Localizar ato administrativo, denominação oficial e território abrangido. |
| Macaé se torna cidade | Data não fornecida | “Século XIX” como enquadramento editorial; **nenhuma data exata atribuída** | Conferir a data, número e texto do ato legal no IBGE e em fontes primárias. Substituir o enquadramento editorial pela data comprovada. |
| Porto da Imbetiba | 1844 / 1875 | Anos de referência do roteiro, sem associá-los a uma inauguração | Identificar a que se refere cada ano: instalações, companhia, operação, obras ou conexões de transporte. Não afirmar que o porto foi inaugurado em ambos os anos. |
| Ferrovia / Vila da Imbetiba | 1875 | Ano de referência, com ressalva | Distinguir companhia, abertura de trechos, estação, conexão portuária e formação da vila; verificar a ordem em relação ao porto. |
| Petrobras e Macaé | 1978 / 1980 | Recorte proposto de expansão local; explicitamente **não é a fundação da empresa** | Identificar marcos operacionais locais e da Bacia de Campos. Conferir implantação de bases, produção e infraestrutura, sem equiparar descoberta, produção e instalação em Macaé. |
| Construção e expansão SESI/SENAI | 1995 / 1996 – 2008 | Anos provisórios, sem designar inauguração ou unidade | Solicitar cronologia oficial à Firjan, identificar endereço/unidade e distinguir construção, inauguração e ampliação. |

Os textos principais são sínteses editoriais do roteiro. As frases de abertura e encerramento são criação editorial deste projeto, sem atribuição a personagem histórico. “Um território. Muitas histórias.” e “Uma cidade nunca deixa de acontecer.” não são citações de acervo.

## Divergências e decisões

- A data de elevação à cidade não foi preenchida por memória ou suposição. A consulta documental é necessária antes de publicar.
- 1844, 1875, 1978, 1980, 1995, 1996 e 2008 não foram transformados em datas de inauguração sem evidência.
- A distinção entre fundação da Petrobras e expansão petrolífera local está explícita na tela.
- “Vila dos Pescadores” permanece como tema do roteiro, sem inventar ato de fundação, sequência anual ou imagens dos séculos XVII e XVIII.
- Não há três fotografias históricas nessa etapa. Há três leituras editoriais sobre território, água e memória, sem alegação documental.
- Não foi possível identificar um conflito comprovado entre duas fontes externas, pois nenhuma delas pôde ser lida. O status correto é **pendência**, não “divergência resolvida”.

## Próximas fontes a investigar

Priorizar IBGE, Prefeitura de Macaé, Arquivo Nacional, Biblioteca Nacional/Hemeroteca, instituições locais de patrimônio, memória institucional da Petrobras e Firjan/SESI/SENAI. Estes são **alvos de pesquisa**, não fontes utilizadas nesta edição. Não foram inventados títulos de documentos, números de leis ou URLs de itens de acervo.

Para cada afirmação validada, registrar instituição, título exato, autoria quando identificada, data do documento, URL permanente, trecho que comprova a afirmação e data de acesso. Para materiais visuais, a ficha histórica não substitui a verificação da licença de reprodução.

## Desbloquear e continuar

O rascunho da configuração do ambiente inclui os domínios de IBGE, Prefeitura, Commons, Biblioteca Nacional, Petrobras e Firjan para pesquisa. A atualização do rascunho não aplica a rede à máquina atual. Revise e salve nas configurações do ambiente; publique o ambiente quando indicado pelo produto. Após a aplicação, repetir primeiro as consultas bloqueadas, validar os documentos, atualizar esta tabela e só então alterar as ressalvas nos dados.

Até essa etapa, a implementação está disponível para desenvolvimento e ensaio audiovisual; **a curadoria histórica e o acervo permanecem incompletos**.
