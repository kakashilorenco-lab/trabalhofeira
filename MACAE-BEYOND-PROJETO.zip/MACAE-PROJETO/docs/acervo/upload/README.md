# Recebimento das imagens — versão atual

Atualização de **20/10/2026**, após o envio de `Imagens Trabalho Feira.zip`. Foram recebidos **11 arquivos**, todos identificados e associados aos capítulos. O catálogo passou de quatro para **12 registros distintos**, incluindo o atlas já existente. Apenas a **Estação Ferroviária de Macaé de 1978** continua ausente.

## Associação dos arquivos recebidos

| Arquivo do ZIP | Associação | Tratamento |
| --- | --- | --- |
| `Antiga avenida feliciano Sodré.png` | Cidade · Rua Presidente Sodré, meados do século XX | Mesma cena do Arquivo Nacional. Preservada a versão já incorporada de melhor resolução, sem substituir por cópia menor. |
| `Antiga Margem do Rio Macaé.png` | Pescadores e cidade | Reprodução visualmente correspondente ao ClimaOnline. Ano e fotógrafo não identificados; **não atribuir ao IBGE**. Na primeira seção, legenda informa que é posterior aos séculos XVII–XVIII. |
| `Estação ferroviaria de Macaé.jpg` | Ferrovia · **1917** | Identificada pela fotografia e legenda da página Macaé Tips. Obtida a reprodução maior de 1000 × 695 dessa mesma página. Não associada a 1978 por adivinhação. |
| `Firjan Senai sesi.jpg` | SESI/SENAI | SHA-256 idêntico ao arquivo municipal consultado anteriormente. Reduzido proporcionalmente de 5184 × 3456 para 2560 × 1707. Legenda conserva 2015 como data informada e indica registro posterior. |
| `Obra Petrobras.png` | Petróleo · obras de instalação | Inscrição visível: novembro de 1978. Fotógrafo não identificado; compilação atribuída a Izio Enco no roteiro. |
| `Patio ferroviario.jpg` | Ferrovia · pátio | SHA-256 idêntico à reprodução do Macaé Tips. A página diz **possivelmente anos 1960**, autor desconhecido, cessão João Silva; a incerteza permanece na legenda. |
| `Petrobras 1978.png` | Petróleo · instalações | Inscrição 1978 preservada; sem atribuir a foto ao compilador como se ele fosse o fotógrafo. |
| `Planta canal camposmacae.jpg` | Vila e porto · mapa de 1846 | SHA-256 idêntico ao original BnF/Commons já verificado. Preservada a versão local de 2560 × 1728, com quadro integral. |
| `Planta da cidade de Macaé.png` | Pescadores e vila | Correspondência visual com a reprodução da Prefeitura, atribuída a BNRJ / Solar dos Mellos. Sem inventar ano de produção; legenda indica data não confirmada e registro posterior. |
| `Praia de Imbetiba.jpg` | Porto · **1941** | SHA-256 idêntico ao original Commons já conferido. Mantidos crédito a Aristides Henriques de Oliveira / Halleypo e CC BY-SA 3.0, com indicação de registro posterior. |
| `Primeira Guarita.png` | Petróleo · Imbetiba | Inscrição: dezembro de 1978. Correspondência visual com a referência fornecida do Slideshare. |

Os originais recebidos estão preservados fora da pasta pública, em `/workspace/shared/downloads/imagens-macae-enviadas`. [inventory.json](inventory.json) registra nomes, dimensões, hashes e a destinação de cada um; [receipt.json](receipt.json) registra o ZIP. [matching-results.json](matching-results.json) contém as 11 correspondências do inventário, reconhecidas pelos hashes dos arquivos conferidos.

O atlas de 1767 não veio no ZIP, mas já estava incorporado. A estação de 1978 também não veio: seu espaço continua identificado pelo nome, sem repetir a imagem de 1917 com outra data. São 16 posições ao longo dos capítulos, com reutilização contextual de alguns documentos; não são 16 imagens distintas.

## Autorização de uso e créditos

O usuário respondeu à pergunta sobre Petrobras, pátio e SENAI:

> “tenho sim, autorizado pelo macaetips que tem parceria com senai”

Em seguida, confirmou explicitamente que a autorização também inclui a planta da cidade e a margem do rio:

> “Inclui também as duas imagens”

A declaração, o contexto e os sete identificadores abrangidos estão em [`data/permissions.json`](../../../data/permissions.json). A parceria foi **informada pelo responsável**, não verificada independentemente. A autorização foi registrada para o uso nesta apresentação; não foi inventada uma licença Creative Commons, uma página pública de licença ou uma autorização geral para terceiros.

O catálogo diferencia:

- **Cinco registros com condição consultada em fonte pública:** os quatro anteriores e a estação de 1917, cuja fotografia antiga é de domínio público pela data de publicação indicada na fonte secundária. A edição original da Fon-Fon não foi consultada; isso permanece documentado.
- **Sete registros com autorização declarada pelo responsável:** planta, margem do rio, pátio, três fotos da Petrobras e SENAI. Usam `rightsVerification: "user-declaration"`, `permissionId` e `licenseUrl: null`. O campo `verified` não significa verificação independente dessa autorização.

Créditos compactos ficam nas legendas; autoria, fonte, data, condição de uso e distinção da autorização ficam no painel **S**. As fichas editáveis estão em [`data/image-sources.json`](../../../data/image-sources.json) e os candidatos em [`data/image-candidates.json`](../../../data/image-candidates.json). A licença da Praia de Imbetiba permanece CC BY-SA 3.0; preserve sua atribuição e condições ao reutilizar a fotografia.

## Conferência histórica e procedência

A página [Estação Ferroviária de Macaé, Macaé Tips](https://macaetips.com/places/estacao-ferroviaria-de-macae/) respondeu 200 nesta etapa. Sua legenda identifica a fotografia da multidão como **1917**, citando “Fon-fon, 6/9/1917”; o pátio é descrito como “possivelmente anos 1960”, autor desconhecido, cessão João Silva. A página e o texto consultado foram preservados nesta pasta.

Essa mesma página cita estação em **1873** e primeiro trecho em **1874**, divergindo da referência de **1875** do roteiro. O capítulo preserva o ano solicitado, mas a divergência foi registrada nos dados de pesquisa e no painel S; não apresentamos uma inauguração em 1875 como comprovada. É necessária conferência em fonte primária antes de encerrar a pesquisa cronológica.

As referências visuais do ClimaOnline e dos três arquivos do Slideshare também ficaram acessíveis. A comparação permite identificar os materiais, mas não confirma autoria ou licença por si só. A atribuição ao IBGE não foi adotada. O mapa da cidade continua sem ano confirmado. As datas de 1978 nas fotos da Petrobras são inscrições das reproduções, sem confusão com a fundação da empresa. A fachada de 2015 não é apresentada como fotografia da construção de 1995/1996.

A página municipal continua sendo a confirmação institucional para 29/07/1813 e para o ano de elevação à cidade, 1846. As demais ressalvas estão em [historical-sources.md](../../historical-sources.md).

## Qualidade e revisão visual

Nenhum registro foi gerado, reconstruído, colorizado ou ampliado por IA. Os arquivos foram preservados ou convertidos/reduzidos proporcionalmente, sem filtro sépia e sem corte essencial. O [registro de processamento](../processing.json) inclui hashes, dimensões e arquivo local.

As fotos da Petrobras têm apenas 476–487 px de largura; o pátio, 450 px. Elas são exibidas dentro de seus limites nativos. A moldura do capítulo do petróleo foi compactada para reduzir o espaço vazio sem esticar as fotografias. Essa moldura mantém dimensões constantes durante as três trocas para não provocar um salto no rasgo. Uma reprodução maior legítima ainda melhoraria a leitura em TV/4K; não foi inventado detalhe para compensar a resolução.

Foram realizadas duas rodadas de captura das nove telas:

1. [`zip-round-1`](../../visual-review/zip-round-1/): diagnóstico da integração, incluindo ferrovia, petróleo e SENAI já preenchidos.
2. [`zip-round-2`](../../visual-review/zip-round-2/): revisão com moldura compacta no petróleo e Rua Presidente Sodré abrindo o capítulo da cidade, com a indicação explícita de registro posterior.

Os três pontos principais examinados foram o excesso de espaço nas molduras das fotos pequenas, a distinção entre data da imagem e data do acontecimento e o enquadramento dos registros de resoluções diferentes. As capturas não detectaram cortes nas áreas medidas. Os estados internos também foram capturados e examinados:

- [Planta no capítulo dos pescadores](pescadores-planta.png) e [margem do rio com legenda de registro posterior](pescadores-rio.png).
- [Obras da Petrobras](petroleo-obras.png) e [instalações da Petrobras](petroleo-instalacoes.png).
- [Pátio ferroviário](ferrovia-patio.png) e [posição da estação de 1978 ainda pendente](ferrovia-pendente.png).
- [SENAI em 3840 × 2160](senai-4k.png).
- [HTML exportado em contexto offline](standalone.png).

## Testes executados

| Verificação | Resultado final |
| --- | --- |
| `npm test` | **14 passaram**, zero falhas ou testes ignorados, 46,8 s |
| Sequência dos pescadores | Três registros reais, datas independentes e pausas de 3 s, com rasgo entre eles |
| Todas as posições | 16 posições conferidas: registros carregam ou a ausência exibe o nome exato da estação de 1978 |
| Autorização declarada | Sete registros com escopo documentado, sem inventar URL pública de licença; painel S testado |
| Controles e fullscreen | Pausa, navegação, reinício e painéis passaram |
| 1080p / 4K | Composição, alternância, dimensões de títulos e limites passaram |
| Ciclos acelerados | Três ciclos, sem erros nem imagens quebradas |
| `npm run export` | TypeScript, build e HTML autossuficiente concluídos; aproximadamente 7,8 MiB |
| Produção | Loop completo, zero requisições externas, zero respostas com erro, zero erros de JavaScript |
| HTML offline | Fontes e imagens incorporadas, 17 links de fontes/condições, fullscreen e loop passaram; zero requisições externas |
| Ciclo normal completo | **79,465 s**, sem interação, 532 quadros capturados, ordem 0→1→2→3→4→5→6→7→8→0, zero erros ou requisições externas |

A primeira execução do novo teste do painel enviou S antes de os ouvintes de teclado estarem registrados; o teste foi corrigido para aguardar a inicialização real e a visibilidade do painel. A execução final dos 14 testes passou. Nenhuma verificação foi removida ou desativada.

A [gravação integral](complete-normal-speed.mp4) registra pinturas reais do navegador. [cycle-results.json](cycle-results.json) contém os estados e tempos. O HTML é testado com seus bytes exatos via `setContent` em Chromium offline: a navegação direta `file://` é bloqueada pelo navegador gerenciado e não foi contornada. Não foi executado ensaio em TV física nem por várias horas.

## Abrir e editar

O [README principal](../../../README.md) contém os comandos e controles. O arquivo de exibição é `exports/macae-exposicao.html`; abra-o no Chrome/Edge do computador da TV e pressione **F**. Após editar qualquer material, rode `npm run export` novamente. O painel do ChatGPT não foi declarado corrigido ou publicado por esses testes.

As instruções reutilizáveis do ambiente foram atualizadas para reconhecer este ZIP, as permissões já informadas e o catálogo de 12 registros. Salvar o rascunho não aplica nem publica o ambiente; sua publicação é feita pelo produto.
