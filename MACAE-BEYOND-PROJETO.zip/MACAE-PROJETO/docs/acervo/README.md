# Atualização do acervo e revisão da exposição

> **Etapa anterior ao ZIP.** A [atualização com as imagens recebidas](upload/README.md) é o relatório atual: 12 registros disponíveis, uma imagem ausente e 14 testes. Este documento preserva o diagnóstico e a validação anteriores.

Entrega de **20/10/2026**. Interface executada e examinada em Chromium, com três conjuntos de capturas: diagnóstico, revisão e resultado final. Foram concluídas duas rodadas de refinamento. A versão atual mantém os sete capítulos, o visual escuro, a linha branca congelada, o rasgo de papel e o funcionamento automático.

## O que foi localizado

Não havia imagens históricas fornecidas pelo usuário no checkout ou no restante de `/workspace`. A pasta informada `C:\Users\MAC0161855\Downloads\Imagens Trabalho Feira` está no computador Windows, fora do alcance deste ambiente. Não alegamos ter aberto essa pasta.

A partir das URLs fornecidas foram obtidos **quatro registros distintos**, com fonte e condições de reutilização conferidas. Eles estão em `public/media/`, com fichas em [`data/image-sources.json`](../../data/image-sources.json). O inventário por nome está em [inventory.json](inventory.json). Outros dois arquivos foram consultados, mas não incorporados por pendências de direitos/datação/qualidade. Sete outros materiais não puderam ser obtidos; não foram substituídos por desenhos.

| Capítulo | Registros incorporados | Posições ainda pendentes |
| --- | --- | --- |
| 01 · Vila dos Pescadores | Folha de rosto de *Cartas Topográficas*, 1767 | Planta da Cidade de Macahé; Rio Macaé — Vista Panorâmica |
| 02 · Vila São João, 1813 | Mapa do canal Campos–Macahé, **1846**, identificado como posterior | Planta da Cidade de Macahé |
| 03 · Macaé se torna cidade, 1846 | Rua Presidente Sodré, **meados do século XX**, registro posterior | Rio Macaé — Vista Panorâmica |
| 04 · Porto da Imbetiba | Praia de Imbetiba, **1941**, registro posterior; mapa do canal, **1846** | Nenhuma das duas posições visuais; cronologia do porto continua em pesquisa |
| 05 · Ferrovia / Vila da Imbetiba | Nenhum arquivo aprovado | Estação 1917; Pátio Ferroviário, possivelmente década de 1960; Estação 1978 |
| 06 · Petróleo | Nenhum arquivo aprovado | Primeira Guarita 1978; Obras de Instalação 1978; Instalações 1978 |
| 07 · SESI/SENAI | Nenhum arquivo aprovado | Fachada da Unidade SENAI, 2015 — direitos e identificação pendentes |

São **13 candidatos distintos**, dos quais quatro disponíveis e nove pendentes, distribuídos por **16 posições**. Reutilizar um mapa em dois contextos não cria dois documentos distintos. O usuário pode editar a ordem por `mediaIds`; materiais disponíveis aparecem antes das pendências. O porto abre com a praia, evitando repetir imediatamente o mesmo mapa usado na vila.

A folha de rosto de 1767 não é um mapa geográfico de Macaé. Seu JPEG disponível tem 535 × 748: não foi ampliado; uma digitalização maior permanece pendente. As três outras reproduções foram reduzidas proporcionalmente para largura de 2560, sem corte ou filtro. [processing.json](processing.json) registra dimensões e hashes. A fotografia da praia mantém CC BY-SA 3.0 e crédito a Aristides Henriques de Oliveira / Halleypo; conserve autoria e licença ao reutilizá-la.

## Direitos e fontes

- **Legenda visível:** título/data real, indicação de registro posterior e crédito compacto. A praia mantém indicação CC BY-SA 3.0.
- **Tecla S:** fichas completas, fonte, link para condições de uso, notas de processamento e todos os materiais pendentes.
- **Catálogo incorporado:** [`image-sources.json`](../../data/image-sources.json).
- **13 candidatos e nomes esperados:** [`image-candidates.json`](../../data/image-candidates.json).
- **Comprovação cronológica, divergências e limitações:** [historical-sources.md](../historical-sources.md).
- **Substituição e correspondência semântica de nomes:** [media-guide.md](../media-guide.md).

**29/07/1813** e o ano de **1846** foram confirmados na página História da Prefeitura. A mudança da data omitida para 1846 foi documentada. Não foi confirmado dia/mês da elevação. Os demais anos do roteiro permanecem provisórios, sem invenção de inaugurações. O título do petróleo evita associar 1978/1980 à fundação da Petrobras.

## Revisão visual executada

Primeiro conjunto: [`acervo-round-1`](../visual-review/acervo-round-1/). As nove telas foram capturadas em 1920 × 1080. Os três maiores problemas de acabamento foram:

1. Créditos em cerca de 14,9 px, pouco confortáveis para a TV. Foram simplificados sem perder autoria e ampliados para cerca de 18,2 px, com legendas de 19,2 px e contraste maior. A ficha extensa permanece no painel S.
2. Margens excessivas dentro das molduras. A proporção da área foi ajustada de 1,12 para 1,22 e o passe-partout de 1,6vw para 1vw, preservando o quadro inteiro das imagens.
3. A dobra do rasgo ainda usava cinzas frios. A paleta da dobra e das fibras foi aquecida para marfim; a linha do tempo mantém o branco gelado.

Segundo conjunto: [`acervo-round-2`](../visual-review/acervo-round-2/). Após conferir as correções, a segunda rodada reorganizou o porto para começar com a fotografia de 1941, evitando repetição imediata do mapa, e explicitou “fotografia” na legenda da Rua Presidente Sodré, conservando “registro posterior”. As capturas finais foram repetidas e examinadas. A ausência de nove registros continua sendo a principal limitação material; não há correção visual legítima que substitua os originais e a autorização.

Capturas finais, todas executadas:

| Tela | Captura 1920 × 1080 |
| --- | --- |
| Abertura | [00-abertura.png](../visual-review/acervo-final/00-abertura.png) |
| Pescadores | [01-pescadores.png](../visual-review/acervo-final/01-pescadores.png) |
| Vila São João | [02-vila.png](../visual-review/acervo-final/02-vila.png) |
| Cidade | [03-cidade.png](../visual-review/acervo-final/03-cidade.png) |
| Porto | [04-porto.png](../visual-review/acervo-final/04-porto.png) |
| Ferrovia | [05-ferrovia.png](../visual-review/acervo-final/05-ferrovia.png) |
| Petróleo | [06-petroleo.png](../visual-review/acervo-final/06-petroleo.png) |
| SESI/SENAI | [07-formacao.png](../visual-review/acervo-final/07-formacao.png) |
| Encerramento | [08-encerramento.png](../visual-review/acervo-final/08-encerramento.png) |

Também foram capturados o [rasgo entre duas peças autênticas](tear-between-records.png), a [cidade em 3840 × 2160](cidade-4k.png) e a [abertura do HTML offline](standalone.png). Os verificadores de captura não detectaram cortes nas áreas medidas; o teste funcional conferiu alternância e geometria nos dois tamanhos.

## Testes executados e resultados

| Verificação | Resultado observado |
| --- | --- |
| `npm test` | **13 testes passaram**, 44,6 s na execução final |
| Autoplay em velocidade normal | Inicia sem interação; três posições do primeiro capítulo observadas antes de avançar |
| Pausas e câmera | 3 s por posição, rasgo de 1,2 s adicional; deslocamento suave de cerca de 1,21 s |
| Sequência e rasgo | Camada nova realmente sob a anterior, máscara irregular, limpeza e pausa verificadas entre foto de 1941 e mapa de 1846 |
| Ciclos acelerados | Três ciclos completos, ordem correta, sem erro de JavaScript ou arquivo quebrado |
| Nomes e pendências | Correspondência por nomes/acentos/anos; todas as 16 posições conferidas; falha forçada retorna ao nome exato, sem desenho ou ícone quebrado |
| Teclas e fullscreen | Pausa, setas, F, R, H, S e fechamento dos painéis passaram |
| Movimento reduzido | Sem partículas ou rasgo; conteúdo permanece acessível |
| 1080p e 4K | Alternância, limites da tela e tamanho dos títulos passaram |
| `npm run export` | TypeScript, build e exportação concluídos; HTML de cerca de 4,7 MiB |
| `node tests/production.mjs` | Ciclo completo; zero requisições externas, zero respostas HTTP com erro, zero erros de JavaScript |
| `node tests/standalone.mjs` | Bytes exatos do HTML em contexto offline: fontes/imagens incorporadas, oito links de créditos/licenças, fullscreen e loop passaram; zero requisições externas |
| `node tests/brief-cycle.mjs` | Ciclo normal **79,209 s**, sem interação, sequência 0→1→2→3→4→5→6→7→8→0, 544 quadros capturados, zero erros ou requisições externas |

A gravação real do ciclo está em [complete-normal-speed.mp4](complete-normal-speed.mp4); os estados e tempos estão em [cycle-results.json](cycle-results.json). Não foi criada uma animação de teste a partir de capturas estáticas: o vídeo registra pinturas reais do navegador durante um ciclo automático.

**Não executados:** TV física, resistência por várias horas, abertura direta `file://` no Chromium gerenciado (bloqueada pela política) e publicação do painel do ChatGPT. O teste offline usa `setContent` dos bytes exportados e não contorna esse bloqueio. Nenhum teste declara todos os fatos históricos comprovados ou todos os candidatos autorizados.

## Executar e entregar

Veja o [README principal](../../README.md). `npm run export` gera `exports/macae-exposicao.html`, para transferir ao computador da TV. Abra em Chrome/Edge externo e pressione F. O painel de visualização do ChatGPT neste fluxo não publica o Vite automaticamente; não foi declarado corrigido.

As instruções de inicialização foram atualizadas no rascunho do ambiente. Além dos domínios institucionais existentes, a pesquisa solicitou ClimaOnline, Macaé Tips, Slideshare, Gallica e objdigital BN. A persistência do rascunho foi confirmada; ela não aplica a rede nem publica o ambiente. Revise e salve as configurações e publique pelo produto para preservar a configuração preparada. Restauração em uma nova tarefa não foi testada.
