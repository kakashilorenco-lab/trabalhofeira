# Entrega e pré-visualização — diagnóstico de 20/10/2026

O usuário informou falha ao baixar os links internos e ausência de pré-visualização no ChatGPT. Os links `/workspace/...` enviados anteriormente identificavam arquivos locais; não eram anexos publicados e não foram validados como downloads. Não repetir esses links como se solucionassem a entrega.

Neste fluxo, as ferramentas disponíveis não incluem publicação de preview, encaminhamento de portas ou envio de anexos gerados. O serviço Vite no contêiner não é automaticamente exposto no painel do ChatGPT. Publicar o ambiente salva a configuração e seu snapshot; não é publicação do site nem transferência do HTML para o usuário.

## Artefatos concretos preparados

- `exports/macae-exposicao.html`: 8.175.455 bytes, HTML autossuficiente.
- `exports/MACAE-TV.zip`: 6.049.594 bytes, inclui o mesmo HTML e instruções em português para extrair e abrir em Chrome/Edge.
- O ZIP passou na verificação CRC e o hash do HTML extraído coincide com o exportado.
- SHA-256 do ZIP: `5de966e5103b931480d08ef9658ac30eada4440aedb05b8951630c7155d49e2d`.
- O teste offline foi repetido: fontes/imagens incorporadas, 17 links de créditos, fullscreen e loop passaram, sem requisições externas ou erros de JavaScript. A navegação direta `file://` continua bloqueada apenas no navegador gerenciado, sem contorno da política.

## Alternativa de entrega proposta

A leitura do remoto `kakashilorenco-lab/trabalhofeira` funcionou e não encontrou HEAD. Foi solicitada autorização explícita para enviar o ZIP a uma nova branch, pois isso transfere os arquivos para o GitHub e segue a visibilidade do repositório. Nenhum envio foi realizado antes da resposta. A autorização prévia de uso das imagens nesta apresentação não foi tratada como aprovação automática para hospedagem pública externa.

Capturas reais podem mostrar a composição de forma estática na conversa; não são uma pré-visualização interativa. Não alegar que o preview ou o download foram corrigidos enquanto a entrega efetiva não for publicada e acessível por um canal suportado.

## Entrega confirmada

O usuário autorizou explicitamente o envio pelo GitHub. Foi criada e enviada a branch `entrega/macae-tv-2026-10-20`, sem mudar o HEAD, o índice ou os arquivos de trabalho do checkout. O commit remoto foi confirmado: `d1fd38da651ecabf6614ace4f14583c6072510b9`. Essa branch contém apenas o pacote de exibição, instruções e duas capturas reais; não substitui o código-fonte local.

- Download real: https://github.com/kakashilorenco-lab/trabalhofeira/raw/refs/heads/entrega/macae-tv-2026-10-20/MACAE-TV.zip
- Capturas e instruções: https://github.com/kakashilorenco-lab/trabalhofeira/tree/entrega/macae-tv-2026-10-20

O arquivo publicado foi baixado novamente: HTTP 200, Content-Type `application/zip`, 6.049.594 bytes, SHA-256 idêntico e CRC válido. Este link foi efetivamente testado; não é um caminho interno apresentado como anexo. O preview animado no ChatGPT continua indisponível; a página GitHub contém apenas capturas estáticas.
