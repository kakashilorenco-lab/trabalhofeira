# Fontes históricas — atualização de 20/10/2026

> Atualização após recebimento do ZIP, em 20/10/2026: os 11 arquivos foram identificados e o catálogo passou a 12 registros, incluindo o atlas já existente. O responsável informou autorização de uso pelo Macaé Tips para Petrobras, pátio e SENAI e confirmou separadamente que ela inclui também o mapa da cidade e a margem do rio. A declaração exata e seu alcance estão em `data/permissions.json`; ela não foi convertida em licença pública. Apenas a estação de 1978 continua ausente. O [relatório do ZIP](acervo/upload/README.md) atualiza o inventário e as pendências descritas no relatório abaixo, que registra a etapa anterior.

A pesquisa agora é **parcialmente verificável**, com acesso à Prefeitura, BNDigital e Wikimedia Commons. O [relatório de 19/10](archive/historical-sources-2026-10-19.md) registra os bloqueios da edição anterior e não descreve o estado atual. Os sete temas foram preservados. Fontes acessadas não tornam automaticamente todo o roteiro validado.

## Datas: confirmação e pendências

Fonte efetivamente lida: Prefeitura Municipal de Macaé, **História**, https://macae.rj.gov.br/conteudo/leitura/titulo/historia, acesso em 20/10/2026.

| Tema | Resultado da conferência | Decisão de exibição |
| --- | --- | --- |
| Vila dos Pescadores, XVII–XVIII | Tema e recorte fornecidos pelo usuário. A denominação e sua abrangência social precisam de pesquisa específica; não comprovamos uma fundação única. | Manter como tema do roteiro; a folha de rosto de 1767 é contexto cartográfico regional, sem alegação de retratar a vila. |
| Vila São João de Macaé, 29/07/1813 | A página municipal registra a criação da vila por alvará de 29 de julho de 1813. O alvará original não foi consultado. | Data confirmada em fonte institucional secundária. |
| Elevação a cidade | Nota 21 da página municipal: “O Município de Macaé foi elevado à categoria de cidade em 1846.” Cita KNAUSS, Paulo. *Macaé: História e Memória*. Prefeitura de Macaé / Fundação Macaé de Cultura, 2001, p. 86. O livro não foi consultado diretamente. | **1846** substitui a omissão anterior. Não atribuir dia ou mês sem nova fonte. |
| Porto da Imbetiba, 1844 / 1875 | Não foi comprovado qual fato corresponde a cada ano. | Anos de referência provisórios; não chamar ambos de inauguração. O mapa do canal não prova a cronologia do porto. |
| Ferrovia / Vila da Imbetiba, 1875 | Cronologia do trecho, estação e vila ainda pendente de fonte histórica específica. | Ano de referência provisório; não inferir inauguração a partir de fotos posteriores. |
| Petrobras / petróleo, 1978 / 1980 | Os marcos operacionais locais ainda não foram confirmados. | O título continua “Macaé, cidade do petróleo”. **Não adotar “Fundação da Petrobras” para esses anos**; o roteiro confunde o tema local com a criação da empresa. |
| SESI/SENAI, 1995 / 1996 – 2008 | Construção, inauguração, ampliação, endereço e unidades não confirmados. | Preservar os anos fornecidos como provisórios. A fachada de 2015 não comprova construção em 1995/1996. |

A ordem solicitada foi preservada. O intervalo do porto abrange o marco da cidade e se sobrepõe ao da ferrovia: trata-se de capítulos temáticos, não de uma ordenação estrita de todos os anos.

## Acervo efetivamente consultado e incorporado

As fichas completas estão em [`data/image-sources.json`](../data/image-sources.json); a associação com os vários eventos e os nove candidatos pendentes está em [`data/image-candidates.json`](../data/image-candidates.json). A API do Commons foi lida com descrição original (wikitext), metadados e condições de uso, não apenas por resultados de busca. As respostas foram preservadas em `docs/acervo/commons-*.json`.

1. **Manoel Vieira Leão, Cartas Topográficas da Capitania do Rio de Janeiro, 1767 — folha de rosto.** [Artigo da BNDigital](https://bndigital.bn.gov.br/dossies/biblioteca-virtual-da-cartografia-historica-do-seculo-xvi-ao-xviii/artigos/cartas-topograficas-da-capitania-do-rio-de-janeiro/). O artigo confirma autor e ano e liga a reprodução fornecida pelo usuário. [Condições de reutilização da BN](https://bndigital.bn.gov.br/orientacoes-de-uso-de-arquivos-digitais/): obras em domínio público têm reutilização livre e gratuita com o crédito “Acervo da Fundação Biblioteca Nacional – Brasil”; obras protegidas exigem autorização do titular. Usamos a obra de 1767 em domínio público, com o crédito exigido. **O JPEG é a folha de rosto, não a folha geográfica de Macaé**. A versão acessível tem 535 × 748 e é exibida sem ampliação; cópia de maior resolução pendente. O artigo diz que a folha 15 representa o rio Macaé, mas não obtivemos essa folha. O [catálogo indicado pelo artigo](https://objdigital.bn.br/objdigital2/acervo_digital/div_cartografia/cart512339/cart512339.htm) ficou bloqueado pelo proxy.
2. **Arquivo Militar, Planta da Direção do Canal de Campos a Macahé, 1846.** [Ficha Commons / BnF](https://commons.wikimedia.org/wiki/File:Planta_da_Direo%C3%A7ao_do_Canal_de_Campos_a_Macah%C3%A9..._-_btv1b8490826j.jpg). BnF, département Cartes et plans, GE D-13911; identificador `btv1b8490826j`. Ficha declara domínio público (`PD-France`, `PD-US-expired`). O original possui 7341 × 4955; cópia local proporcional de 2560 × 1728, sem cortes. Relaciona o território aos transportes; não é imagem de 1813 nem prova de inauguração do porto.
3. **Aristides Henriques de Oliveira, Praia de Imbetiba, 1941.** [Ficha Commons](https://commons.wikimedia.org/wiki/File:Praia_imbetiba_macae_rj_1941.jpg). A descrição do usuário Halleypo afirma que a foto foi tirada por seu avô, Aristides, durante levantamentos geológicos. O campo de autor da API identifica o usuário; a descrição esclarece o fotógrafo, por isso ambos são creditados. Licença declarada [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/). Mantida a fotografia original, com redução técnica para 2560 × 1614. Paisagem da praia em 1941, **posterior** ao período do porto; não descrevê-la como fotografia de instalações portuárias em 1844/1875.
4. **Autor não identificado, Trecho da Rua Presidente Sodré.** [Ficha Commons / Arquivo Nacional](https://commons.wikimedia.org/wiki/File:Trecho_da_Rua_Presidente_Sodr%C3%A9,_Maca%C3%A9_(RJ).tif). Fundo Correio da Manhã, código `BR_RJANRIO_PH_0_FOT_06937_0131`. A ficha data “Mid 20th century” e declara domínio público pelo modelo do Arquivo Nacional. Não atribuir ano exato. O título informa a antiga Avenida Feliciano Sodré; a inscrição da própria foto é preservada. TIFF 3065 × 1869 convertido proporcionalmente em JPEG 2560 × 1561. Registro posterior à elevação de 1846.

Nenhum material passou por IA, reconstrução, colorização, filtro sépia ou criação de detalhes. As cores envelhecidas vistas nas reproduções pertencem aos arquivos obtidos. Dimensões, tratamentos e hashes SHA-256 constam de [`acervo/processing.json`](acervo/processing.json).

## Materiais consultados mas não incorporados

- **Planta da Cidade de Macahé:** reprodução https://macae.rj.gov.br/midia/uploads/Mapa.jpg. A página História identifica a fonte como BNRJ e a pesquisa como Solar dos Mellos. O arquivo tem apenas 647 × 443; a datação “século XIX” vem do roteiro, sem ano visível confirmado. Falta verificar a condição de reutilização dessa reprodução e obter versão maior.
- **Fachada SENAI 2015:** https://macae.rj.gov.br/midia/noticias/34328/1430392799.jpg, JPEG 5184 × 3456 acessível. Atribuição “Divulgação — Mobilidade Urbana” fornecida pelo usuário. A matéria correspondente, data, autoria e permissão de reutilização não foram confirmadas; o arquivo não foi redistribuído.
- **IBGE Cidades:** a página https://cidades.ibge.gov.br/brasil/rj/macae/historico respondeu 200, mas apenas com a estrutura JavaScript, sem histórico legível nessa consulta. Não foi usada como comprovação. O PDF tentado em 19/10 retornou 404 em 20/10; não é referência documental.

## Bloqueios e materiais ainda não acessados

ClimaOnline, Macaé Tips e image.slidesharecdn.com retornaram bloqueio de túnel HTTPS (403). Os nomes, autores e anos do panorama, das estações, do pátio e das três imagens da Petrobras são **referências fornecidas**, não fatos visuais verificados por nós. Todos os links exatos e motivos estão no catálogo de candidatos. Não consideramos a compilação do Slideshare uma licença e não ampliamos suas miniaturas de 320 px.

Não havia imagens históricas do usuário no checkout nem no restante de `/workspace`: apenas capturas de testes. O caminho informado `C:\Users\MAC0161855\Downloads\Imagens Trabalho Feira` é local ao Windows e não está montado na nuvem. Quatro arquivos foram recuperados de fontes verificadas; os nove restantes aguardam arquivos, qualidade e/ou direitos. O recebimento dos arquivos não dispensa a verificação de origem e licença.

Os domínios adicionais de pesquisa foram salvos no rascunho do ambiente. Salvar esse rascunho não aplica a rede nem publica o ambiente. Até concluir estas pendências, esta é uma exposição funcional **em edição de pesquisa**, com acervo incompleto.
