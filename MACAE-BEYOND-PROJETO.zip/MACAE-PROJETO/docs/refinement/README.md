# Refinamento visual e motion — Macaé

Implementado em 19/10/2026 sobre a aplicação existente, sem recriar o projeto. O conjunto atual de evidências está nesta pasta; as capturas completas das nove cenas estão em `docs/visual-review/minimal-final/`.

## O que foi preservado

- Os sete temas, sua ordem, todos os títulos, descrições e ressalvas históricas em `src/data/events.ts` permanecem byte a byte idênticos.
- A fórmula de geometria da timeline (`knots` e `path`, no `App.tsx`) foi comparada com a cópia anterior e permanece idêntica. A alternância de texto e mídia também foi mantida.
- Pausas de leitura, autoplay, encerramento, loop, controles de teclado, painel de fontes, fontes tipográficas locais e exportação offline continuam disponíveis.
- `data/image-sources.json` permanece idêntico e vazio. Não havia fotografias autenticadas a preservar. Nenhuma imagem de IA ou peça histórica fictícia foi criada para a refatoração.

Hashes SHA-256 anteriores e posteriores:

```text
src/data/events.ts
9da176d87e0033477af4d4ff7e343b56565d66969e25341ce4774c582e3d5ca4

data/image-sources.json
37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570
```

## Direção de arte

O monograma M, símbolo, ponto ao lado de MACAÉ, ornamentos cartográficos, marca-d'água de capítulos, ruído, tons cobre/âmbar e molduras foram removidos. A abertura traz MACAÉ apenas como título editorial. Os campos gráficos receberam superfícies frias e menos linhas; textos, datas e mídia mantêm sua organização anterior. Os avisos de pesquisa permanecem legíveis porque o refinamento visual não resolve as lacunas documentais.

A interface usa grafite `#101215`, branco `#f2f4f5` e cinzas frios. O núcleo da linha é quase branco puro (`#f9fdff`), com luz interna, halo, atmosfera estreita e pele de geada em camadas. As fotografias futuras mantêm cores originais: não há sépia, colorização ou filtro de paleta sobre o registro.

## Construção do gelo

O caminho SVG original recebe múltiplos traços estreitos, facetas translúcidas e um trecho de luz que acompanha o ponto real amostrado do caminho. As facetas são criadas uma única vez por mudança de geometria, não por frame ou por loop. Não existe filtro de blur aplicado ao SVG de nove telas.

O Canvas de névoa ocupa somente uma faixa central de 168 px em 1080p, escalada com a resolução. A névoa usa três sprites radiais procedurais pequenos, criados localmente; não são imagens de acervo. Microcristais têm tamanho, velocidade, opacidade e vida útil variáveis. O limite simultâneo é 48. A emissão aumenta na viagem e aproximação, cai durante a leitura e diminui ainda mais no rasgo. Na observação automática a geada continua discreta; a pausa manual congela o relógio visual. O pulso do marco começa na chegada, após a desaceleração.

## Ritmo

| Parâmetro | Antes | Atual |
| --- | --- | --- |
| Deslocamento entre marcos | 3.400 ms | 1.700 ms, 2× mais rápido |
| Retomada | 600 ms | 350 ms |
| Primeiro capítulo: observação | 3 × 8 s | 3 × 8 s, preservada |
| Primeiro capítulo: transições | Troca direta | 2 × 1,2 s, acrescentadas à observação |
| Outros capítulos | 17–20 s | 17–20 s, preservados |
| Abertura / encerramento | 12 / 14 s | 12 / 14 s, preservados |
| Ciclo completo, aproximadamente | 3 min 12 s | 3 min |

As rampas de aceleração e desaceleração são integrais de curvas de velocidade cosseno: a posição e a velocidade continuam suaves nas junções. O trajeto ficou mais rápido; o tempo de leitura não foi dividido por dois.

## Rasgo de papel

`PaperTearTransition.tsx` mantém a próxima folha em `.paper-under` e a anterior em `.paper-front`, de verdade, em camadas DOM sobrepostas. A folha superior recebe uma máscara com 201 pontos. A ruptura começa pelo canto superior direito, propaga-se até a borda inferior e revela o conteúdo abaixo.

A trajetória combina irregularidades correlacionadas em diferentes escalas, pequenos dentes, fibras separadas, dobra de largura variável com iluminação e sombra de contato. A sombra acompanha a mesma borda em cada frame. Ao terminar, a máscara é removida, a folha frontal e a borda são ocultadas, e a folha inferior fica estável. Não há explosão de fragmentos, tela branca, movimento de papéis pela tela nem fade entre imagens.

O rasgo lê `tearProgress` do controlador existente. Ele não possui `setInterval`, `setTimeout` ou segundo loop de animação. Pausar, avançar, recuar, reiniciar e alternar sequências usam o mesmo estado. A preferência de movimento reduzido remove partículas e rasgo, mantendo o conteúdo seguinte visível.

**Limite importante:** o efeito foi inspecionado sobre as três composições tipográficas que já existiam. Não há fotografias no catálogo; portanto, não se afirma que foram feitas capturas de fotografias reais antes/durante/depois. O mesmo componente envolve o ramo de mídia autêntica, mas o ensaio com fotografias reais depende da curadoria do acervo.

## Duas rodadas de refinamento

### Rodada 1: limpeza, luz e ritmo

Foram capturadas as nove cenas em `docs/visual-review/minimal-round-1/`, sete estados do rasgo em `round-1/` e uma gravação real de aproximadamente 11,7 segundos. A sequência foi extraída do vídeo e inspecionada em [round-1/video-frames.jpg](round-1/video-frames.jpg).

Problemas encontrados: a primeira borda tinha dentes regulares e uma dobra grossa que lembravam um zíper; o acabamento da linha ainda parecia sobretudo um tubo iluminado; a névoa quase desaparecia. As correções combinaram ruído em várias escalas, propagação pelo canto, dobra mais estreita, sombra menor, facetas de gelo e leve aumento da névoa junto à linha.

### Rodada 2: materialidade, sincronização e limpeza

Foram feitas outras nove capturas em `docs/visual-review/minimal-round-2/`, sete estados do rasgo e nova gravação real em `round-2/`. A borda passou a ter irregularidade variável e uma dobra mais discreta, sem repetição de dentes. A revelação da folha inferior e o repouso depois da troca foram confirmados.

Na revisão de sincronização, o pulso do marco estava associado à seleção do destino, antes de a câmera chegar. Foi transferido para a chegada. A máscara residual, embora invisível, passou a ser explicitamente removida após o rasgo. Os testes de máscara, motor e composição foram repetidos após esses ajustes: três passaram.

### Confirmação final e vídeos

- [Prancha das nove cenas finais](final/overview.jpg).
- [Frames extraídos do vídeo real do rasgo](final/video-frames.jpg).
- [Vídeo do rasgo em tempo real](final/paper-tear-realtime.mp4).
- [Vídeo da viagem e chegada em tempo real](final/ice-travel-realtime.mp4).
- [Linha congelada em movimento](final/ice-travel.png).
- [Antes do rasgo](final/tear-00-before.png), [abertura intermediária](final/tear-50.png), [folha seguinte revelada](final/tear-99-after.png).
- [Metadados da captura](final/capture-results.json).

Os vídeos vêm de frames reais emitidos pelo Chromium via CDP durante execução em velocidade normal, codificados por FFmpeg com suas durações. Não foram montados a partir dos screenshots controlados. Os screenshots intermediários usam o relógio de desenvolvimento posicionado em valores conhecidos para examinar a borda em detalhe; esses dois métodos estão distinguidos no script.

## Testes

`npm test`: **9 passaram, 0 falharam, 0 ignorados**, aproximadamente 72 segundos. A suíte cobre o motor, três leituras automáticas em velocidade normal, viagem 2× mais rápida, pausa no meio do rasgo, camadas sobrepostas, borda irregular, limpeza final, movimento reduzido, teclado, fullscreen, três loops automáticos, recursos locais e composição em 1080p/4K. Depois da última limpeza de máscara, três testes relevantes foram repetidos e passaram.

Build TypeScript/Vite aprovado. Sem nova dependência de runtime. A medição de fluidez e de dez ciclos adicionais após aquecimento fica em [performance-results.json](performance-results.json): amostra de 8,2 segundos em velocidade normal, 492 frames, média de **59,9 FPS**, mediana e percentil 95 de **16,7 ms**, maior intervalo de 49,9 ms. O trecho inclui observação, rasgo e viagem.

Após dois ciclos de aquecimento e mais dez ciclos a 60×, o DOM continuou com **649 elementos** e o motor com **sete assinaturas de renderização**, sem acumulação. Permaneceram 145 facetas estáticas; os cristais vivos ficaram dentro do limite configurado. O heap JavaScript após coleta de lixo passou de 7.995.864 para 8.245.548 bytes, cerca de 244 KiB de diferença; não se interpreta essa única comparação como prova de ausência de vazamento. Nenhuma exceção de navegador foi registrada. Os resultados medem esta instância headless, não o desempenho garantido em qualquer TV ou computador.

## Ajustes e reprodução

Todos os parâmetros artísticos ficam em `src/motion/config.ts`:

| Grupo | Controles principais |
| --- | --- |
| Câmera | `SCROLL_SPEED_MULTIPLIER`, `SCROLL_ACCELERATION`, `SCROLL_DECELERATION`, `RESUME_DURATION` |
| Leitura | `SECTION_HOLD_MULTIPLIER`, `IMAGE_HOLD_DURATION`, `INTRO_DURATION`, `OUTRO_DURATION` |
| Gelo | `ICE_GLOW_INTENSITY`, `ICE_PARTICLE_DENSITY`, `ICE_PARTICLE_SPEED`, `ICE_MIST_OPACITY`, `ICE_PARTICLE_LIMIT` |
| Papel | `PAPER_TEAR_DURATION`, `PAPER_TEAR_IRREGULARITY`, `PAPER_TEAR_SHADOW`, `PAPER_TEAR_PROPAGATION`, `PAPER_TEAR_CURL` |

Use valores positivos para as durações. `SCROLL_ACCELERATION` e `SCROLL_DECELERATION` são frações do trajeto e sua soma deve ser menor que 1. Para mudar o intervalo de uma seção específica, continue usando `duration` nos dados existentes. As pausas de sequências devem ser suficientes para ler o conteúdo depois de cada rasgo.

```bash
cd /workspace/trabalhofeira
npm run dev -- --port 5173
# Em outro terminal, para repetir a evidência:
npm test
node tests/capture.mjs minimal-final
node tests/motion-capture.mjs final
node tests/performance.mjs
# Para distribuir o arquivo único atualizado:
npm run export
```

Os comandos de gravação exigem Chromium e FFmpeg, disponíveis nesta máquina. Os arquivos temporários dos frames ficam em `/workspace/scratch/macae-motion/`, fora do checkout.

## Pendências e limites

A cronologia documental e o acervo continuam pendentes conforme `docs/historical-sources.md`; esta tarefa não alterou seu status. A apresentação não deve ser publicada como narrativa historicamente verificada. Não houve teste em TV física nem execução por várias horas. Repetição acelerada e contagem estável de recursos não provam ausência de vazamento em todas as condições. A versão de arquivo único é destinada à abertura em um navegador externo; a prévia no painel do ChatGPT não foi habilitada por esta refatoração.
