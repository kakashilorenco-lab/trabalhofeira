# Validação da exposição

Execução em 19/10/2026. Navegador: Chromium 154, headless real, via Playwright. Node 24.19.0. Ambiente Linux. Referência visual: viewport 1920 × 1080; verificações geométricas adicionais em 3840 × 2160.

## Rodadas de revisão visual

Foram executadas **duas rodadas de refinamento**, seguidas por uma captura de confirmação. Cada conjunto contém abertura, pescadores, vila, cidade, porto, ferrovia, petróleo, SESI/SENAI e encerramento. As capturas não são mockups: vêm da aplicação executando no Chromium, com fontes locais carregadas. O relógio fica pausado para enquadrar cada cena; no segundo conjunto e no final, somente a notificação flutuante de pausa é ocultada na captura para permitir examinar a composição.

### Rodada 1 — diagnóstico e correções

Evidência: `docs/visual-review/round-1/`, nove PNGs.

Os três maiores problemas identificados:

1. Ao pausar na abertura antes de o relógio avançar, a cortina inicial permanecia opaca. A primeira captura registra esse defeito. Corrigido para que pausar revele a cena; o teste funcional verifica opacidade zero ao pausar imediatamente.
2. Notas curatoriais e créditos estavam pequenos para a TV. As notas foram ampliadas para cerca de 18 px em 1080p; as legendas, para cerca de 16,5 px, com contraste maior. Textos principais têm cerca de 24,6 px e títulos cerca de 92 px.
3. A linha atravessava o texto de encerramento. O término do caminho e a posição final da faísca foram elevados para a área acima do título.

### Rodada 2 — diagnóstico e correções

Evidência: `docs/visual-review/round-2/`, nove PNGs.

Os três maiores problemas restantes:

1. A máscara de entrada aplicada à figura inteira recortava as legendas externas, embora suas caixas geométricas estivessem corretas. A máscara foi limitada ao campo gráfico interno. As legendas aparecem nas capturas finais.
2. O granulado tinha presença excessiva, especialmente nos campos claros. Sua opacidade foi reduzida de 0,035 para 0,016.
3. A abertura entrava depressa em comparação com o restante do percurso. O título recebeu uma revelação de 2,6 segundos; o subtítulo entra com atraso discreto. A preferência de movimento reduzido elimina essas animações decorativas.

### Confirmação final

Evidência: `docs/visual-review/final/`, nove PNGs e [prancha das nove telas](visual-review/final/contact-sheet.jpg).

| Tela | Captura |
| --- | --- |
| Abertura | [00-abertura.png](visual-review/final/00-abertura.png) |
| Vila dos Pescadores | [01-pescadores.png](visual-review/final/01-pescadores.png) |
| Vila São João | [02-vila.png](visual-review/final/02-vila.png) |
| Elevação à cidade | [03-cidade.png](visual-review/final/03-cidade.png) |
| Porto da Imbetiba | [04-porto.png](visual-review/final/04-porto.png) |
| Ferrovia | [05-ferrovia.png](visual-review/final/05-ferrovia.png) |
| Petróleo | [06-petroleo.png](visual-review/final/06-petroleo.png) |
| SESI/SENAI | [07-formacao.png](visual-review/final/07-formacao.png) |
| Encerramento | [08-encerramento.png](visual-review/final/08-encerramento.png) |

As nove cenas finais foram inspecionadas na prancha de contato. Nenhum corte foi detectado nas caixas dos textos, figuras ou legendas em 1080p; nenhuma exceção foi registrada pelo navegador durante as capturas. As figuras alternam os lados. A ausência de acervo está indicada em todas as legendas. A inspeção confirma a direção de arte, não a autenticidade de um acervo que ainda não existe.

## Testes funcionais executados

`npm test`: **6 testes passaram; 0 falharam; 0 ignorados**. Duração aproximada: 1 minuto e 18 segundos.

| Verificação | Resultado / alcance |
| --- | --- |
| Máquina de estados | Testados INTRO, TRAVELING, APPROACHING_SECTION, SECTION_ACTIVE, HOLDING, IMAGE_SEQUENCE, RESUMING, OUTRO e RESTARTING; pausa congela a posição. |
| Temas e duração | Sete temas em ordem; tempos de leitura de 17–24 segundos; três leituras de 8 segundos no primeiro capítulo. |
| Autoplay sem interação | Teste em velocidade normal: entrada automática no primeiro marco, posição parada por 3 segundos, três leituras e avanço ao segundo marco. Cerca de 42 segundos de execução real. |
| Teclado | Espaço, setas, F, R, H, S e Esc; entrada/saída de fullscreen pela API do navegador; reinício retorna a INTRO. |
| Múltiplos loops | Três ciclos completos no Chromium a 30×, mantendo a ordem dos nove momentos e reinício sem recarregar a página. |
| Faísca | Posição comparada à geometria real do caminho SVG; aproximação dentro da tolerância de amostragem. Pulso do marco examinado visualmente nas cenas. |
| 1080p e 4K | Todos os sete marcos verificados em ambos os tamanhos; alternância, corpo de texto ≥ 24 px, títulos e legendas dentro da área útil. |
| Recursos e erros | Nenhuma solicitação externa, exceção JavaScript ou imagem quebrada durante os três ciclos. O catálogo histórico é explicitamente vazio, não um teste de carregamento de fotografias. |

Um erro inicial do runner por importação JSON sem atributo foi corrigido com `with { type: 'json' }`. A compilação posterior detectou uma declaração TypeScript incompleta no histórico de cenas do teste; a tipagem foi corrigida. Não houve alteração de uma asserção para esconder falha da aplicação.

## Build e produção

`npm ci --cache /workspace/.npm-cache --no-audit --no-fund` foi executado com sucesso para verificar a instalação pelo lockfile. `npm run build` executou a verificação TypeScript e gerou `dist/` com sucesso. O pacote contém scripts, fontes e licenças locais. O teste adicional `node tests/production.mjs` **passou** no preview da porta 4173, com origens externas bloqueadas: um loop completo, fontes carregadas, interface de depuração ausente, zero requisições externas, zero respostas HTTP com erro e zero exceções do navegador.

Para reproduzir:

```bash
npm run build
npm run preview -- --port 4173 --strictPort
# Em outro terminal:
node tests/production.mjs
```

## Limites e itens não executados

- Não houve ensaio em televisor físico, controle remoto, alto-falantes ou diferentes modelos de Smart TV. O alvo validado é um computador com Chromium conectado a uma TV.
- Não houve reprodução real por várias horas. Há um único relógio `requestAnimationFrame`, sem timers de avanço concorrentes; os três loops acelerados verificam repetição, mas não substituem um teste de longa duração na instalação final.
- Não houve avaliação documental das datas, inspeção de qualidade de fotografias, teste de sequência de três fotografias ou validação de licenças históricas. Esses itens dependem do acervo ainda não localizado. A sequência testada é tipográfica, explicitamente identificada.
- O fallback para erro de arquivo de imagem está implementado, mas não foi exercitado com uma fotografia histórica real, pois nenhuma foi incorporada.
- Fullscreen automático sem gesto não foi implementado, pois depende de restrição do navegador. A tecla F foi testada com sucesso.
- A composição em 4K foi verificada geometricamente; o conjunto de capturas e as duas revisões visuais foram feitos em 1080p.
- Para o build convencional, a execução offline significa não depender de internet externa após a preparação; o servidor HTTP local precisa permanecer ativo. A exportação em arquivo único dispensa esse servidor. Não há service worker ou instalação PWA.
- A publicação do ambiente e a restauração em uma nova tarefa não foram executadas. Salvar a configuração não equivale a publicar ou testar uma nova máquina.

O resultado é uma implementação executável e editável para ensaio expositivo. A publicação como narrativa histórica final permanece condicionada à verificação documental e à curadoria do acervo.

## Correção de acesso à visualização

Após relato de erro no painel do ChatGPT, os servidores de desenvolvimento e produção foram novamente verificados: ambos responderam HTTP 200. O smoke de produção passou novamente, incluindo um loop completo. Este fluxo de onboarding não oferece publicação de uma aplicação localhost no painel de visualização; o teste local não valida a interface do ChatGPT.

Foi adicionada a exportação `npm run export`, que incorpora o build inteiro em `exports/macae-exposicao.html`, incluindo fontes e licenças. O teste `node tests/standalone.mjs` **passou**: renderizou os bytes desse HTML no Chromium com a rede desligada, verificou as fontes incorporadas, entrada/saída de tela cheia e um loop completo; zero solicitações externas e zero exceções JavaScript. A navegação direta por `file://` foi bloqueada pelo administrador do Chromium gerenciado (`ERR_BLOCKED_BY_ADMINISTRATOR`); não foi contornada. A renderização usa `page.setContent` com o conteúdo do arquivo local, sem conceder acesso a arquivos ao navegador. Portanto, não se afirma que a abertura por `file://` foi validada nessa máquina gerenciada. O arquivo é destinado à abertura no navegador externo do computador de exibição.

A inspeção da exportação também identificou que a máscara final da revelação do título cortava o topo do acento de “MACAÉ”. A área final da máscara foi ampliada, o arquivo foi reexportado e o teste offline passou novamente. A captura `docs/visual-review/standalone.png` registra a correção; a abertura da prancha final também foi atualizada.
