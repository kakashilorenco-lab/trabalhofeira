# Acervo, substituição e correspondência de nomes

A versão atual incorpora 12 registros em `public/media/`, após receber e identificar os 11 arquivos do ZIP. Não há geração por IA nem ilustrações artificiais para substituir documentos. A estação de 1978 não veio no ZIP e conserva seu espaço nomeado. As permissões de sete registros foram informadas pelo usuário; os demais cinco têm condições de uso consultadas em fonte pública.

- `data/image-candidates.json`: 13 materiais solicitados, nomes esperados, URLs fornecidas, eventos relacionados, situação e pendências.
- `data/image-sources.json`: somente arquivos incorporados, com fonte e condições verificadas, data real, legenda e dimensões.
- `data/permissions.json`: declarações do responsável e os sete registros abrangidos, sem inventar URL de licença.
- `src/data/events.ts`: `mediaIds` por evento, que também definem a ordem; os disponíveis aparecem primeiro.
- `src/data/media.ts`: seleção dos arquivos e créditos compactos para TV. O painel S apresenta a ficha completa e links de licença.

## Localizar a pasta de imagens

A nuvem não tem acesso a `C:\Users\...`. Disponibilize os arquivos no ambiente, por exemplo extraindo um ZIP anexado em `/workspace/shared/downloads/imagens-macae`. Em seguida:

```bash
node scripts/inventory-images.mjs /workspace/shared/downloads/imagens-macae
```

O ZIP atual já foi extraído em `/workspace/shared/downloads/imagens-macae-enviadas`. O comando é somente leitura: normaliza acentos, espaços, pontuação e a grafia Macahé/Macaé. Usa palavras distintivas para associar nomes; exige distinguir as estações de 1917 e 1978 e não associa uma “estação” sem ano por adivinhação. Relata arquivos desconhecidos ou ambíguos sem copiá-los. Os arquivos enviados e seus hashes estão em `docs/acervo/upload/inventory.json`; `matching-results.json` registra as 11 correspondências. Uma associação por hash só vale para o arquivo já conferido, sem adivinhar o ano de outra estação sem data no nome.

**Uma correspondência de nome não comprova autoria, época ou licença.** Examine o arquivo e a fonte antes de incorporar. Não preencha o catálogo aprovado apenas porque uma imagem foi enviada ou está publicamente acessível.

## Incorporar ou substituir

1. Confirme a identidade na fonte institucional ou descrição de acervo; leia a condição de reutilização e guarde a evidência. Mantenha os dados não confirmados como pendentes.
2. Compare a data real do arquivo com o evento. Fotografia de 1941 não é de 1875; fachada de 2015 não é fotografia da construção de 1995. Use “registro posterior” quando necessário.
3. Prefira um original de alta resolução. Reduza proporcionalmente, sem corte essencial, sem extensão/reconstrução, sem filtro histórico automático. Não amplie miniaturas. A folha de rosto de 1767 é limitada ao tamanho de origem.
4. Salve uma versão web em `public/media/`, usando o `expectedFile` do candidato ou atualize ambos os registros com um nome estável. Nenhum caminho do Windows deve ir para `localFile`.
5. Acrescente a ficha no catálogo aprovado, obedecendo `data/image-sources.schema.json`. Use o mesmo `id` do candidato; registre título, autor/instituição, URL, data real ou `null`, período, tipo, licença/condição de uso, URL pública da licença (ou `null` para autorização apenas declarada), `rightsVerification`, eventual `permissionId`, legenda, caminho `/media/...`, dimensões e `verified: true` após conferência. `eventId` é o evento principal; reutilizações estão em `eventIds` do candidato e `mediaIds` dos eventos.
6. Para autorização informada, use `rightsVerification: "user-declaration"` e registre a declaração e o alcance em `data/permissions.json`, referenciado por `permissionId`. Não crie um link de licença pública inexistente. Para domínio público ou licença consultada, use `rightsVerification: "public-source"` e a URL da evidência. O campo `verified` sinaliza identidade conferida e uso elegível; não transforma uma declaração em verificação independente.
7. Atualize situação e nota do candidato e o crédito compacto em `displayCredits` se necessário. O disponível passa a ser mostrado automaticamente. Não é necessário alterar o componente ou o motor.
8. Execute `npm run export`, `npm test` e as capturas. Confira a imagem inteira e a legenda. Para novos IDs, inclua-os em `mediaIds`, no candidato e nas regras do inventário.

Se um arquivo aprovado falhar ao carregar, o componente o retira e mostra seu título e nome esperado. Não há ícone quebrado nem documento inventado. As 16 posições do roteiro permanecem, inclusive pendências explícitas, com três segundos por posição e rasgo entre elas; não são apresentadas como 16 imagens disponíveis.

Os arquivos são pré-carregados. A exportação HTML incorpora somente imagens aprovadas, fontes e estilos; não precisa buscar acervos durante a exibição. O arquivo de exibição e as capturas que contêm a Praia de Imbetiba mantêm atribuição e CC BY-SA 3.0; preserve esses créditos e a licença ao redistribuir a fotografia.
