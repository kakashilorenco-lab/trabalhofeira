import { useEffect, useState } from 'react';
import { Snapshot } from '../engine/Presentation';
import { events } from '../data/events';
import { imageSources, imageCandidates } from '../data/media';

type Props = { snapshot: Snapshot; pause: () => void; go: (index: number) => void; restart: () => void; fullscreen: () => void };
export function Controls({ snapshot, pause, go, restart, fullscreen }: Props) {
  const [open, setOpen] = useState(false);
  const [sources, setSources] = useState(false);
  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() === 'h') setOpen(value => !value);
      if (event.key.toLowerCase() === 's') setSources(value => !value);
      if (event.key === 'Escape') { setOpen(false); setSources(false); }
    };
    window.addEventListener('keydown', keydown);
    return () => window.removeEventListener('keydown', keydown);
  }, []);
  return <>
    <button className="maintenance-trigger" onClick={() => setOpen(value => !value)} aria-label="Abrir controles de apresentação" aria-expanded={open}>H <span>CONTROLES</span></button>
    {open && <aside className="controls" aria-label="Controles de apresentação">
      <div className="controls-heading"><span>MODO DE APRESENTAÇÃO</span><button onClick={() => setOpen(false)} aria-label="Fechar controles">×</button></div>
      <div className="control-actions">
        <button onClick={() => go(snapshot.index - 1)}><kbd>←</kbd> Anterior</button>
        <button onClick={pause}><kbd>ESPAÇO</kbd> {snapshot.paused ? 'Continuar' : 'Pausar'}</button>
        <button onClick={() => go(snapshot.index + 1)}>Próximo <kbd>→</kbd></button>
        <button onClick={fullscreen}><kbd>F</kbd> Tela cheia</button>
        <button onClick={restart}><kbd>R</kbd> Recomeçar</button>
        <button onClick={() => setSources(value => !value)}><kbd>S</kbd> Pesquisa e fontes</button>
      </div>
      <p>A reprodução começa automaticamente. Os controles ficam ocultos durante a exposição.</p>
    </aside>}
    {sources && <aside className="research-panel" aria-label="Situação da pesquisa histórica">
      <button className="close-research" aria-label="Fechar pesquisa" onClick={() => setSources(false)}>×</button>
      <span className="eyebrow">NOTA CURATORIAL</span><h2>A história exige fontes.</h2>
      <p>Edição de pesquisa: {imageSources.length} registros incorporados. A Prefeitura confirma a criação da vila em 29/07/1813 e a elevação a cidade em 1846. As demais referências cronológicas continuam provisórias.</p>
      <p>As condições de uso de {imageSources.filter(source => source.rightsVerification === 'public-source').length} registros foram consultadas em fontes públicas. Para {imageSources.filter(source => source.rightsVerification === 'user-declaration').length}, o responsável pelo projeto informou autorização do Macaé Tips e parceria com SENAI. Essa declaração autoriza o uso nesta apresentação; não foi apresentada como licença pública ou confirmação independente do titular.</p>
      <p>As datas dos materiais são independentes das datas dos acontecimentos. Fotografias posteriores não documentam os séculos XVII e XVIII. Os anos 1978/1980 não são a data de fundação da Petrobras.</p>
      <h3>Acervo consultado</h3>
      <ol>{imageSources.map(source => <li key={source.id} data-source={source.id}><strong>{source.title} · {source.imageDate ?? 'Data não identificada'}</strong>{source.institutionOrAuthor}<br /><a href={source.sourceUrl} target="_blank" rel="noreferrer">Fonte do registro</a> · {source.licenseUrl ? <a href={source.licenseUrl} target="_blank" rel="noreferrer">{source.license}</a> : <span>{source.license}</span>}<br />Tratamento: arquivo original ou conversão técnica proporcional, sem alteração do conteúdo.{source.width < 1200 && ' Resolução limitada; exibido sem ampliação.'}{source.id === 'atlas-1767' && ' Folha de rosto, não uma folha geográfica.'}</li>)}</ol>
      <h3>Pendências identificadas</h3>
      <ol>{imageCandidates.filter(item => !imageSources.some(source => source.id === item.id)).map(item => <li key={item.id}><strong>{item.title}</strong>{item.note}<br /><code>{item.expectedFile}</code></li>)}</ol>
      <h3>Verificação dos acontecimentos</h3>
      <ol>{events.map(event => <li key={event.id}><strong>{event.detail}</strong><span>{event.status}</span></li>)}</ol>
      <p>Fontes e pendências: <code>docs/historical-sources.md</code><br />Catálogo visual: <code>data/image-sources.json</code></p>
    </aside>}
  </>;
}
