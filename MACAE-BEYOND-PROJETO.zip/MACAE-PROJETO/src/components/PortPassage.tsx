import { useCallback, useState } from 'react';
import { Presentation } from '../engine/Presentation';
import { sourceFor, exhibitionCandidatesFor } from '../data/media';
import { clamp, passageProgress } from '../motion/choreography';
import { PaperTearTransition } from './PaperTearTransition';

/** Two identified reproductions, never a fabricated historic panorama. */
export function PortPassage({ engine }: { engine: Presentation }) {
  const [failed, setFailed] = useState<string[]>([]);
  const previous = exhibitionCandidatesFor('porto')[engine.fromSequence % exhibitionCandidatesFor('porto').length];
  const previousRecord = sourceFor(previous.id)!;
  const progress = useCallback(() => {
    const p = passageProgress(engine);
    return p === null ? null : clamp((p - .15) / .64);
  }, [engine]);
  const render = (sequence: number) => {
    const record = sequence === 0 ? previousRecord : sourceFor('estacao-1917')!;
    return <div className="sheet-content authentic-sheet" data-record={record.id}>
      {failed.includes(record.id) ? <span>Registro indisponível · {record.imageDate}</span> :
        <img src={record.localFile} alt={record.title} width={record.width} height={record.height} style={{ maxWidth: record.width, maxHeight: record.height }} onError={() => setFailed(previous => previous.includes(record.id) ? previous : [...previous, record.id])} />}
    </div>;
  };
  return <div className="port-passage" data-visible="false" aria-hidden="true" inert>
    <div className="passage-beam" />
    <div className="passage-document"><PaperTearTransition engine={engine} sceneIndex={5} sequence={1} progress={progress} dramatic renderSheet={render} /></div>
    <div className="passage-credit">{previousRecord.id === 'canal-1846' ? 'Mapa do canal · 1846 · BnF' : 'Praia de Imbetiba · 1941 · A. H. de Oliveira / Halleypo · CC BY-SA 3.0'} <span>→</span> Estação ferroviária · fotografia de 1917 · Fon-Fon / Macaé Tips</div>
  </div>;
}
