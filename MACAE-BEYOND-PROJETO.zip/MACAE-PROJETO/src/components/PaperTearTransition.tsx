import { ReactNode, useId, useLayoutEffect, useRef } from 'react';
import { Presentation } from '../engine/Presentation';
import { MOTION } from '../motion/config';

type Props = { engine: Presentation; sceneIndex: number; sequence: number; renderSheet: (sequence: number) => ReactNode; progress?: () => number | null; dramatic?: boolean };

function noise(index: number, seed: number) {
  let value = Math.imul(index + seed * 97, 0x45d9f3b);
  value = Math.imul(value ^ (value >>> 16), 0x45d9f3b);
  return ((value ^ (value >>> 16)) >>> 0) / 4294967296 * 2 - 1;
}
function smoothNoise(position: number, seed: number) {
  const index = Math.floor(position), fraction = position - index;
  const mix = fraction * fraction * (3 - 2 * fraction);
  return noise(index, seed) * (1 - mix) + noise(index + 1, seed) * mix;
}

/** The new sheet is real DOM underneath the masked, outgoing sheet. No timers. */
export function PaperTearTransition({ engine, sceneIndex, sequence, renderSheet, progress, dramatic = false }: Props) {
  const root = useRef<HTMLDivElement>(null);
  const front = useRef<HTMLDivElement>(null);
  const lift = useRef<HTMLDivElement>(null);
  const edge = useRef<SVGPathElement>(null);
  const shadow = useRef<SVGPathElement>(null);
  const shadowSoft = useRef<SVGPathElement>(null);
  const fold = useRef<SVGPathElement>(null);
  const fibers = useRef<SVGPathElement>(null);
  const gradient = useRef<SVGLinearGradientElement>(null);
  const seamLight = useRef<SVGPathElement>(null);
  const id = useId().replace(/[^a-zA-Z0-9]/g, '');

  useLayoutEffect(() => {
    let previous = -1;
    let previousActive: boolean | undefined;
    const draw = (reduced = false) => {
      const override = progress?.();
      const active = !reduced && (progress ? override !== null && override !== undefined && override < 1 : engine.index === sceneIndex && engine.phase === 'IMAGE_SEQUENCE' && engine.sequence > 0);
      const p = active ? (override ?? engine.tearProgress) : 1;
      if (!root.current || !front.current) return;
      if (active !== previousActive) {
        root.current.dataset.tearing = String(active);
        previousActive = active;
        if (!active) {
          front.current.style.clipPath = 'none';
          if (lift.current) { lift.current.style.clipPath = 'none'; lift.current.style.transform = 'none'; }
          previous = -1;
        }
      }
      if (p !== previous) root.current.dataset.progress = p.toFixed(3);
      if (!active || p === previous) return;
      previous = p;
      const count = dramatic ? 129 : 201;
      const points = Array.from({ length: count }, (_, sample) => {
        const index = sample * 200 / (count - 1);
        const y = -20 + index * 4.2;
        // The rupture starts at the upper right; its tip reaches the lower edge
        // later. Correlated coarse fibres and fine teeth avoid a periodic zipper.
        const arrival = Math.max(0, Math.min(1, y / 800)) * MOTION.PAPER_TEAR_PROPAGATION;
        const local = Math.max(0, Math.min(1, (p - arrival) / (1 - MOTION.PAPER_TEAR_PROPAGATION)));
        const advance = local * local * (3 - 2 * local);
        const irregular = (smoothNoise(index / 28, sequence + 11) * 1.3 + smoothNoise(index / 6, sequence + 57) * .45 + noise(index, sequence) * .18) * MOTION.PAPER_TEAR_IRREGULARITY;
        const x = 1020 - 1150 * advance + irregular;
        return { x, y };
      });
      const line = `M ${points.map(point => `${point.x.toFixed(2)} ${point.y.toFixed(2)}`).join(' L ')}`;
      front.current.style.clipPath = `polygon(-5% -5%, ${points.map(point => `${point.x / 10}% ${point.y / 8}%`).join(',')}, -5% 105%)`;
      edge.current?.setAttribute('d', line);
      seamLight.current?.setAttribute('d', line);
      shadow.current?.setAttribute('d', line);
      shadowSoft.current?.setAttribute('d', line);
      const curl = Math.sin(Math.PI * p) * MOTION.PAPER_TEAR_CURL * (dramatic ? 2.4 : 1);
      // A narrow strip of the actual outgoing print bends toward the viewer.
      // This is a second rendering of the same photograph, never invented pixels.
      const inner = [...points].reverse().map(point => `${(point.x - curl * 1.8) / 10}% ${point.y / 8}%`);
      if (lift.current) {
        lift.current.style.clipPath = `polygon(${points.map(point => `${point.x / 10}% ${point.y / 8}%`).join(',')},${inner.join(',')})`;
        lift.current.style.transform = `translateX(${-Math.sin(Math.PI * p) * (dramatic ? .8 : .22)}%) skewY(${-Math.sin(Math.PI * p) * (dramatic ? .65 : .22)}deg)`;
      }
      const returnPoints = [...points].reverse().map((point, index) => `${(point.x - curl * (.65 + smoothNoise(index / 18, sequence + 8) * .25) - 1.5).toFixed(2)} ${point.y.toFixed(2)}`);
      fold.current?.setAttribute('d', `${line} L ${returnPoints.join(' L ')} Z`);
      const midpoint = points[Math.floor(count / 2)];
      const high = points[Math.floor(count * .9)], low = points[Math.floor(count * .1)];
      const slope = (high.x - low.x) / (high.y - low.y);
      gradient.current?.setAttribute('x1', String(midpoint.x - curl));
      gradient.current?.setAttribute('y1', String(midpoint.y + curl * slope));
      gradient.current?.setAttribute('x2', String(midpoint.x + 2));
      gradient.current?.setAttribute('y2', String(midpoint.y - 2 * slope));
      fibers.current?.setAttribute('d', points.filter((_, index) => index % 4 === 0).map((point, index) => `M ${point.x - 1} ${point.y} l ${1 + (index % 3)} ${index % 2 ? -1 : 2}`).join(' '));
    };
    draw(window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    return engine.subscribeFrame(frame => draw(frame.reducedMotion));
  }, [engine, sceneIndex, sequence, progress, dramatic]);

  return <div ref={root} className={`paper-stack ${dramatic ? 'dramatic-tear' : ''}`} data-tearing="false" data-progress="1">
    <div className="paper-under">{renderSheet(sequence)}</div>
    <div className="paper-front" ref={front} aria-hidden="true" inert>{renderSheet(Math.max(0, sequence - 1))}</div>
    <div className="paper-curl" ref={lift} aria-hidden="true" inert>{renderSheet(Math.max(0, sequence - 1))}</div>
    <svg className="paper-edge" viewBox="0 0 1000 800" preserveAspectRatio="none" aria-hidden="true">
      <defs><linearGradient id={`fold-${id}`} ref={gradient} gradientUnits="userSpaceOnUse"><stop offset="0" stopColor="#8f8270" /><stop offset=".44" stopColor="#e0d4bf" /><stop offset=".86" stopColor="#b9aa91" /><stop offset="1" stopColor="#eee3cd" /></linearGradient></defs>
      <path ref={shadowSoft} className="tear-shadow-soft" style={{ opacity: MOTION.PAPER_TEAR_SHADOW * .36 }} />
      <path ref={shadow} className="tear-shadow" style={{ opacity: MOTION.PAPER_TEAR_SHADOW }} />
      {dramatic && <path ref={seamLight} className="tear-seam-light" />}
      <path ref={fold} fill={`url(#fold-${id})`} />
      <path ref={edge} className="tear-fiber-edge" />
      <path ref={fibers} className="tear-fibers" />
    </svg>
  </div>;
}
