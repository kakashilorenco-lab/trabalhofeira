import { useState, type CSSProperties } from 'react';
import { HistoricalEvent } from '../data/events';
import { exhibitionCandidatesFor, sourceFor, displayCredits } from '../data/media';
import { Presentation } from '../engine/Presentation';
import { PaperTearTransition } from './PaperTearTransition';

export function Graphic({ event, sequence, engine, sceneIndex }: { event: HistoricalEvent; sequence: number; engine: Presentation; sceneIndex: number }) {
  const [failed, setFailed] = useState<string[]>([]);
  const candidates = exhibitionCandidatesFor(event.id);
  const candidate = candidates[sequence % candidates.length];
  const record = candidate && sourceFor(candidate.id);
  const available = record && !failed.includes(record.id);
  const records = candidates.map(item => sourceFor(item.id)).filter(source => source !== undefined);
  const nativeWidth = Math.max(0, ...records.map(source => source.width));
  const compact = nativeWidth > 0 && nativeWidth < 700 && records.every(source => source.recordType.startsWith('fotografia'));
  const renderSheet = (sheetSequence: number) => {
    const item = candidates[sheetSequence % candidates.length];
    const source = item && sourceFor(item.id);
    if (source && !failed.includes(source.id)) return <div className="sheet-content authentic-sheet" data-record={source.id}>
      <img src={source.localFile} alt={source.title} width={source.width} height={source.height}
        style={{ maxWidth: source.width, maxHeight: source.height }} loading="eager" decoding="async"
        onError={() => setFailed(previous => previous.includes(source.id) ? previous : [...previous, source.id])} />
    </div>;
    return <div className="sheet-content missing-sheet" data-record={item?.id}>
      <span className="missing-label">{source ? 'ARQUIVO INDISPONÍVEL' : item?.status === 'rights-pending' ? 'REUTILIZAÇÃO EM VERIFICAÇÃO' : 'IMAGEM PENDENTE'}</span>
      <strong>{item?.title ?? 'Registro histórico não localizado'}</strong>
      <span className="missing-detail">{item?.status === 'rights-pending' ? 'A reprodução aguarda confirmação dos direitos de uso.' : 'O arquivo original ainda não está disponível neste ambiente.'}</span>
      <code>{item?.expectedFile}</code>
    </div>;
  };
  return <figure className={`artifact ${available ? 'authentic' : 'pending-media'} ${compact ? 'compact-media' : ''}`} style={{ '--native-width': `${nativeWidth}px` } as CSSProperties} aria-label={available ? record.title : `Pendente: ${candidate?.title}`}>
    <PaperTearTransition engine={engine} sceneIndex={sceneIndex} sequence={sequence} renderSheet={renderSheet} />
    <figcaption>{available ? <>
      <span className="media-caption-title">{record.caption}{event.id === 'vila' && record.id === 'canal-1846' ? ' · registro posterior a 1813' : ''}{event.id === 'pescadores' && record.id === 'panorama' ? ' · posterior aos séculos XVII–XVIII' : ''}</span>
      <span className="media-credit">{displayCredits[record.id] ?? `${record.institutionOrAuthor} · ${record.license}`}</span>
    </> : <span>Espaço reservado ao registro identificado · fontes e pendências: tecla S</span>}</figcaption>
    {candidates.length > 1 && <div className="media-counter" aria-label={`Registro ${sequence + 1} de ${candidates.length}`}>{String(sequence + 1).padStart(2, '0')} <i /> {String(candidates.length).padStart(2, '0')}</div>}
  </figure>;
}
