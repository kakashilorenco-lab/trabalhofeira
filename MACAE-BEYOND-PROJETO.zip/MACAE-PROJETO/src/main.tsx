import React from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource/cormorant-garamond/latin-500.css';
import '@fontsource/cormorant-garamond/latin-500-italic.css';
import '@fontsource/cormorant-garamond/latin-600.css';
import '@fontsource/manrope/latin-400.css';
import '@fontsource/manrope/latin-500.css';
import '@fontsource/manrope/latin-600.css';
import { App } from './App';
import './styles.css';
import './brief.css';
import './exhibition.css';
import './beyond.css';

createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);
