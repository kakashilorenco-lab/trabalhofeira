import { events } from './events';
import { exhibitionCandidatesFor } from './media';
import { MOTION } from '../motion/config';

// Display copy is deliberately separate from the complete historical research.
// Vila (1813) and city (1846) confirmed by the municipal history page.
// Other supplied dates remain provisional; see docs/historical-sources.md.
export const displayCopy: Record<string, { period: string | null; title: string[] }> = {
  pescadores: { period: 'SÉCULOS XVII–XVIII', title: ['Vila dos', 'pescadores'] },
  vila: { period: '29 DE JULHO DE 1813', title: ['Criação da vila', 'São João', 'de Macaé'] },
  cidade: { period: '1846', title: ['Macaé se torna', 'cidade'] },
  porto: { period: '1844 / 1875', title: ['Porto da', 'Imbetiba'] },
  ferrovia: { period: '1875', title: ['Chegada da', 'ferrovia', 'Vila da Imbetiba'] },
  petroleo: { period: '1978–1980', title: ['Macaé, cidade', 'do petróleo'] },
  formacao: { period: '1995 / 1996 – 2008', title: ['Construção do', 'SESI / SENAI'] },
};

export const SCENES = [
  { duration: MOTION.INTRO_DURATION, sequences: 1 },
  ...events.map(event => {
    const sequences = Math.max(1, exhibitionCandidatesFor(event.id).length);
    return {
      duration: sequences > 1 ? sequences * MOTION.IMAGE_HOLD_DURATION : MOTION.SECTION_HOLD_DURATION * MOTION.SECTION_HOLD_MULTIPLIER,
      sequences,
    };
  }),
  { duration: MOTION.OUTRO_DURATION, sequences: 1 },
];

export const nominalCycleDuration = SCENES.reduce((total, scene) => total + scene.duration + (scene.sequences - 1) * MOTION.PAPER_TEAR_DURATION, 0)
  + (SCENES.length - 1) * (MOTION.SCROLL_BASE_TRAVEL_MS / MOTION.SCROLL_SPEED_MULTIPLIER + MOTION.RESUME_DURATION)
  + MOTION.PORT_PASSAGE_DURATION - MOTION.SCROLL_BASE_TRAVEL_MS / MOTION.SCROLL_SPEED_MULTIPLIER
  + MOTION.RESTART_DURATION;
