import rawSources from '../../data/image-sources.json' with { type: 'json' };
import rawCandidates from '../../data/image-candidates.json' with { type: 'json' };
import { events } from './events';

export type ImageSource = {
  id: string;
  eventId: string;
  title: string;
  institutionOrAuthor: string;
  sourceUrl: string;
  imageDate: string | null;
  historicalPeriod: string;
  recordType: string;
  license: string;
  licenseUrl: string | null;
  rightsVerification: 'public-source' | 'user-declaration';
  permissionId?: string;
  caption: string;
  localFile: string;
  width: number;
  height: number;
  verified: boolean;
};

export const imageSources = rawSources as ImageSource[];
// Compact exhibition credit; complete authorship, rights and URLs remain above
// in the catalogue and in the S panel, including attribution for CC BY-SA.
export const displayCredits: Record<string, string> = {
  'atlas-1767': 'Manoel Vieira Leão · Acervo da Fundação Biblioteca Nacional – Brasil',
  'canal-1846': 'Arquivo Militar · Bibliothèque nationale de France · domínio público',
  'sodre-xx': 'Arquivo Nacional · fundo Correio da Manhã · domínio público',
  'praia-1941': 'Aristides Henriques de Oliveira · acervo Halleypo · CC BY-SA 3.0',
  'planta-xix': 'Biblioteca Nacional / Solar dos Mellos · reprodução enviada',
  panorama: 'Fotógrafo não identificado · reprodução ClimaOnline',
  'estacao-1917': 'Fon-Fon · reprodução Macaé Tips · domínio público',
  'patio-1960': 'Autor desconhecido · cessão João Silva / Macaé Tips',
  'guarita-1978': 'Fotógrafo não identificado · compilação atribuída a Izio Enco',
  'obras-1978': 'Fotógrafo não identificado · compilação atribuída a Izio Enco',
  'instalacoes-1978': 'Fotógrafo não identificado · compilação atribuída a Izio Enco',
  'senai-2015': 'Divulgação — Mobilidade Urbana / Prefeitura de Macaé',
};
export type ImageCandidate = {
  id: string; title: string; eventIds: string[]; expectedFile: string;
  sourceUrl: string; status: string; note: string;
};
export const imageCandidates = rawCandidates as ImageCandidate[];
export const sourceFor = (id: string) => imageSources.find(source => source.id === id && source.verified && source.localFile && source.license);
// Begin with the usable records; preserve named pending slots afterwards.
export const candidatesFor = (eventId: string) => (events.find(event => event.id === eventId)?.mediaIds ?? [])
  .map(id => imageCandidates.find(item => item.id === id && item.eventIds.includes(eventId)))
  .filter((item): item is ImageCandidate => Boolean(item))
  .sort((a, b) => Number(Boolean(sourceFor(b.id))) - Number(Boolean(sourceFor(a.id))));
// Keep unresolved research in the catalogue/S panel, not as an empty TV slide.
export const exhibitionCandidatesFor = (eventId: string) => {
  const candidates = candidatesFor(eventId);
  const available = candidates.filter(item => sourceFor(item.id));
  return available.length ? available : candidates.slice(0, 1);
};
export function mediaFor(ids: string[]) {
  return ids.map(id => imageSources.find(source => source.id === id))
    .filter((item): item is ImageSource => Boolean(item?.verified && item.localFile && item.license));
}
