export type HistoricalEvent = {
  id: string;
  chapter: string;
  period: string;
  title: string[];
  description: string;
  note: string;
  status: string;
  graphic: 'tides' | 'village' | 'city' | 'port' | 'rail' | 'oil' | 'learning';
  word: string;
  detail: string;
  duration: number;
  mediaIds: string[];
};

// Research status updated 20 October 2026; see docs/historical-sources.md.
export const events: HistoricalEvent[] = [
  {
    id: 'pescadores', chapter: 'AS ORIGENS', period: 'SÉCULOS XVII — XVIII',
    title: ['Antes da cidade,', 'as águas.'],
    description: 'As ocupações do território e as atividades ligadas à pesca abrem este percurso pela formação de Macaé.',
    note: 'A história indígena e as diferentes ocupações da região integram a pesquisa em andamento.',
    status: 'Recorte temporal fornecido · pesquisa pendente',
    graphic: 'tides', word: 'ÁGUA', detail: 'VILA DOS PESCADORES', duration: 24000, mediaIds: ['atlas-1767', 'planta-xix', 'panorama'],
  },
  {
    id: 'vila', chapter: 'UM NOVO NOME NO MAPA', period: '29 JULHO 1813',
    title: ['Vila de São João', 'de Macaé.'],
    description: 'A criação da vila marca a formação administrativa de Macaé. O território passa a se organizar em uma nova condição política.',
    note: 'Data e denominação confirmadas na página História, da Prefeitura de Macaé. O alvará original não foi consultado.',
    status: '29/07/1813 confirmado em fonte municipal',
    graphic: 'village', word: '1813', detail: 'A FORMAÇÃO DA VILA', duration: 17000, mediaIds: ['planta-xix', 'canal-1846'],
  },
  {
    id: 'cidade', chapter: 'A CIDADE SE FORMA', period: '1846',
    title: ['De vila', 'a cidade.'],
    description: 'A elevação à categoria de cidade é um marco próprio da história administrativa de Macaé, distinto da criação da vila.',
    note: 'A Prefeitura confirma o ano de 1846, citando Knauss, História e Memória (2001), p. 86. Dia e mês não foram verificados.',
    status: '1846 confirmado em fonte municipal · dia e mês não verificados',
    graphic: 'city', word: 'CIDADE', detail: 'UM MARCO ADMINISTRATIVO', duration: 17000, mediaIds: ['sodre-xx', 'panorama'],
  },
  {
    id: 'porto', chapter: 'UMA CIDADE EM CONEXÃO', period: '1844 / 1875',
    title: ['O porto', 'da Imbetiba.'],
    description: 'O porto conduz o olhar para as relações entre o mar, o comércio e o desenvolvimento regional.',
    note: '1844 e 1875 são referências do roteiro inicial. Os fatos correspondentes a cada ano ainda precisam de comprovação.',
    status: 'Anos de referência · vínculo com os fatos pendente',
    graphic: 'port', word: 'MAR', detail: 'PORTO DA IMBETIBA', duration: 18000, mediaIds: ['praia-1941', 'canal-1846'],
  },
  {
    id: 'ferrovia', chapter: 'CAMINHOS QUE SE ENCONTRAM', period: '1875',
    title: ['Entre o porto', 'e os trilhos.'],
    description: 'A ferrovia integra a narrativa sobre transporte, atividade portuária e transformação urbana na região da Imbetiba.',
    note: 'O roteiro indica 1875. O Macaé Tips cita estação em 1873 e trecho em 1874; a divergência exige conferência em fonte primária.',
    status: '1875 no roteiro · fonte secundária cita 1873/1874 · conferência pendente',
    graphic: 'rail', word: 'TRILHOS', detail: 'FERROVIA · VILA DA IMBETIBA', duration: 18000, mediaIds: ['estacao-1917', 'patio-1960', 'estacao-1978'],
  },
  {
    id: 'petroleo', chapter: 'OUTRA ESCALA DE TRANSFORMAÇÃO', period: '1978 / 1980',
    title: ['Macaé e', 'o petróleo.'],
    description: 'A expansão das atividades petrolíferas ligadas a Macaé inaugura outro capítulo nas relações entre trabalho, cidade e mar.',
    note: 'Estes anos se referem ao recorte proposto para a expansão local. Não representam a fundação da Petrobras.',
    status: 'Marcos locais de 1978 e 1980 em verificação',
    graphic: 'oil', word: 'ENERGIA', detail: 'PETROBRAS E MACAÉ', duration: 19000, mediaIds: ['guarita-1978', 'obras-1978', 'instalacoes-1978'],
  },
  {
    id: 'formacao', chapter: 'O FUTURO TAMBÉM SE APRENDE', period: '1995 / 1996 — 2008',
    title: ['Formar pessoas.', 'Abrir caminhos.'],
    description: 'SESI e SENAI encerram este percurso com o tema da formação e sua relação com as transformações do trabalho na cidade.',
    note: 'Construção, inauguração, expansão e unidades precisam ser distinguidas nas fontes institucionais. Os anos são provisórios.',
    status: 'Marcos institucionais e unidades em verificação',
    graphic: 'learning', word: 'AMANHÃ', detail: 'CONSTRUÇÃO E EXPANSÃO · SESI / SENAI', duration: 20000, mediaIds: ['senai-2015'],
  },
];

export const fishingPhases = [
  { word: 'TERRITÓRIO', title: 'Antes dos limites.', line: 'A formação da região começa antes de sua organização como vila.' },
  { word: 'ÁGUA', title: 'A vida junto às águas.', line: 'A pesca é o fio condutor deste primeiro capítulo do roteiro.' },
  { word: 'MEMÓRIA', title: 'O que o tempo preserva.', line: 'Mapas, registros e vozes locais são caminhos para uma história documentada.' },
];
