import { MOTION } from './config';
import { Phase } from '../engine/Presentation';

type Crystal = { x: number; y: number; vx: number; vy: number; age: number; life: number; size: number; angle: number };
export class IceField {
  private context: CanvasRenderingContext2D;
  private particles: Crystal[] = [];
  private carry = 0;
  private seed = 1709;
  private energy = 0.15;
  private sprite: HTMLCanvasElement;
  readonly band: number;
  readonly scale: number;
  get count() { return this.particles.length; }
  constructor(private canvas: HTMLCanvasElement, private width: number, private height: number) {
    this.scale = Math.max(0.6, width / 1920);
    this.band = Math.ceil(MOTION.ICE_BAND_WIDTH * this.scale);
    canvas.width = this.band;
    canvas.height = height;
    canvas.style.width = `${this.band}px`;
    const context = canvas.getContext('2d', { alpha: true });
    if (!context) throw new Error('Canvas 2D unavailable');
    this.context = context;
    this.sprite = document.createElement('canvas');
    this.sprite.width = this.sprite.height = 96;
    const mist = this.sprite.getContext('2d')!;
    const gradient = mist.createRadialGradient(48, 48, 0, 48, 48, 48);
    gradient.addColorStop(0, 'rgba(238,247,250,.45)');
    gradient.addColorStop(0.35, 'rgba(238,247,250,.18)');
    gradient.addColorStop(1, 'rgba(238,247,250,0)');
    mist.fillStyle = gradient; mist.fillRect(0, 0, 96, 96);
  }
  private random() { this.seed = (1664525 * this.seed + 1013904223) >>> 0; return this.seed / 4294967296; }
  reset() { this.particles.length = 0; this.carry = 0; }
  draw(delta: number, time: number, head: { x: number; y: number }, cameraY: number, phase: Phase, reduced: boolean) {
    const ctx = this.context;
    ctx.clearRect(0, 0, this.band, this.height);
    if (reduced) { this.reset(); this.canvas.dataset.particles = '0'; return; }
    const traveling = phase === 'TRAVELING' || phase === 'APPROACHING_SECTION';
    const tearing = phase === 'IMAGE_SEQUENCE';
    const target = traveling ? (phase === 'APPROACHING_SECTION' ? .72 : 1) : tearing ? 0.05 : 0.1;
    this.energy += (target - this.energy) * (1 - Math.exp(-delta / 280));
    const dt = delta / 1000;
    this.canvas.style.left = `${head.x}px`;
    const x = this.band / 2;
    const y = head.y - cameraY;
    this.carry += dt * MOTION.ICE_PARTICLE_DENSITY * this.energy;
    while (this.carry >= 1) {
      this.carry--;
      if (this.particles.length >= MOTION.ICE_PARTICLE_LIMIT) continue;
      this.particles.push({ x: head.x + (this.random() - .5) * 7 * this.scale, y: head.y + (this.random() - .5) * 48 * this.scale, vx: (this.random() - .5) * 12 * this.scale, vy: (this.random() < .22 ? 8 : -(6 + this.random() * 14)) * this.scale, age: 0, life: 0.7 + this.random() * 1.1, size: (.45 + this.random() * .85) * this.scale, angle: this.random() * Math.PI });
    }
    ctx.globalAlpha = MOTION.ICE_MIST_OPACITY * this.energy;
    // Three small cached radial sprites; no full-screen blur or particle textures.
    for (let i = 0; i < 3; i++) {
      const drift = Math.sin(time * .0004 + i * 2.3) * 8 * this.scale;
      const spread = (42 + i * 9) * this.scale;
      ctx.drawImage(this.sprite, x - spread / 2 + drift, y - (40 + i * 31) * this.scale, spread, 110 * this.scale);
    }
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const particle = this.particles[i];
      particle.age += dt;
      if (particle.age >= particle.life) { this.particles.splice(i, 1); continue; }
      particle.x += particle.vx * dt * MOTION.ICE_PARTICLE_SPEED;
      particle.y += particle.vy * dt * MOTION.ICE_PARTICLE_SPEED;
      const alpha = Math.sin(Math.PI * particle.age / particle.life) * .65;
      const cy = particle.y - cameraY;
      if (cy < -20 || cy > this.height + 20) continue;
      ctx.globalAlpha = alpha;
      ctx.fillStyle = '#f5fbff';
      const wobble = Math.sin(particle.age * 3 + particle.angle) * 3 * this.scale;
      const px = particle.x - head.x + this.band / 2 + wobble;
      const r = particle.size;
      ctx.beginPath(); ctx.moveTo(px, cy - r * 1.7); ctx.lineTo(px + r * .65, cy); ctx.lineTo(px, cy + r * 1.7); ctx.lineTo(px - r * .65, cy); ctx.closePath(); ctx.fill();
    }
    ctx.globalAlpha = 1;
    this.canvas.dataset.particles = String(this.particles.length);
    this.canvas.dataset.energy = this.energy.toFixed(2);
  }
}
