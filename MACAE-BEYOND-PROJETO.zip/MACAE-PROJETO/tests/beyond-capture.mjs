import { chromium } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';
const out = process.argv[2] || 'docs/beyond/round-1';
await mkdir(out, { recursive: true });
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox','--disable-dev-shm-usage'] });
try {
  const page = await browser.newPage({viewport:{width:1920,height:1080}});
  const errors = [], geometry = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.goto('http://127.0.0.1:5173');
  await page.waitForFunction(()=>window.__exhibition);
  await page.evaluate(()=>document.fonts.ready);
  const capture = async name => {
    await page.waitForTimeout(180);
    await page.screenshot({path:`${out}/${name}.png`,style:'.pause-notice {visibility:hidden}'});
  };
  for (let i=0;i<9;i++) {
    await page.evaluate(i=>{const e=window.__exhibition.engine;e.seek(i);e.pause(false);e.elapsed=i===0?3600:1500;e.tick(0);e.pause(true);},i);
    await page.waitForFunction(i=>Math.abs(scrollY-i*innerHeight)<1,i);
    await capture(`scene-${i}`);
    geometry.push(await page.locator('.scene').nth(i).evaluate(el=>({scene:el.dataset.scene,boxes:[...el.querySelectorAll('h1,h2,.event-period,figcaption,.artifact')].map(e=>{const r=e.getBoundingClientRect();return {name:e.className||e.tagName,x:r.x,y:r.y,right:r.right,bottom:r.bottom}})})));
  }
  for (const p of [.08,.25,.5,.7,.92]) {
    await page.evaluate(p=>{const e=window.__exhibition.engine;e.pause(false);e.seek(4);e.tick(5300);e.go(5);e.elapsed=e.travelMs*p;e.tick(0);e.pause(true);},p);
    await capture(`passage-${p}`);
  }
  for (const [scene,elapsed,name] of [[0,1150,'opening-light'],[2,350,'date-arrival'],[6,450,'oil-arrival']]) {
    await page.evaluate(({scene,elapsed})=>{const e=window.__exhibition.engine;e.pause(false);e.seek(scene);e.elapsed=elapsed;e.tick(0);e.pause(true);},{scene,elapsed});
    await capture(name);
  }
  await page.setViewportSize({width:3840,height:2160});
  await page.evaluate(()=>{const e=window.__exhibition.engine;e.seek(7);e.elapsed=1500;});
  await page.waitForFunction(()=>Math.abs(scrollY-7*2160)<1);
  await page.waitForTimeout(400);
  await capture('senai-4k');
  await writeFile(`${out}/inspection.json`,JSON.stringify({errors,geometry},null,2));
  console.log(JSON.stringify({errors,scenes:geometry.length,output:out}));
  if(errors.length) throw Error(errors.join('\n'));
} finally {await browser.close();}
