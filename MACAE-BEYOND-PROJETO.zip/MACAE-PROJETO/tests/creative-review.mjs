import { chromium } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';
const directory = process.argv[2] || 'docs/creative/pass-2';
await mkdir(directory, { recursive: true });
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
try {
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('http://127.0.0.1:5173');
  await page.waitForFunction(() => window.__exhibition);
  await page.evaluate(() => document.fonts.ready);
  const capture = async name => {
    await page.waitForTimeout(100);
    await page.screenshot({ path: `${directory}/${name}.png`, style: '.pause-notice { visibility: hidden }' });
  };
  for (const [label, progress] of [['begin', .12], ['middle', .5], ['end', .88], ['settled', 1]]) {
    await page.evaluate(progress => {
      const engine = window.__exhibition.engine;
      engine.pause(false); engine.seek(4);
      const hold = engine.scenes[4].duration / engine.scenes[4].sequences;
      engine.elapsed = hold + progress * 1200;
      engine.tick(0); engine.pause(true);
    }, progress);
    await capture(`tear-${label}`);
  }
  // Real playing travel first builds particles. Freeze after approaching starts.
  await page.evaluate(() => {
    const engine = window.__exhibition.engine;
    engine.pause(false); engine.seek(3); engine.go(4);
  });
  await page.waitForFunction(() => window.__exhibition.engine.phase === 'APPROACHING_SECTION');
  await page.evaluate(() => window.__exhibition.engine.pause(true));
  await capture('travel-frost');
  await page.evaluate(() => {
    const engine = window.__exhibition.engine;
    engine.pause(false); engine.seek(4); engine.tick(180); engine.pause(true);
  });
  await capture('arrival-pulse');
  await page.setViewportSize({ width: 3840, height: 2160 });
  await page.evaluate(() => window.__exhibition.seek(7));
  await page.waitForFunction(() => innerHeight === 2160 && Math.abs(document.querySelector('[data-scene="formacao"]').getBoundingClientRect().top) < 1);
  await page.waitForTimeout(500);
  await capture('senai-4k');
  await writeFile(`${directory}/browser-results.json`, JSON.stringify({ errors, viewport: '1920x1080 + 3840x2160', transition: 'real engine at 12%, 50%, 88% and completion', frost: 'real travel paused at approach' }, null, 2));
  if (errors.length) throw new Error(errors.join('\n'));
} finally { await browser.close(); }
