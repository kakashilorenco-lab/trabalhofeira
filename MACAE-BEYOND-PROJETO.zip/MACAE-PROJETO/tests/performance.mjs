import { chromium } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
try {
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('http://127.0.0.1:5173');
  await page.waitForLoadState('networkidle');
  await page.evaluate(() => document.fonts.ready);
  const timing = await page.evaluate(() => new Promise(resolve => {
    const intervals = [];
    const engine = window.__exhibition.engine;
    engine.seek(1); engine.elapsed = Math.max(0, engine.scenes[1].duration / engine.scenes[1].sequences - 1500);
    const started = performance.now(); let last = started;
    const sample = now => {
      intervals.push(now - last); last = now;
      if (now - started < 6000) requestAnimationFrame(sample);
      else {
        engine.seek(4); engine.tick(5300); engine.go(5);
        const end = now + 3600;
        const travel = time => {
          intervals.push(time - last); last = time;
          if (time < end) requestAnimationFrame(travel);
          else resolve(intervals);
        };
        requestAnimationFrame(travel);
      }
    };
    requestAnimationFrame(sample);
  }));
  const sorted = [...timing].sort((a, b) => a - b);
  const cdp = await page.context().newCDPSession(page);
  await cdp.send('Performance.enable');
  await page.evaluate(() => window.__exhibition.speed(60));
  await page.waitForFunction(() => window.__exhibition.engine.cycles >= 2, undefined, { timeout: 18000 });
  await cdp.send('HeapProfiler.collectGarbage');
  const before = await cdp.send('Performance.getMetrics');
  const initial = await page.evaluate(() => ({ elements: document.querySelectorAll('*').length, listeners: window.__exhibition.engine.listenerCount }));
  await page.waitForFunction(() => window.__exhibition.engine.cycles >= 12, undefined, { timeout: 45000 });
  await cdp.send('HeapProfiler.collectGarbage');
  const after = await cdp.send('Performance.getMetrics');
  const final = await page.evaluate(() => ({ elements: document.querySelectorAll('*').length, listeners: window.__exhibition.engine.listenerCount, particles: Number(document.querySelector('.ice-atmosphere').dataset.particles), cycles: window.__exhibition.engine.cycles, facets: document.querySelector('.timeline-crystals').children.length }));
  const metric = (collection, name) => collection.metrics.find(metric => metric.name === name)?.value;
  const result = {
    viewport: '1920x1080', normalSpeedSamplingMs: 9600, sampledFrames: timing.length,
    averageFps: +(1000 / (timing.reduce((total, value) => total + value, 0) / timing.length)).toFixed(1),
    medianFrameMs: +sorted[Math.floor(sorted.length * .5)].toFixed(2), p95FrameMs: +sorted[Math.floor(sorted.length * .95)].toFixed(2), maxFrameMs: +sorted.at(-1).toFixed(2),
    soak: { speedMultiplier: 60, warmupCycles: 2, measuredAdditionalCycles: 10, initial, final, jsHeapBeforeBytes: metric(before, 'JSHeapUsedSize'), jsHeapAfterBytes: metric(after, 'JSHeapUsedSize') }, errors,
  };
  assert.equal(final.listeners, 8); assert.equal(initial.listeners, final.listeners);
  assert.ok(Math.abs(initial.elements - final.elements) <= 5, 'DOM must not accumulate across loops');
  assert.ok(final.particles <= 48); assert.ok(final.facets < 350); assert.deepEqual(errors, []);
  const output = process.argv[2] || 'docs/refinement';
  await mkdir(output, { recursive: true });
  await writeFile(`${output}/performance-results.json`, JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result));
} finally { await browser.close(); }
