import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
try {
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  const errors = [], external = [], failed = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('response', response => { if (response.status() >= 400) failed.push(`${response.status()} ${response.url()}`); });
  await page.route('**/*', route => {
    if (new URL(route.request().url()).origin === 'http://127.0.0.1:4173') return route.continue();
    external.push(route.request().url()); return route.abort();
  });
  await page.goto('http://127.0.0.1:4173/?speed=30');
  await page.evaluate(() => document.fonts.ready);
  assert.equal(await page.evaluate(() => Boolean(window.__exhibition)), false, 'Development inspection must not exist in production');
  await page.waitForFunction(() => document.querySelector('.exhibition').dataset.index === '8', undefined, { timeout: 15000 });
  await page.waitForFunction(() => document.querySelector('.exhibition').dataset.phase === 'RESTARTING');
  await page.waitForFunction(() => document.querySelector('.exhibition').dataset.index === '0');
  assert.deepEqual(errors, []); assert.deepEqual(external, []); assert.deepEqual(failed, []);
  console.log(JSON.stringify({ production: 'passed', viewport: '1920x1080', loop: 'completed', externalRequests: external.length, failedResponses: failed.length, browserErrors: errors.length, fontsReady: true }));
} finally { await browser.close(); }
