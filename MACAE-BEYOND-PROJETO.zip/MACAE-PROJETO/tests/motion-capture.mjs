import { chromium } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const round = process.argv[2] || 'round-1';
const output = resolve(`docs/refinement/${round}`);
const framesPath = resolve(`/workspace/scratch/macae-motion/${round}`);
await mkdir(output, { recursive: true });
await mkdir(framesPath, { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
try {
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('http://127.0.0.1:5173');
  await page.waitForLoadState('networkidle');
  await page.evaluate(() => document.fonts.ready);
  await page.evaluate(() => { window.__exhibition.engine.seek(1); window.__exhibition.engine.pause(true); });
  await page.waitForTimeout(300);
  await page.screenshot({ path: `${output}/tear-00-before.png`, style: '.pause-notice{visibility:hidden}' });
  for (const progress of [.12, .32, .5, .72, .9]) {
    await page.evaluate(p => {
      const engine = window.__exhibition.engine;
      engine.paused = false;
      const scene = engine.scenes[1];
      const hold = scene.duration / scene.sequences;
      const tear = (engine.sceneDuration - scene.duration) / (scene.sequences - 1);
      engine.elapsed = hold + p * tear;
      engine.tick(0);
      engine.pause(true);
    }, progress);
    await page.waitForTimeout(100);
    await page.screenshot({ path: `${output}/tear-${String(Math.round(progress * 100)).padStart(2,'0')}.png`, style: '.pause-notice{visibility:hidden}' });
  }
  await page.evaluate(() => { const engine = window.__exhibition.engine; const scene = engine.scenes[1]; const tear = (engine.sceneDuration - scene.duration) / (scene.sequences - 1); engine.paused = false; engine.elapsed = scene.duration / scene.sequences + tear + 100; engine.tick(0); engine.pause(true); });
  await page.waitForTimeout(100);
  await page.screenshot({ path: `${output}/tear-99-after.png`, style: '.pause-notice{visibility:hidden}' });

  // Record actual browser paints, in real time, rather than synthesising a video
  // from the controlled intermediate screenshots above.
  const cdp = await page.context().newCDPSession(page);
  const frames = [];
  const writes = [];
  cdp.on('Page.screencastFrame', event => {
    const file = `${framesPath}/${String(frames.length).padStart(5, '0')}.jpg`;
    frames.push({ file, timestamp: event.metadata.timestamp });
    writes.push(writeFile(file, Buffer.from(event.data, 'base64')));
    void cdp.send('Page.screencastFrameAck', { sessionId: event.sessionId });
  });
  await page.evaluate(() => { const engine = window.__exhibition.engine; engine.pause(false); engine.seek(1); engine.elapsed = Math.max(0, engine.scenes[1].duration / engine.scenes[1].sequences - 1800); });
  await cdp.send('Page.startScreencast', { format: 'jpeg', quality: 80, maxWidth: 1920, maxHeight: 1080, everyNthFrame: 2 });
  await page.waitForTimeout(11700);
  await cdp.send('Page.stopScreencast');
  await Promise.all(writes);
  await writeFile(`${framesPath}/frames.txt`, frames.map((frame, i) => `file '${frame.file}'\nduration ${i + 1 < frames.length ? Math.max(.005, frames[i + 1].timestamp - frame.timestamp) : .04}`).join('\n'));
  const video = spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', `${framesPath}/frames.txt`, '-fps_mode', 'vfr', '-c:v', 'libx264', '-preset', 'fast', '-crf', '20', '-pix_fmt', 'yuv420p', `${output}/paper-tear-realtime.mp4`], { encoding: 'utf8' });
  if (video.status !== 0) throw new Error(video.stderr);

  // A separate real-time trip validates the shortened travel and cold wake.
  await page.evaluate(() => { const engine = window.__exhibition.engine; engine.seek(1); engine.go(2); });
  await page.waitForTimeout(1050);
  await page.evaluate(() => window.__exhibition.engine.pause(true));
  await page.screenshot({ path: `${output}/ice-travel.png`, style: '.pause-notice{visibility:hidden}' });
  const ice = await page.locator('.ice-atmosphere').evaluate(canvas => ({ particles: canvas.dataset.particles, energy: canvas.dataset.energy, width: canvas.width }));
  const iceStart = frames.length;
  await page.evaluate(() => { const engine = window.__exhibition.engine; engine.pause(false); engine.seek(1); engine.go(2); });
  await cdp.send('Page.startScreencast', { format: 'jpeg', quality: 80, maxWidth: 1920, maxHeight: 1080, everyNthFrame: 2 });
  await page.waitForTimeout(2500);
  await cdp.send('Page.stopScreencast');
  await Promise.all(writes);
  const iceFrames = frames.slice(iceStart);
  await writeFile(`${framesPath}/ice-frames.txt`, iceFrames.map((frame, i) => `file '${frame.file}'\nduration ${i + 1 < iceFrames.length ? Math.max(.005, iceFrames[i + 1].timestamp - frame.timestamp) : .04}`).join('\n'));
  const iceVideo = spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', `${framesPath}/ice-frames.txt`, '-fps_mode', 'vfr', '-c:v', 'libx264', '-preset', 'fast', '-crf', '20', '-pix_fmt', 'yuv420p', `${output}/ice-travel-realtime.mp4`], { encoding: 'utf8' });
  if (iceVideo.status !== 0) throw new Error(iceVideo.stderr);
  await writeFile(`${output}/capture-results.json`, JSON.stringify({ viewport: '1920x1080', tearFrames: 7, realtimeVideoFrames: iceStart, realtimeVideoSeconds: frames[iceStart - 1].timestamp - frames[0].timestamp, iceTravelVideoFrames: iceFrames.length, ice, errors }, null, 2));
  console.log(JSON.stringify({ round, frames: frames.length, ice, errors }));
} finally { await browser.close(); }
