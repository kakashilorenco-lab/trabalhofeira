import { chromium } from '@playwright/test';
import { mkdir, writeFile, copyFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { resolve } from 'node:path';

const output = resolve(process.argv[2] || 'docs/acervo');
const temp = resolve('/workspace/scratch/macae-beyond-cycle');
await mkdir(output, { recursive: true });
await mkdir(temp, { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
try {
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  const errors = [], external = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('request', request => { if (/^https?:/.test(request.url()) && !request.url().startsWith('http://127.0.0.1:5173')) external.push(request.url()); });
  await page.addInitScript(() => {
    window.__briefLog = [];
    let previous = '';
    new MutationObserver(() => {
      const root = document.querySelector('.exhibition');
      if (!root) return;
      const state = { timestamp: Date.now(), index: Number(root.dataset.index), phase: root.dataset.phase };
      const key = state.index + ':' + state.phase;
      if (key !== previous) { window.__briefLog.push(state); previous = key; }
    }).observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-index', 'data-phase'] });
  });
  const cdp = await page.context().newCDPSession(page);
  const frames = [], writes = [];
  cdp.on('Page.screencastFrame', event => {
    const file = `${temp}/${String(frames.length).padStart(5, '0')}.jpg`;
    frames.push({ file, timestamp: event.metadata.timestamp * 1000 });
    writes.push(writeFile(file, Buffer.from(event.data, 'base64')));
    void cdp.send('Page.screencastFrameAck', { sessionId: event.sessionId });
  });
  await cdp.send('Page.startScreencast', { format: 'jpeg', quality: 85, maxWidth: 1920, maxHeight: 1080, everyNthFrame: 8 });
  await page.goto('http://127.0.0.1:5173');
  // No keyboard, seek, speed parameter or pause: one complete normal-speed loop.
  await page.waitForFunction(() => window.__exhibition?.engine.cycles >= 1 && document.querySelector('.exhibition')?.dataset.phase === 'INTRO', undefined, { timeout: 115000 });
  await cdp.send('Page.stopScreencast');
  await Promise.all(writes);
  const states = await page.evaluate(() => window.__briefLog);
  const start = states[0].timestamp;
  const end = states.filter(state => state.index === 0 && state.phase === 'INTRO').at(-1).timestamp;
  const ordered = states.filter((state, index) => index === 0 || state.index !== states[index - 1].index).map(state => state.index);
  const seconds = (end - start) / 1000;
  assert.ok(seconds >= 90 && seconds <= 105, `Actual loop took ${seconds}s`);
  assert.deepEqual(ordered, [0, 1, 2, 3, 4, 5, 6, 7, 8, 0]);
  assert.deepEqual(errors, []); assert.deepEqual(external, []);
  const selected = frames.filter(frame => frame.timestamp >= start && frame.timestamp <= end);
  await writeFile(`${temp}/frames.txt`, selected.map((frame, i) => `file '${frame.file}'\nduration ${i + 1 < selected.length ? Math.max(.005, (selected[i + 1].timestamp - frame.timestamp) / 1000) : .1}`).join('\n'));
  const video = spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', `${temp}/frames.txt`, '-fps_mode', 'vfr', '-c:v', 'libx264', '-preset', 'fast', '-crf', '19', '-pix_fmt', 'yuv420p', `${output}/complete-normal-speed.mp4`], { encoding: 'utf8' });
  if (video.status !== 0) throw new Error(video.stderr);
  const names = ['abertura', 'pescadores', 'vila', 'cidade', 'porto', 'ferrovia', 'petroleo', 'formacao', 'encerramento'];
  for (const [index, name] of names.entries()) {
    const state = states.find(state => state.index === index && state.phase === (index === 0 ? 'INTRO' : index === 8 ? 'OUTRO' : 'HOLDING'));
    const target = state.timestamp + (index === 0 ? 2600 : index === 8 ? 1500 : 500);
    const frame = selected.reduce((nearest, frame) => Math.abs(frame.timestamp - target) < Math.abs(nearest.timestamp - target) ? frame : nearest);
    await copyFile(frame.file, `${output}/${String(index).padStart(2, '0')}-${name}.jpg`);
  }
  const result = { normalSpeed: true, interaction: 'none', viewport: '1920x1080', actualCycleSeconds: seconds, orderedScenes: ordered, capturedFrames: selected.length, errors, externalRequests: external, states };
  await writeFile(`${output}/cycle-results.json`, JSON.stringify(result, null, 2));
  console.log(JSON.stringify({ ...result, states: `${states.length} transitions saved in cycle-results.json` }));
} finally { await browser.close(); }
