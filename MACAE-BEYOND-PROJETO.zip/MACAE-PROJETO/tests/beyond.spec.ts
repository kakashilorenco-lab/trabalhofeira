import { test, expect } from '@playwright/test';
import { Presentation } from '../src/engine/Presentation';
import { SCENES, nominalCycleDuration } from '../src/data/presentation';
import { MOTION } from '../src/motion/config';

test('direção C: a passagem excepcional tem duração própria e volta ao ritmo normal', () => {
  const e = new Presentation(SCENES);
  e.seek(4); e.go(5); expect(e.travelMs).toBe(3000);
  e.tick(1500); expect(e.position).toBeGreaterThan(4); expect(e.position).toBeLessThan(5);
  e.tick(1500); expect(e.index).toBe(5); expect(e.phase).toBe('SECTION_ACTIVE');
  e.go(6); expect(e.travelMs).toBe(MOTION.SCROLL_BASE_TRAVEL_MS / MOTION.SCROLL_SPEED_MULTIPLIER);
  expect(nominalCycleDuration).toBeGreaterThan(94000); expect(nominalCycleDuration).toBeLessThan(98000);
});

test('passagem: documentos identificados, pausa exata, limpeza e navegação interrompida', async ({page}) => {
  await page.goto('/'); await page.waitForFunction(()=>window.__exhibition);
  await page.evaluate(()=>{const e=window.__exhibition!.engine;e.seek(4);e.tick(5300);e.go(5);e.tick(1500);e.pause(true);});
  const portal=page.locator('.port-passage');
  await expect(portal).toHaveAttribute('data-visible','true');
  await expect(portal.locator('.paper-under .sheet-content')).toHaveAttribute('data-record','estacao-1917');
  await expect(portal.locator('.paper-front .sheet-content')).toHaveAttribute('data-record','canal-1846');
  await expect(page.locator('[data-scene="porto"] .paper-under .sheet-content')).toHaveAttribute('data-record','canal-1846');
  await expect(portal.locator('.paper-stack')).toHaveAttribute('data-tearing','true');
  const clip=await portal.locator('.paper-front').evaluate(e=>getComputedStyle(e).clipPath);
  await page.waitForTimeout(350);
  expect(await portal.locator('.paper-front').evaluate(e=>getComputedStyle(e).clipPath)).toBe(clip);
  await page.keyboard.press('ArrowRight');
  await expect(portal).toHaveAttribute('data-visible','false');
  await expect(portal.locator('.paper-stack')).toHaveAttribute('data-tearing','false');
  expect(await page.evaluate(()=>window.__exhibition!.engine.listenerCount)).toBe(8);
});

test('traçado editorial: não atravessa títulos, acompanha a faísca e respeita o acervo', async ({page}) => {
  await page.goto('/'); await page.waitForFunction(()=>window.__exhibition);
  await page.evaluate(()=>document.fonts.ready);
  for (const viewport of [{width:1920,height:1080},{width:3840,height:2160}]) {
    await page.setViewportSize(viewport);
    for(let i=1;i<=8;i++) {
      await page.evaluate(i=>{const e=window.__exhibition!.engine;e.pause(true);e.seek(i);e.elapsed=1500;},i);
      await expect.poll(()=>page.evaluate(()=>scrollY)).toBe(i*viewport.height);
      const result=await page.evaluate(i=>{
        const path=document.querySelector<SVGPathElement>('.timeline-base')!;
        const scene=document.querySelectorAll('.scene')[i];
        const text=scene.querySelector('h2')!;
        const walker=document.createTreeWalker(text,NodeFilter.SHOW_TEXT);
        const rectangles: DOMRect[]=[];
        while(walker.nextNode()) { const range=document.createRange();range.selectNodeContents(walker.currentNode);rectangles.push(range.getBoundingClientRect()); }
        let collisions=0;
        for(let d=0;d<path.getTotalLength();d+=6){const p=path.getPointAtLength(d);if(rectangles.some(rect=>p.x>rect.left&&p.x<rect.right&&p.y-scrollY>rect.top&&p.y-scrollY<rect.bottom))collisions++;}
        const images=[...scene.querySelectorAll<HTMLImageElement>('.paper-under img')];
        return {collisions,right:Math.max(...rectangles.map(r=>r.right)),left:Math.min(...rectangles.map(r=>r.left)),images:images.every(img=>img.getBoundingClientRect().width<=img.naturalWidth+1)};
      },i);
      expect(result.collisions,`scene ${i} at ${viewport.width}`).toBe(0);
      expect(result.left).toBeGreaterThan(0);expect(result.right).toBeLessThan(viewport.width);
      expect(result.images).toBe(true);
    }
  }
});

test('movimento reduzido também desativa a passagem espacial', async ({page}) => {
  await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/');await page.waitForFunction(()=>window.__exhibition);
  await page.evaluate(()=>{const e=window.__exhibition!.engine;e.seek(4);e.go(5);e.tick(1500);e.pause(true);});
  await expect(page.locator('.port-passage')).toBeHidden();
  await expect(page.locator('.ice-atmosphere')).toHaveAttribute('data-particles','0');
});
