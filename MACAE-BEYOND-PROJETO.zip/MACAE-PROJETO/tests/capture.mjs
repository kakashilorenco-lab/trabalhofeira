import { chromium } from '@playwright/test';
import { mkdir } from 'node:fs/promises';
const round = process.argv[2] || 'round-1';
const directory = `docs/visual-review/${round}`;
await mkdir(directory, { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
const errors = [];
page.on('pageerror', error => errors.push(error.message));
await page.goto('http://127.0.0.1:5173');
await page.waitForLoadState('networkidle');
await page.evaluate(() => document.fonts.ready);
await page.waitForFunction(() => window.__exhibition);
await page.evaluate(() => window.__exhibition.engine.pause(true));
const scenes = ['abertura', 'pescadores', 'vila', 'cidade', 'porto', 'ferrovia', 'petroleo', 'formacao', 'encerramento'];
for (const [index, scene] of scenes.entries()) {
  await page.evaluate(index => {
    window.__exhibition.seek(index);
    window.__exhibition.engine.elapsed = index === 0 ? 3400 : 1500;
  }, index);
  await page.waitForTimeout(index === 0 ? 3000 : 1800);
  await page.screenshot({ path: `${directory}/${String(index).padStart(2, '0')}-${scene}.png`, style: '.pause-notice { visibility: hidden }' });
  const measurements = await page.locator(`[data-scene="${scene}"]`).evaluate(element => {
    const rect = element.getBoundingClientRect();
    const elements = [...element.querySelectorAll('.event-copy, .artifact, .artifact figcaption, .event-copy h2')];
    return { scene: element.dataset.scene, top: rect.top, overflow: elements.filter(child => { const box = child.getBoundingClientRect(); return box.right > innerWidth || box.bottom > innerHeight - 70 || box.left < 0 || box.top < 90; }).map(child => child.className) };
  });
  console.log(JSON.stringify(measurements));
}
console.log('Browser errors:', errors);
await browser.close();
