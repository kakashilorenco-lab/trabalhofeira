import { test, expect } from '@playwright/test';
import { Presentation } from '../src/engine/Presentation';
import { events } from '../src/data/events';
import { imageSources, imageCandidates, candidatesFor } from '../src/data/media';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { MOTION, travelProgress } from '../src/motion/config';
import { SCENES, displayCopy, nominalCycleDuration } from '../src/data/presentation';

declare global { interface Window { sceneHistory?: number[] } }

test('motor: pausas, desaceleração, sequência, retomada e cortina de loop', () => {
  const engine = new Presentation([{ duration: 12000, sequences: 1 }, { duration: 24000, sequences: 3 }, { duration: 14000, sequences: 1 }]);
  const phases = new Set([engine.phase]);
  engine.onChange = state => phases.add(state.phase);
  engine.tick(12000); expect(engine.phase).toBe('RESUMING');
  engine.tick(MOTION.RESUME_DURATION); expect(engine.phase).toBe('TRAVELING');
  engine.tick(1200); expect(engine.phase).toBe('APPROACHING_SECTION');
  const middle = engine.position;
  engine.pause(true); engine.tick(90000); expect(engine.position).toBe(middle);
  engine.pause(false); engine.tick(engine.travelMs - 1200); expect(engine.phase).toBe('SECTION_ACTIVE');
  engine.tick(3000); expect(engine.sequence).toBe(0); expect(engine.position).toBe(1);
  engine.tick(5000); expect(engine.sequence).toBe(1);
  expect(engine.phase).toBe('IMAGE_SEQUENCE'); expect(engine.tearProgress).toBe(0);
  engine.tick(MOTION.PAPER_TEAR_DURATION); expect(engine.phase).toBe('HOLDING');
  engine.tick(8000); expect(engine.sequence).toBe(2); expect(engine.tearProgress).toBe(0);
  engine.tick(MOTION.PAPER_TEAR_DURATION);
  engine.tick(8000); engine.tick(MOTION.RESUME_DURATION); engine.tick(engine.travelMs); expect(engine.phase).toBe('OUTRO');
  engine.tick(14000); expect(engine.phase).toBe('RESTARTING');
  expect(engine.position).toBe(2); engine.tick(650); expect(engine.position).toBe(0);
  engine.tick(750); expect(engine.index).toBe(0); expect(engine.cycles).toBe(1);
  expect(phases).toEqual(new Set(['INTRO', 'RESUMING', 'TRAVELING', 'APPROACHING_SECTION', 'SECTION_ACTIVE', 'HOLDING', 'IMAGE_SEQUENCE', 'OUTRO', 'RESTARTING']));
});

test('dados: história preservada, sete temas e ciclo entre 75 e 100 segundos', () => {
  expect(events.map(event => event.id)).toEqual(['pescadores', 'vila', 'cidade', 'porto', 'ferrovia', 'petroleo', 'formacao']);
  expect(events.every(event => event.duration >= 17000)).toBe(true);
  expect(events[0].duration / 3).toBeGreaterThanOrEqual(3000);
  expect(imageSources).toHaveLength(12);
  expect(imageCandidates).toHaveLength(13);
  expect(imageSources.every(item => item.verified && (item.licenseUrl?.startsWith('https://') || (item.rightsVerification === 'user-declaration' && item.permissionId)) && existsSync(resolve('public', '.' + item.localFile)))).toBe(true);
  expect(events.every(event => event.mediaIds.length === candidatesFor(event.id).length)).toBe(true);
  expect(nominalCycleDuration).toBeGreaterThanOrEqual(75000);
  expect(nominalCycleDuration).toBeLessThanOrEqual(100000);
  expect(displayCopy.cidade.period).toBe('1846');
  expect(SCENES[1].duration / SCENES[1].sequences).toBe(4000);
});

test('autoplay real: inicia sem interação e observa três leituras antes de avançar', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('.exhibition')).toHaveAttribute('data-index', '1', { timeout: 16000 });
  await expect(page.locator('.exhibition')).toHaveAttribute('data-phase', 'HOLDING', { timeout: 7000 });
  const originalY = await page.evaluate(() => scrollY);
  await expect(page.locator('[data-scene="pescadores"] .paper-under .sheet-content')).toHaveAttribute('data-record', 'atlas-1767');
  await page.waitForTimeout(2000);
  expect(await page.evaluate(() => scrollY)).toBe(originalY);
  await expect(page.locator('[data-scene="pescadores"] .paper-under .sheet-content')).toHaveAttribute('data-record', 'planta-xix', { timeout: 3000 });
  await expect(page.locator('[data-scene="pescadores"] .paper-under .sheet-content')).toHaveAttribute('data-record', 'panorama', { timeout: 6000 });
  await expect(page.locator('.exhibition')).toHaveAttribute('data-index', '2', { timeout: 10000 });
});

test('viagem permanece rápida e cada composição recebe pelo menos três segundos', () => {
  const engine = new Presentation(SCENES);
  expect(engine.travelMs).toBeLessThanOrEqual(1700);
  expect(MOTION.SCROLL_BASE_TRAVEL_MS / engine.travelMs).toBe(2.8);
  expect(travelProgress(0)).toBe(0); expect(travelProgress(1)).toBeCloseTo(1);
  const positions = Array.from({ length: 101 }, (_, index) => travelProgress(index / 100));
  expect(positions.every((position, index) => index === 0 || position >= positions[index - 1])).toBe(true);
  expect(positions[1] - positions[0]).toBeLessThan(positions[50] - positions[49]);
  expect(positions[100] - positions[99]).toBeLessThan(positions[50] - positions[49]);
  engine.seek(1); expect(engine.sceneDuration).toBe(14400);
});

test('rasgo: folha nova realmente por baixo, borda irregular, pausa e limpeza', async ({ page }) => {
  await page.goto('/');
  await page.waitForFunction(() => Boolean(window.__exhibition));
  await page.evaluate(() => {
    const engine = window.__exhibition!.engine;
    engine.seek(4); engine.elapsed = 4600; engine.tick(0); engine.pause(true);
  });
  const stack = page.locator('[data-scene="porto"] .paper-stack');
  await expect(stack).toHaveAttribute('data-tearing', 'true');
  await expect(stack.locator('.paper-under .sheet-content')).toHaveAttribute('data-record', 'canal-1846');
  await expect(stack.locator('.paper-front .sheet-content')).toHaveAttribute('data-record', 'praia-1941');
  const start = await stack.locator('.paper-front').evaluate(element => getComputedStyle(element).clipPath);
  expect(start.startsWith('polygon(')).toBe(true); expect(start.split(',').length).toBeGreaterThan(100);
  await expect(stack.locator('.paper-edge')).toBeVisible();
  await expect(stack.locator('.paper-curl')).toBeVisible();
  await expect(page.locator('[data-scene="porto"] figcaption')).toBeHidden();
  const curl = await stack.locator('.paper-curl').evaluate(element => getComputedStyle(element).transform);
  await page.waitForTimeout(500);
  expect(await stack.locator('.paper-front').evaluate(element => getComputedStyle(element).clipPath)).toBe(start);
  expect(await stack.locator('.paper-curl').evaluate(element => getComputedStyle(element).transform)).toBe(curl);
  await page.keyboard.press('Space');
  await expect(stack).toHaveAttribute('data-tearing', 'false', { timeout: 2500 });
  await expect(stack.locator('.paper-front')).toBeHidden();
  expect(await stack.locator('.paper-front').evaluate(element => getComputedStyle(element).clipPath)).toBe('none');
  await expect(stack.locator('.paper-edge')).toBeHidden();
  await expect(stack.locator('.paper-curl')).toBeHidden();
  await expect(page.locator('[data-scene="porto"] figcaption')).toBeVisible();
  await expect(stack.locator('.paper-under .sheet-content')).toHaveAttribute('data-record', 'canal-1846');
  await page.keyboard.press('Space');
  await page.keyboard.press('ArrowRight');
  await expect(page.locator('.paper-stack[data-tearing="true"]')).toHaveCount(0);
  expect(await page.evaluate(() => window.__exhibition!.engine.listenerCount)).toBe(8);
});

test('movimento reduzido: sem partículas nem rasgo; conteúdo continua acessível', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  await page.waitForFunction(() => Boolean(window.__exhibition));
  await page.evaluate(() => { const engine = window.__exhibition!.engine; engine.seek(4); engine.elapsed = 4600; engine.tick(0); engine.pause(true); });
  await expect(page.locator('.ice-atmosphere')).toHaveAttribute('data-particles', '0');
  await expect(page.locator('.paper-stack[data-tearing="true"]')).toHaveCount(0);
  await expect(page.locator('[data-scene="porto"] .paper-under .sheet-content')).toHaveAttribute('data-record', 'canal-1846');
});

test('teclas: pausa, navegação, tela cheia, reinício e painel ocultável', async ({ page }) => {
  await page.goto('/');
  await page.waitForFunction(() => Boolean(window.__exhibition));
  await page.keyboard.press('Space');
  await expect(page.locator('.running')).toHaveText('EM PAUSA');
  const start = await page.evaluate(() => scrollY);
  await page.waitForTimeout(600);
  expect(await page.evaluate(() => scrollY)).toBe(start);
  // Pausing immediately must never leave an opaque intro curtain.
  expect(await page.locator('.restart-curtain').evaluate(element => Number(getComputedStyle(element).opacity))).toBe(0);
  await page.keyboard.press('ArrowRight');
  await expect(page.locator('.exhibition')).toHaveAttribute('data-index', '1');
  await expect.poll(() => page.evaluate(() => scrollY)).toBe(1080);
  await page.keyboard.press('ArrowLeft');
  await expect(page.locator('.exhibition')).toHaveAttribute('data-index', '0');
  await page.keyboard.press('h'); await expect(page.getByRole('complementary', { name: 'Controles de apresentação' })).toBeVisible();
  await page.keyboard.press('h'); await expect(page.getByRole('complementary', { name: 'Controles de apresentação' })).toHaveCount(0);
  await page.keyboard.press('s'); await expect(page.getByRole('complementary', { name: 'Situação da pesquisa histórica' })).toBeVisible();
  await page.keyboard.press('Escape');
  await page.keyboard.press('f'); await expect.poll(() => page.evaluate(() => Boolean(document.fullscreenElement))).toBe(true);
  await page.keyboard.press('f'); await expect.poll(() => page.evaluate(() => Boolean(document.fullscreenElement))).toBe(false);
  await page.keyboard.press('r');
  await expect(page.locator('.exhibition')).toHaveAttribute('data-phase', 'RESTARTING');
  await expect(page.locator('.exhibition')).toHaveAttribute('data-phase', 'INTRO', { timeout: 4000 });
  await expect(page.locator('.running')).toHaveText('EM EXIBIÇÃO');
});

test('três ciclos automáticos no navegador; ordem, faísca, recursos locais e erros', async ({ page }) => {
  const errors: string[] = [];
  const external: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('request', request => { if (!request.url().startsWith('http://127.0.0.1:5173') && !request.url().startsWith('data:')) external.push(request.url()); });
  await page.goto('/?speed=30');
  await page.evaluate(() => {
    const history: number[] = [];
    window.sceneHistory = history;
    new MutationObserver(() => {
      const index = Number(document.querySelector('.exhibition')?.getAttribute('data-index'));
      if (history.at(-1) !== index) history.push(index);
    }).observe(document.querySelector('.exhibition')!, { attributes: true, attributeFilter: ['data-index'] });
  });
  await page.waitForFunction(() => (window.__exhibition?.engine.cycles ?? 0) >= 3, undefined, { timeout: 40000 });
  const result = await page.evaluate(() => {
    const svg = document.querySelector<SVGPathElement>('.timeline-base')!;
    const spark = document.querySelector<SVGGElement>('.timeline-spark')!;
    const matrix = spark.transform.baseVal.consolidate()!.matrix;
    let nearest = Infinity;
    for (let i = 0; i <= 1000; i++) { const p = svg.getPointAtLength(svg.getTotalLength() * i / 1000); nearest = Math.min(nearest, Math.hypot(p.x - matrix.e, p.y - matrix.f)); }
    return { history: window.sceneHistory ?? [], nearest, images: Array.from(document.images).filter(image => !image.complete || image.naturalWidth === 0).length };
  });
  const sequence = result.history.join(',');
  expect(sequence).toContain('1,2,3,4,5,6,7,8,0,1,2,3,4,5,6,7,8,0');
  expect(result.nearest).toBeLessThan(10);
  expect(result.images).toBe(0); expect(errors).toEqual([]); expect(external).toEqual([]);
});

test('composição em 1080p e 4K: sem cortes, alternância e mídia legível', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('.identity, .identity-mark, .title-ornament, .chapter-watermark')).toHaveCount(0);
  expect(await page.locator('.timeline-base').evaluate(element => getComputedStyle(element).stroke)).toBe('rgb(249, 253, 255)');
  for (const viewport of [{ width: 1920, height: 1080 }, { width: 3840, height: 2160 }]) {
    await page.setViewportSize(viewport);
    await page.evaluate(() => window.__exhibition!.engine.pause(true));
    for (let index = 1; index <= 7; index++) {
      await page.evaluate(index => { window.__exhibition!.seek(index); window.__exhibition!.engine.elapsed = 1500; }, index);
      await expect.poll(() => page.evaluate(() => scrollY)).toBe(index * viewport.height);
      const geometry = await page.locator(`[data-scene="${events[index - 1].id}"]`).evaluate(element => {
        const copy = element.querySelector('.event-copy')!.getBoundingClientRect();
        const media = element.querySelector('.event-media')!.getBoundingClientRect();
        const caption = element.querySelector('figcaption')!.getBoundingClientRect();
        const title = element.querySelector('h2')!.getBoundingClientRect();
        return { copyX: copy.x, mediaX: media.x, titleRight: title.right, captionBottom: caption.bottom, titleTop: title.top, titleSize: parseFloat(getComputedStyle(element.querySelector('h2')!).fontSize), mediaWidth: media.width };
      });
      expect(geometry.titleRight).toBeLessThan(viewport.width);
      expect(geometry.titleTop).toBeGreaterThan(90);
      expect(geometry.captionBottom).toBeLessThan(viewport.height * .9);
      expect(geometry.titleSize).toBeGreaterThanOrEqual(80);
      expect(geometry.mediaWidth).toBeGreaterThanOrEqual(viewport.width * .28);
      expect(geometry.copyX < geometry.mediaX).toBe([1, 3, 5, 6, 7].includes(index));
    }
  }
});

test('TV: identificação discreta, número, período e título; cidade com ano verificado', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('main .event-description, main .research-note, main .chapter-label, main .intro-description, main .fishing-phase, main .graphic-typography, main .graphic-topline')).toHaveCount(0);
  for (const event of events) {
    const section = page.locator(`[data-scene="${event.id}"]`);
    await expect(section.locator('h2')).toHaveText(displayCopy[event.id].title.join(''));
    expect((await section.locator('.event-copy').innerText()).trim().split(/\s+/).length).toBeLessThanOrEqual(18);
    await expect(section.locator('.event-copy > *')).toHaveCount(3);
  }
  await expect(page.locator('[data-scene="cidade"] .event-period')).toHaveText('1846');
  await expect(page.locator('header')).toHaveText('Macaé');
  await expect(page.locator('[data-scene="encerramento"]')).toHaveText('MACAÉ');
});
