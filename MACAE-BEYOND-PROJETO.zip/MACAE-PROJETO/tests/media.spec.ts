import { test, expect } from '@playwright/test';
import { imageSources, imageCandidates, exhibitionCandidatesFor, sourceFor } from '../src/data/media';
import { events } from '../src/data/events';
import permissions from '../data/permissions.json' with { type: 'json' };
import { matchName } from '../scripts/inventory-images.mjs';

test('correspondência semântica: acentos, Macahé e anos distintos sem adivinhar estação', () => {
  const cases = [
    ['Cartas Topográficas da Capitania do Rio de Janeiro (1767).JPEG', 'atlas-1767'],
    ['PLANTA DA CIDADE DE MACAHÉ - Acervo.jpg', 'planta-xix'],
    ['Planta da Direção do Canal de Campos a Macahé (1846).jpg', 'canal-1846'],
    ['Praia de Imbetiba, Macaé (1941).jpg', 'praia-1941'],
    ['Estação Ferroviária de Macaé - 1917.jpg', 'estacao-1917'],
    ['Estação Ferroviária de Macaé - 1978.jpg', 'estacao-1978'],
    ['Obras de Instalação da Petrobras em Macaé (1978).jpg', 'obras-1978'],
    ['Fachada da Unidade SENAI Macaé (2015).jpg', 'senai-2015'],
  ];
  for (const [filename, id] of cases) expect(matchName(filename, imageCandidates)).toEqual({ status: 'matched', ids: [id] });
  expect(matchName('Estação Ferroviária de Macaé.jpg', imageCandidates)).toEqual({ status: 'unmatched', ids: [] });
  expect(matchName('foto-qualquer.jpg', imageCandidates).status).toBe('unmatched');
});

test('catálogo: 15 posições com registros aprovados; pendência de 1978 não vira slide vazio', async ({ page, request }) => {
  expect(events.flatMap(event => exhibitionCandidatesFor(event.id))).toHaveLength(15);
  expect(exhibitionCandidatesFor('ferrovia').map(item => item.id)).toEqual(['estacao-1917', 'patio-1960']);
  for (const item of imageSources) {
    const response = await request.get(item.localFile);
    expect(response.ok()).toBe(true);
    expect(response.headers()['content-type']).toContain(item.localFile.endsWith('.webp') ? 'image/webp' : 'image/jpeg');
  }
  const mediaRequests: string[] = [];
  page.on('request', request => { if (request.url().includes('/media/')) mediaRequests.push(new URL(request.url()).pathname); });
  await page.goto('/');
  await page.waitForFunction(() => Boolean(window.__exhibition));
  await page.evaluate(() => document.fonts.ready);
  for (const [i, event] of events.entries()) {
    for (const [sequence, candidate] of exhibitionCandidatesFor(event.id).entries()) {
      await page.evaluate(({ index, sequence }) => {
        const engine = window.__exhibition!.engine;
        engine.seek(index); engine.elapsed = sequence * (engine.scenes[index].duration / engine.scenes[index].sequences + 1200) + 1300;
        engine.pause(false); engine.tick(0); engine.pause(true);
      }, { index: i + 1, sequence });
      const sheet = page.locator(`[data-scene="${event.id}"] .paper-under .sheet-content`);
      await expect(sheet).toHaveAttribute('data-record', candidate.id);
      const record = sourceFor(candidate.id);
      if (record) {
        await expect(sheet.locator('img')).toHaveAttribute('alt', record.title);
        await expect.poll(() => sheet.locator('img').evaluate(image => (image as HTMLImageElement).naturalWidth)).toBe(record.width);
      } else {
        await expect(sheet.locator('img, svg')).toHaveCount(0);
        await expect(sheet.locator('strong')).toHaveText(candidate.title);
        await expect(sheet.locator('code')).toHaveText(candidate.expectedFile);
      }
    }
  }
  expect([...new Set(mediaRequests)].sort()).toEqual(imageSources.map(item => item.localFile).sort());
});

test('falha de arquivo: retorna à pendência nomeada, sem ícone quebrado nem ilustração', async ({ page }) => {
  await page.route('**/media/cartas-topograficas-1767-folha-de-rosto.jpg', route => route.abort());
  await page.goto('/');
  await page.waitForFunction(() => Boolean(window.__exhibition));
  await page.evaluate(() => { window.__exhibition!.engine.pause(true); window.__exhibition!.seek(1); });
  const sheet = page.locator('[data-scene="pescadores"] .paper-under');
  await expect(sheet.locator('img')).toHaveCount(0);
  await expect(sheet.locator('.missing-label')).toHaveText('ARQUIVO INDISPONÍVEL');
  await expect(sheet.locator('code')).toHaveText('cartas-topograficas-1767-folha-de-rosto.jpg');
});


test('autorização declarada: escopo explícito, sem inventar licença ou URL pública', async ({ page }) => {
  const declared = imageSources.filter(item => item.rightsVerification === 'user-declaration');
  expect(declared).toHaveLength(7);
  for (const item of declared) {
    expect(item.licenseUrl).toBeNull();
    expect(item.license).toContain('conforme declaração');
    const permission = permissions.find(permission => permission.id === item.permissionId);
    expect(permission?.scope).toContain(item.id);
  }
  expect(imageCandidates.filter(item => !sourceFor(item.id)).map(item => item.id)).toEqual(['estacao-1978']);
  await page.goto('/');
  await page.waitForFunction(() => Boolean(window.__exhibition));
  await page.keyboard.press('s');
  await expect(page.getByRole('complementary', { name: 'Situação da pesquisa histórica' })).toBeVisible();
  for (const item of declared) {
    const row = page.locator(`[data-source="${item.id}"]`);
    await expect(row.locator('a')).toHaveCount(1);
    await expect(row).toContainText('conforme declaração');
  }
  await expect(page.locator('a[href="null"], a[href="undefined"]')).toHaveCount(0);
});
