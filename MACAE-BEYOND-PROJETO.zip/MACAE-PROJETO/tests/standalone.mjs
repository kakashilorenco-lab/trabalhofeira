import { chromium } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
try {
  const context = await browser.newContext({ viewport: { width: 1920, height: 1080 }, offline: true });
  const page = await context.newPage();
  const errors = [], external = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('request', request => { if (/^https?:/.test(request.url())) external.push(request.url()); });
  const html = await readFile(resolve(process.argv[2] || 'exports/macae-exposicao.html'), 'utf8');
  const records = JSON.parse(await readFile(resolve('data/image-sources.json'), 'utf8'));
  const creditLinks = records.length + records.filter(record => record.licenseUrl).length;
  // The managed cloud Chromium blocks file:// navigation by policy. Render the
  // exact exported bytes in an empty document without granting file access.
  await page.setContent(html);
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(2900);
  assert.equal(await page.locator('h1').innerText(), 'MACAÉ');
  assert.equal(await page.evaluate(() => document.fonts.check('500 30px "Cormorant Garamond"') && document.fonts.check('400 20px "Manrope"')), true);
  await page.screenshot({ path: process.argv[3] || 'docs/acervo/upload/standalone.png' });
  assert.equal(await page.locator('img').evaluateAll(images => images.every(image => image.complete && image.naturalWidth > 0 && image.src.startsWith('data:image/'))), true);
  await page.keyboard.press('s');
  assert.equal(await page.locator('.research-panel a').count(), creditLinks);
  await page.keyboard.press('Escape');
  await page.keyboard.press('f');
  await page.waitForFunction(() => Boolean(document.fullscreenElement));
  await page.keyboard.press('f');
  await page.goto('about:blank?speed=30');
  await page.setContent(html);
  await page.waitForFunction(() => document.querySelector('.exhibition').dataset.index === '8', undefined, { timeout: 15000 });
  await page.waitForFunction(() => document.querySelector('.exhibition').dataset.phase === 'RESTARTING');
  await page.waitForFunction(() => document.querySelector('.exhibition').dataset.index === '0');
  assert.deepEqual(errors, []); assert.deepEqual(external, []);
  console.log(JSON.stringify({ standalone: 'passed', rendering: 'exported HTML bytes via setContent', fileNavigation: 'blocked by managed browser policy; not validated', offline: true, embeddedFonts: true, embeddedImages: true, creditLinks, fullscreen: 'passed', automaticLoop: 'passed', externalRequests: 0, browserErrors: 0 }));
} finally { await browser.close(); }
