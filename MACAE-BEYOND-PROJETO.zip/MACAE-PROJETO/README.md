# MACAÉ — UMA HISTÓRIA EM MOVIMENTO

Exposição automática para TV 16:9, em React, TypeScript e Vite. Direção atual: **A cidade em uma linha**. Fundo escuro e quente, datas monumentais, linha branca que muda de orientação, névoa discreta e uma passagem espacial com rasgo iluminado entre porto e ferrovia. O topo contém somente “Macaé”; cada capítulo mostra número, data, título e mídia. Autoplay e loop estão habilitados, sem áudio e sem dependência de permissões de vídeo.

**Edição de pesquisa:** o ZIP recebido contém 11 arquivos, todos identificados e integrados às seções correspondentes, preservando três versões de melhor qualidade já existentes. O catálogo agora possui 12 registros distintos, incluindo o atlas de 1767. Apenas a estação de 1978 permanece ausente. Para sete registros, a autorização do Macaé Tips foi declarada pelo responsável e registrada; não se trata de licença pública ou confirmação independente. Nenhuma imagem de IA, fotografia inventada ou ilustração substitui o acervo. Foram confirmados em fonte municipal 29/07/1813 e o ano de 1846; as demais referências continuam provisórias. Veja [fontes e divergências](docs/historical-sources.md) e [mapeamento do acervo](docs/acervo/upload/README.md). A revisão atual está em [A cidade em uma linha — direção e validação](docs/beyond/README.md); `docs/creative` preserva a edição anterior.

## Executar

No pacote editável, abra a pasta `MACAE-PROJETO` num terminal e execute `npm ci` e `npm run dev`. Isso funciona também no Windows com Node instalado. Para somente exibir na TV, use o HTML do pacote de exibição, sem instalar ferramentas.

Requer Node.js 22.12+ ou 24 LTS e npm; ambiente validado com Node 24.19.0. No checkout existente:

```bash
cd /workspace/trabalhofeira
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run dev -- --port 5173 --strictPort
```

No computador de exibição, abra o endereço mostrado pelo Vite no navegador e mantenha o processo ativo. Para produção:

```bash
npm run build
npm run preview -- --port 4173 --strictPort
```

Depois do preparo, não há consultas externas durante a reprodução: imagens, fontes, scripts e estilos são locais. O servidor local continua necessário nessa modalidade. Não abra `dist/index.html` diretamente por `file://`.

## Arquivo único para a TV

```bash
npm run export
```

Transfira `exports/macae-alem-da-linha.html` ao computador conectado à TV e abra-o no Chrome ou Edge. O arquivo inclui imagens aprovadas, fontes, JavaScript, estilos e créditos; não requer Node, servidor ou internet no computador da TV. Após qualquer edição, gere-o novamente. Preserve as atribuições e condições do acervo ao redistribuir.

O painel de visualização do ChatGPT neste fluxo de configuração **não publica automaticamente o servidor Vite**. Os testes confirmam a aplicação no navegador, não o funcionamento desse painel. O navegador gerenciado bloqueia navegação direta a `file://`; testamos os bytes exatos do HTML exportado em documento offline, sem contornar a política. A abertura do arquivo em um Chrome/Edge externo deve ser conferida no computador da TV.

Pressione **F** uma vez para solicitar tela cheia. O navegador exige um gesto do usuário. Para operação em quiosque, configure o navegador e a suspensão de tela no computador de exibição; não há promessa de fullscreen automático.

| Tecla | Ação |
| --- | --- |
| Espaço | Pausar / continuar |
| → / ← | Próximo / anterior |
| F | Entrar / sair de tela cheia |
| R | Reiniciar com cortina e retomar |
| H | Controles ocultáveis |
| S | Fontes, licenças e pendências |
| Esc | Fechar painéis |
| Home / End | Abertura / encerramento |

Na pausa, as setas mudam diretamente de capítulo. Durante a reprodução, fazem a viagem suave. A aba invisível suspende o relógio para evitar saltos ao retornar.

## Editar

| Arquivo | Conteúdo |
| --- | --- |
| `src/data/presentation.ts` | Títulos e períodos exibidos; cenas do modo breve |
| `src/data/events.ts` | Ordem dos sete eventos, `mediaIds`, pesquisa textual e ressalvas |
| `data/image-candidates.json` | 13 materiais solicitados, associações, nomes e pendências |
| `data/image-sources.json` | 12 registros incorporados, procedência e condições de uso |
| `data/permissions.json` | Declarações de autorização e alcance informado pelo responsável |
| `data/image-sources.schema.json` | Contrato das fichas de acervo |
| `src/data/media.ts` | Seleção e ordem dos registros, créditos compactos |
| `src/motion/config.ts` | Pausas, deslocamento, rasgo, névoa e gelo |
| `src/engine/Presentation.ts` | Máquina de estados, relógio único e loop |
| `src/components/PaperTearTransition.tsx` | Folhas reais sobrepostas, máscara, fibras e dobra |
| `src/beyond.css` | Direção atual: composições, escala das datas, luz e passagem espacial |
| `src/motion/choreography.ts` | Geometria editorial da linha e marcos; sem pretensão geográfica |
| `src/components/PortPassage.tsx` | Passagem excepcional com registros reais e créditos |
| `docs/acervo/` | Evidências de procedência, inventário e revisão desta edição |

Os dados longos em `events.ts` não aparecem na tela principal; suas antigas durações não comandam o modo breve. A ordem de `mediaIds` é editável. A exibição contém 15 posições e 12 imagens distintas; mapas reaparecem em temas relacionados com suas datas reais. `exhibitionCandidatesFor` seleciona somente registros utilizáveis quando existem; a estação de 1978 continua documentada no catálogo e na tecla S, sem criar uma tela vazia. Em caso de falha de arquivo, o fallback nomeado continua disponível.

Cada imagem de uma sequência permanece estável por **4 segundos** (a seção com imagem única, por **4,8 segundos**), além de **1,2 segundo** para o rasgo entre posições. As viagens comuns duram aproximadamente **1,21 segundo**; a passagem do porto para a ferrovia dura **3 segundos**. Abertura: 6 segundos; encerramento: 5 segundos. O ciclo nominal é de **95,74 segundos**, incluindo reinício. Há um único `requestAnimationFrame`, sem `setInterval`, e no máximo 48 cristais ativos. A perspectiva da passagem se estabiliza antes da maior parte do rasgo, preservando a observação e reduzindo rasterizações.

Ajuste `IMAGE_HOLD_DURATION` para sequências e `SECTION_HOLD_DURATION` para capítulos com um único item. `SCROLL_SPEED_MULTIPLIER` está em 2,8; valores maiores encurtam a viagem. `PAPER_TEAR_*` controla o rasgo e `ICE_*` controla o acabamento gelado. Para iniciar pausado, use `engine.pause(true)`; para encerrar sem loop, `engine.loop = false`. `?speed=30` acelera somente os ensaios; remova-o na TV. Em desenvolvimento, `window.__exhibition` permite inspeção e `seek(0…8)`; não existe no build de produção.

## Imagens

O ZIP da pasta Windows foi recebido: os 11 arquivos estão disponíveis em `/workspace/shared/downloads/imagens-macae-enviadas`. O inventário por SHA-256 reconhece as associações já conferidas, inclusive a estação sem ano no nome. Para inventariar outra pasta:

```bash
node scripts/inventory-images.mjs /caminho/da/pasta
```

O inventário é somente leitura, identifica por palavras e nomes, considera acentos e Macahé/Macaé e não confunde as estações de 1917 e 1978. Não aprova direitos automaticamente. O [guia do acervo](docs/media-guide.md) explica como incorporar ou substituir arquivos e manter os créditos. Fotografias posteriores são identificadas como posteriores; a folha de rosto de 1767 não é apresentada como mapa geográfico da vila. A reprodução limitada desse atlas é exibida sem ampliação; versão de maior resolução continua pendente.

## Verificar

```bash
npm test
npm run export
node tests/beyond-capture.mjs docs/beyond/final-review
node tests/brief-cycle.mjs docs/beyond/final
node tests/standalone.mjs exports/macae-alem-da-linha.html docs/beyond/final/offline.png
python scripts/package-delivery.py
```

Os scripts de captura exigem o Vite ativo na porta 5173. O ciclo normal exige FFmpeg. O teste de produção, `node tests/production.mjs`, exige `npm run preview -- --port 4173 --strictPort`. Os testes usam `/usr/bin/chromium`; outro caminho pode ser passado em `CHROMIUM_PATH`.

Os resultados atuais estão em [docs/beyond/README.md](docs/beyond/README.md). O recebimento e a pesquisa das imagens permanecem em `docs/acervo/upload/README.md`. Os relatórios `docs/brief/`, `docs/refinement/` e `docs/validation.md` preservam etapas anteriores e seus ritmos/acervos antigos. Não há teste em TV física nem de resistência por várias horas.
