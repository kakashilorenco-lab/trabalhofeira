import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, extname } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const dist = resolve(root, 'dist');
const types = { '.woff2': 'font/woff2', '.woff': 'font/woff', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.avif': 'image/avif' };
const dataUrl = async path => `data:${types[extname(path)] || 'application/octet-stream'};base64,${(await readFile(path)).toString('base64')}`;
let html = await readFile(resolve(dist, 'index.html'), 'utf8');

for (const match of [...html.matchAll(/<link\b[^>]*href="([^"]+)"[^>]*>/g)]) {
  if (!match[0].includes('stylesheet')) throw new Error('Unsupported external link in export: ' + match[0]);
  const cssPath = resolve(dist, '.' + match[1]);
  let css = await readFile(cssPath, 'utf8');
  for (const url of [...css.matchAll(/url\(([^)]+)\)/g)]) {
    const path = url[1].replace(/^['"]|['"]$/g, '');
    if (path.startsWith('data:')) continue;
    if (/^(https?:)?\/\//.test(path)) throw new Error('External dependency is not allowed: ' + path);
    const local = path.startsWith('/') ? resolve(dist, '.' + path) : resolve(cssPath, '..', path);
    css = css.replace(url[0], `url("${await dataUrl(local)}")`);
  }
  html = html.replace(match[0], () => `<style>${css.replace(/<\/style/gi, '<\\/style')}</style>`);
}

for (const match of [...html.matchAll(/<script\b[^>]*src="([^"]+)"[^>]*><\/script>/g)]) {
  let js = await readFile(resolve(dist, '.' + match[1]), 'utf8');
  const media = JSON.parse(await readFile(resolve(root, 'data/image-sources.json'), 'utf8'));
  for (const record of media.filter(record => record.verified)) {
    const embedded = await dataUrl(resolve(dist, '.' + record.localFile));
    js = js.replaceAll(record.localFile, embedded);
  }
  html = html.replace(match[0], () => `<script type="module">${js.replace(/<\/script/gi, '<\\/script')}</script>`);
}

const licenses = await Promise.all(['Cormorant-Garamond-OFL.txt', 'Manrope-OFL.txt'].map(name => readFile(resolve(dist, 'licenses', name), 'utf8')));
const escaped = licenses.join('\n\n').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
html = html.replace('</body>', () => `<template id="font-licenses">${escaped}</template></body>`);
if (/<(?:script|link)\b[^>]*(?:src|href)="(?:\/assets|https?:)/.test(html)) throw new Error('Export still depends on external files');
await mkdir(resolve(root, 'exports'), { recursive: true });
await writeFile(resolve(root, 'exports/macae-exposicao.html'), html);
await writeFile(resolve(root, 'exports/macae-exposicao-final.html'), html);
await writeFile(resolve(root, 'exports/macae-alem-da-linha.html'), html);
console.log(`Exported exports/macae-exposicao.html (${Math.round(Buffer.byteLength(html) / 1024)} KiB). Open directly in a browser; no server is required.`);
