export function normalizeName(value: string): string;
export function matchName(filename: string, candidates: ReadonlyArray<{ id: string; title: string; expectedFile: string }>): {
  status: 'matched' | 'ambiguous' | 'unmatched';
  ids: string[];
};
