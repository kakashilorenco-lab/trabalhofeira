import { readdir, readFile } from 'node:fs/promises';
import { resolve, basename, extname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

export const normalizeName = value => value.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase().replace(/macah[eé]/g, 'macae').replace(/[^a-z0-9]+/g, ' ').trim();
const rules = {
  'atlas-1767': [/topografic/, /capitania|1767/],
  'planta-xix': [/planta/, /cidade/, /macae/],
  panorama: [/panoram/, /macae/],
  'canal-1846': [/canal/, /campos/, /macae/],
  'praia-1941': [/praia/, /imbetiba/],
  'sodre-xx': [/sodre/],
  'estacao-1917': [/estacao/, /1917/],
  'patio-1960': [/patio/, /ferroviar/],
  'guarita-1978': [/guarita/, /petrobras/],
  'obras-1978': [/obras/, /petrobras/],
  'instalacoes-1978': [/instalac/, /petrobras/, /^(?!.*obras)/],
  'estacao-1978': [/estacao/, /1978/],
  'senai-2015': [/senai/, /fachada|unidade/],
};
export function matchName(filename, candidates) {
  const name = normalizeName(basename(filename, extname(filename)));
  const exact = candidates.filter(item => normalizeName(basename(item.expectedFile, extname(item.expectedFile))) === name || normalizeName(item.title) === name);
  const matches = exact.length ? exact : candidates.filter(item => rules[item.id]?.every(pattern => pattern.test(name)));
  return { status: matches.length === 1 ? 'matched' : matches.length > 1 ? 'ambiguous' : 'unmatched', ids: matches.map(item => item.id) };
}
async function walk(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    if (['node_modules', '.git', 'dist', 'exports', 'docs', 'test-results', 'playwright-report'].includes(entry.name)) continue;
    const path = resolve(directory, entry.name);
    if (entry.isDirectory()) files.push(...await walk(path));
    else if (entry.isFile() && /\.(jpe?g|png|webp|tiff?|avif)$/i.test(entry.name)) files.push(path);
  }
  return files;
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const root = resolve(import.meta.dirname, '..');
  const directory = resolve(process.argv[2] || resolve(root, 'public/media'));
  const candidates = JSON.parse(await readFile(resolve(root, 'data/image-candidates.json'), 'utf8'));
  let verifiedUploads = [];
  try { verifiedUploads = JSON.parse(await readFile(resolve(root, 'docs/acervo/upload/inventory.json'), 'utf8')); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  const files = await walk(directory);
  const results = [];
  for (const file of files) {
    const sha256 = createHash('sha256').update(await readFile(file)).digest('hex');
    const known = verifiedUploads.find(item => item.sha256 === sha256);
    results.push({ file, sha256, ...(known ? { status: 'matched', ids: [known.candidateId], method: 'verified-upload-hash' } : { ...matchName(file, candidates), method: 'filename' }) });
  }
  console.log(JSON.stringify({ directory, files: results, note: 'Inventário somente leitura. Hashes reconhecem somente arquivos enviados já conferidos. Nome ou hash não concede direitos; nenhuma autorização é criada automaticamente.' }, null, 2));
}
