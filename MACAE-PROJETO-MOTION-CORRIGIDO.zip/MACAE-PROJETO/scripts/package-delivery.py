"""Package the existing export, editable sources and current review; never publish."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXPORT = ROOT / 'exports'
HTML = EXPORT / 'macae-motion-corrigido.html'
if not HTML.is_file():
    raise SystemExit('Run npm run export first.')

INSTRUCTIONS = '''MACAÉ — UMA HISTÓRIA EM MOVIMENTO

1. Extraia o ZIP inteiro.
2. Abra macae-motion-corrigido.html no Chrome ou Edge.
3. Pressione F para tela cheia. A reprodução começa sozinha e repete em loop.

Não precisa instalar Node nem conectar à internet para exibir o HTML.
Espaço: pausa. Setas: capítulos. R: reinício. H: controles. S: fontes.
O navegador exige um gesto, como a tecla F, para entrar em tela cheia.

As fotografias e documentos são autênticos. Créditos e condições de uso
estão incorporados no painel S. Preserve-os ao redistribuir.
As pendências históricas continuam identificadas; esta revisão é visual.

Motion corrigido em 22/10/2026. Direção: A cidade em uma linha. Ciclo observado: aproximadamente 98 segundos.
Para editar o projeto, use o pacote MACAE-PROJETO-MOTION-CORRIGIDO.zip e seu README.md.
'''

def package(path, entries, text_entries=None):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for source, name in entries:
            z.write(source, name)
        for name, value in (text_entries or {}).items():
            z.writestr(name, value)
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        assert all(not name.startswith('/') and '..' not in Path(name).parts for name in z.namelist())
        count = len(z.namelist())
    return {'file': path.name, 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'entries': count, 'crc': 'passed'}

results = [package(EXPORT / 'MACAE-TV-MOTION-CORRIGIDO.zip', [(HTML, 'MACAE-TV-MOTION-CORRIGIDO/macae-motion-corrigido.html')],
                   {'MACAE-TV-MOTION-CORRIGIDO/LEIA-ME.txt': INSTRUCTIONS})]
files = [ROOT / name for name in ['README.md', 'package.json', 'package-lock.json',
                                  'tsconfig.json', 'index.html', 'playwright.config.ts', '.gitignore']]
for folder in ['src', 'public', 'data', 'scripts', 'tests']:
    files.extend(p for p in (ROOT / folder).rglob('*') if p.is_file())
for p in (ROOT / 'docs').rglob('*'):
    if not p.is_file():
        continue
    relative = p.relative_to(ROOT).as_posix()
    if p.suffix in ['.md', '.json', '.txt'] or relative.startswith('docs/beyond/final') or (relative.startswith('docs/beyond/motion-fix/') and p.suffix != '.mp4') or (relative.startswith('docs/beyond/') and p.name == 'overview.jpg'):
        # Delivery hashes are written after packaging; do not include a stale manifest.
        if p.name != 'delivery-manifest.json':
            files.append(p)
files.append(HTML)
results.append(package(EXPORT / 'MACAE-PROJETO-MOTION-CORRIGIDO.zip',
                       [(p, 'MACAE-PROJETO/' + p.relative_to(ROOT).as_posix()) for p in sorted(set(files))]))
with zipfile.ZipFile(EXPORT / 'MACAE-TV-MOTION-CORRIGIDO.zip') as z:
    assert z.read('MACAE-TV-MOTION-CORRIGIDO/macae-motion-corrigido.html') == HTML.read_bytes()
manifest = {'publication': 'not published', 'htmlBytes': HTML.stat().st_size,
            'htmlSha256': hashlib.sha256(HTML.read_bytes()).hexdigest(), 'archives': results}
(ROOT / 'docs/beyond/delivery-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
