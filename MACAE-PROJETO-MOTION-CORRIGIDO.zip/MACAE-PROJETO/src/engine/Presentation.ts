import { MOTION, travelProgress } from '../motion/config';

export type Phase = 'INTRO' | 'TRAVELING' | 'APPROACHING_SECTION' | 'SECTION_ACTIVE' | 'IMAGE_SEQUENCE' | 'HOLDING' | 'RESUMING' | 'OUTRO' | 'RESTARTING';
export type Snapshot = { phase: Phase; index: number; sequence: number; paused: boolean; cycles: number };
export type Scene = { duration: number; sequences: number };
export type MotionFrame = { delta: number; time: number; reducedMotion: boolean };

// A single animation clock drives travel, observation, sequence and restart.
// Time only advances while visible and playing; no concurrent timers exist.
export class Presentation {
  phase: Phase = 'INTRO';
  index = 0;
  sequence = 0;
  paused = false;
  cycles = 0;
  elapsed = 0;
  position = 0;
  from = 0;
  fromSequence = 0;
  arrivedByTravel = false;
  travelMs = MOTION.SCROLL_BASE_TRAVEL_MS / MOTION.SCROLL_SPEED_MULTIPLIER;
  loop = true;
  onChange: (snapshot: Snapshot) => void = () => {};
  private frameListeners = new Set<(frame: MotionFrame) => void>();
  constructor(public scenes: Scene[]) {}
  subscribeFrame(callback: (frame: MotionFrame) => void) {
    this.frameListeners.add(callback);
    return () => { this.frameListeners.delete(callback); };
  }
  render(frame: MotionFrame) { this.frameListeners.forEach(callback => callback(frame)); }
  get listenerCount() { return this.frameListeners.size; }
  get snapshot(): Snapshot {
    return { phase: this.phase, index: this.index, sequence: this.sequence, paused: this.paused, cycles: this.cycles };
  }
  get observing() { return !['TRAVELING', 'APPROACHING_SECTION', 'RESUMING', 'RESTARTING'].includes(this.phase); }
  get sceneDuration() { const scene = this.scenes[this.index]; return scene.duration + Math.max(0, scene.sequences - 1) * MOTION.PAPER_TEAR_DURATION; }
  get progress() { return Math.min(1, this.elapsed / this.sceneDuration); }
  get tearProgress() {
    if (this.sequence === 0 || this.phase !== 'IMAGE_SEQUENCE') return 1;
    const hold = this.scenes[this.index].duration / this.scenes[this.index].sequences;
    const start = this.sequence * hold + (this.sequence - 1) * MOTION.PAPER_TEAR_DURATION;
    return Math.max(0, Math.min(1, (this.elapsed - start) / MOTION.PAPER_TEAR_DURATION));
  }
  emit() { this.onChange(this.snapshot); }
  pause(value = !this.paused) { this.paused = value; this.emit(); }
  go(index: number) {
    const destination = Math.max(0, Math.min(index, this.scenes.length - 1));
    if (this.paused) { this.seek(destination); return; }
    this.from = this.position;
    this.fromSequence = this.sequence;
    this.travelMs = destination === 5 && this.from === 4 ? MOTION.PORT_PASSAGE_DURATION : MOTION.SCROLL_BASE_TRAVEL_MS / MOTION.SCROLL_SPEED_MULTIPLIER;
    this.index = destination;
    this.sequence = 0;
    this.elapsed = 0;
    this.phase = 'TRAVELING';
    this.emit();
  }
  // Used for resizing and by the documented development inspection console.
  seek(index: number) {
    this.index = Math.max(0, Math.min(index, this.scenes.length - 1));
    this.position = this.index;
    this.elapsed = 0;
    this.sequence = 0;
    this.activate();
  }
  restart() {
    this.arrivedByTravel = false;
    this.paused = false;
    this.phase = 'RESTARTING';
    this.elapsed = 0;
    this.emit();
  }
  activate(fromTravel = false) {
    this.arrivedByTravel = fromTravel;
    this.phase = this.index === 0 ? 'INTRO' : this.index === this.scenes.length - 1 ? 'OUTRO' : 'SECTION_ACTIVE';
    this.emit();
  }
  tick(delta: number) {
    if (this.paused) return;
    this.elapsed += Math.max(0, delta);
    if (this.phase === 'RESTARTING') {
      // Move only while the blackout curtain is fully opaque.
      if (this.elapsed >= MOTION.RESTART_OPAQUE_AT && this.position !== 0) this.position = 0;
      if (this.elapsed >= MOTION.RESTART_DURATION) {
        this.index = 0; this.sequence = 0; this.position = 0; this.elapsed = 0;
        this.cycles++; this.phase = 'INTRO'; this.emit();
      }
      return;
    }
    if (this.phase === 'RESUMING') {
      if (this.elapsed >= MOTION.RESUME_DURATION) this.go(this.index + 1);
      return;
    }
    if (this.phase === 'TRAVELING' || this.phase === 'APPROACHING_SECTION') {
      const t = Math.min(1, this.elapsed / this.travelMs);
      this.position = this.from + (this.index - this.from) * travelProgress(t);
      if (t >= 1) { this.position = this.index; this.elapsed = 0; this.activate(true); }
      else if (t >= 1 - MOTION.SCROLL_DECELERATION && this.phase !== 'APPROACHING_SECTION') { this.phase = 'APPROACHING_SECTION'; this.emit(); }
      return;
    }
    const scene = this.scenes[this.index];
    const hold = scene.duration / scene.sequences;
    const sequence = Math.min(scene.sequences - 1, Math.floor((this.elapsed + MOTION.PAPER_TEAR_DURATION) / (hold + MOTION.PAPER_TEAR_DURATION)));
    const local = this.elapsed - sequence * hold - Math.max(0, sequence - 1) * MOTION.PAPER_TEAR_DURATION;
    const tearing = sequence > 0 && local < MOTION.PAPER_TEAR_DURATION;
    const nextPhase = tearing ? 'IMAGE_SEQUENCE' : this.index > 0 && this.index < this.scenes.length - 1 && this.elapsed >= MOTION.SECTION_SETTLE_DURATION ? 'HOLDING' : this.phase;
    if (sequence !== this.sequence || nextPhase !== this.phase) { this.sequence = sequence; this.phase = nextPhase; this.emit(); }
    if (this.elapsed >= this.sceneDuration) {
      this.elapsed = 0;
      if (this.index === this.scenes.length - 1) {
        if (this.loop) this.restart(); else this.pause(true);
      } else { this.phase = 'RESUMING'; this.emit(); }
    }
  }
}
