import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { events } from './data/events';
import { imageSources } from './data/media';
import { SCENES, displayCopy } from './data/presentation';
import { Presentation, Snapshot } from './engine/Presentation';
import { Graphic } from './components/Graphic';
import { Controls } from './components/Controls';
import { MOTION } from './motion/config';
import { IceField } from './motion/IceField';
import { exhibitionPath, clamp, smooth, passageProgress, sectionEntry } from './motion/choreography';
import { PortPassage } from './components/PortPassage';

declare global {
  interface Window { __exhibition?: { engine: Presentation; seek: (index: number) => void; speed: (speed: number) => void } }
}

export function App() {
  const engine = useMemo(() => new Presentation(SCENES), []);
  const [snapshot, setSnapshot] = useState<Snapshot>(engine.snapshot);
  const [size, setSize] = useState({ width: window.innerWidth, height: window.innerHeight });
  const [notice, setNotice] = useState({ text: '', id: 0 });
  const pathRef = useRef<SVGPathElement>(null);
  const sparkRef = useRef<SVGGElement>(null);
  const trailRef = useRef<SVGPathElement>(null);
  const lightRef = useRef<SVGPathElement>(null);
  const iceRef = useRef<HTMLCanvasElement>(null);
  const crystalsRef = useRef<SVGGElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const mediaReady = useRef(false);
  const shownSequences = useRef<number[]>([]);
  const speedRef = useRef(Math.max(0.25, Math.min(60, Number(new URLSearchParams(location.search).get('speed')) || 1)));
  const sceneCount = SCENES.length;
  const geometry = useMemo(() => exhibitionPath(size.width, size.height), [size]);
  const { path, anchors: knots } = geometry;

  const fullscreen = useCallback(async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else if (document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen();
      else throw new Error('unsupported');
    } catch { setNotice({ text: 'Tela cheia indisponível neste navegador. Use o modo de apresentação do computador.', id: Date.now() }); }
  }, []);

  useEffect(() => {
    engine.onChange = next => {
      shownSequences.current[next.index] = next.sequence;
      setSnapshot(next);
    };
    const resize = () => setSize({ width: window.innerWidth, height: window.innerHeight });
    const keydown = (event: KeyboardEvent) => {
      if (event.altKey || event.ctrlKey || event.metaKey || (event.target instanceof HTMLElement && ['BUTTON', 'INPUT', 'TEXTAREA', 'SELECT'].includes(event.target.tagName))) return;
      if ([' ', 'ArrowRight', 'ArrowLeft', 'ArrowDown', 'ArrowUp', 'PageDown', 'PageUp', 'Home', 'End'].includes(event.key)) event.preventDefault();
      switch (event.key.toLowerCase()) {
        case ' ': engine.pause(); break;
        case 'arrowright': case 'arrowdown': case 'pagedown': engine.go(engine.index + 1); break;
        case 'arrowleft': case 'arrowup': case 'pageup': engine.go(engine.index - 1); break;
        case 'f': void fullscreen(); break;
        case 'r': engine.restart(); break;
        case 'home': engine.go(0); break;
        case 'end': engine.go(sceneCount - 1); break;
      }
    };
    const wheel = (event: WheelEvent) => { if (!(event.target as HTMLElement).closest('aside')) event.preventDefault(); };
    const touch = (event: TouchEvent) => { if (!(event.target as HTMLElement).closest('aside')) event.preventDefault(); };
    window.addEventListener('resize', resize);
    window.addEventListener('keydown', keydown);
    window.addEventListener('wheel', wheel, { passive: false });
    window.addEventListener('touchmove', touch, { passive: false });
    if (import.meta.env.DEV) window.__exhibition = { engine, seek: index => engine.seek(index), speed: speed => { speedRef.current = Math.max(0.25, Math.min(60, speed)); } };
    return () => {
      engine.onChange = () => {};
      window.removeEventListener('resize', resize);
      window.removeEventListener('keydown', keydown);
      window.removeEventListener('wheel', wheel);
      window.removeEventListener('touchmove', touch);
      delete window.__exhibition;
    };
  }, [engine, fullscreen, sceneCount]);

  useEffect(() => {
    let frame = 0;
    let last = performance.now();
    const svg = pathRef.current;
    if (!svg) return;
    const length = svg.getTotalLength();
    const sceneElements = Array.from(rootRef.current?.querySelectorAll<HTMLElement>('.scene') ?? []);
    const halos = Array.from(rootRef.current?.querySelectorAll<SVGCircleElement>('.knot-halo') ?? []);
    const previousArrival: number[] = [];
    const previousPulse: string[] = [];
    const ice = iceRef.current ? new IceField(iceRef.current, size.width, size.height) : null;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    let ambientTime = 0;
    let cycles = engine.cycles;
    rootRef.current?.style.setProperty('--ice-strength', String(MOTION.ICE_GLOW_INTENSITY));
    rootRef.current?.style.setProperty('--display-scale', String(Math.max(.6, size.width / 1920)));
    // Sample once after geometry changes; each frame only interpolates cached geometry.
    const samples = Array.from({ length: 4001 }, (_, i) => {
      const point = svg.getPointAtLength(length * i / 4000);
      return { x: point.x, y: point.y, length: length * i / 4000 };
    });
    const anchorLengths = knots.map(anchor => samples.reduce((best, point) => Math.hypot(point.x-anchor.x, point.y-anchor.y) < Math.hypot(best.x-anchor.x, best.y-anchor.y) ? point : best).length);
    const openingPaths = Array.from(rootRef.current?.querySelectorAll<SVGPathElement>('.opening-thread path') ?? []);
    const openingLength = openingPaths[0]?.getTotalLength() ?? 1;
    const portal = rootRef.current?.querySelector<HTMLElement>('.port-passage');
    if (crystalsRef.current) {
      const fragments = document.createDocumentFragment();
      const scale = Math.max(.6, size.width / 1920);
      for (let distance = 20, i = 0; distance < length; distance += (37 + i % 5 * 9) * scale, i++) {
        const point = svg.getPointAtLength(distance);
        const hand = i % 2 ? -1 : 1;
        const w = (2 + i % 4 * .8) * scale;
        const h = (3 + i % 5) * scale;
        const facet = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
        facet.setAttribute('points', `${point.x},${point.y - h} ${point.x + hand * w},${point.y - h * .15} ${point.x + hand * w * .4},${point.y + h * .75} ${point.x},${point.y + h * .25}`);
        facet.setAttribute('opacity', String(.14 + i % 4 * .07));
        fragments.append(facet);
      }
      crystalsRef.current.replaceChildren(fragments);
    }
    const animate = (now: number) => {
      const delta = Math.min(100, now - last);
      last = now;
      if (!document.hidden && mediaReady.current) engine.tick(delta * speedRef.current);
      const cameraY = engine.position * size.height;
      window.scrollTo(0, cameraY);
      const segment = Math.max(0, Math.min(sceneCount - 2, Math.floor(engine.position)));
      const along = clamp(engine.position - segment);
      const distance = anchorLengths[segment] + (anchorLengths[segment + 1] - anchorLengths[segment]) * along;
      const sampleIndex = distance / length * 4000;
      const before = samples[Math.floor(sampleIndex)], after = samples[Math.min(4000, Math.floor(sampleIndex)+1)];
      const mix = sampleIndex - Math.floor(sampleIndex);
      const point = { x: before.x + (after.x - before.x) * mix, y: before.y + (after.y - before.y) * mix, length: distance };
      sparkRef.current?.setAttribute('transform', `translate(${point.x} ${point.y})`);
      if (trailRef.current) { trailRef.current.style.strokeDasharray = `${Math.max(0, point.length)} ${length}`; }
      if (lightRef.current) {
        lightRef.current.style.strokeDasharray = `${130 * Math.max(.6, size.width / 1920)} ${length}`;
        lightRef.current.style.strokeDashoffset = String(-point.length + 110 * Math.max(.6, size.width / 1920));
      }
      const visualDelta = !document.hidden && !engine.paused ? delta : 0;
      ambientTime += visualDelta;
      if (cycles !== engine.cycles || engine.phase === 'RESTARTING') { ice?.reset(); cycles = engine.cycles; }
      ice?.draw(visualDelta, ambientTime, point, cameraY, engine.phase, reduced.matches);
      engine.render({ delta: visualDelta, time: ambientTime, reducedMotion: reduced.matches });
      // The same clock directs typography, arrival light and paper. No CSS
      // animation can continue after pause, or finish on a different scene.
      sceneElements.forEach((element, index) => {
        const distance = Math.abs(index - engine.position);
        const arrival = reduced.matches ? 1 : Math.max(0, Math.min(1, 1 - distance / .7));
        if (arrival !== previousArrival[index]) {
          element.style.setProperty('--arrival', String(arrival));
          previousArrival[index] = arrival;
        }
      });
      const arriving = ['TRAVELING', 'APPROACHING_SECTION'].includes(engine.phase);
      if (engine.index === 0 && (engine.phase === 'INTRO' || arriving)) {
        const reveal = arriving ? sectionEntry(engine, 0, reduced.matches) : reduced.matches || engine.arrivedByTravel ? 1 : smooth((engine.elapsed - 350) / 2000);
        sceneElements[0]?.style.setProperty('--title-reveal', String(reveal));
        const stroke = arriving ? reveal : reduced.matches || engine.arrivedByTravel ? 1 : smooth((engine.elapsed - 100) / 2900);
        openingPaths.forEach(line => { line.style.strokeDasharray = String(openingLength); line.style.strokeDashoffset = String(openingLength * (1 - stroke)); });
      }
      sceneElements.forEach((element, index) => {
        const entry = sectionEntry(engine, index, reduced.matches);
        element.style.setProperty('--entry', String(entry));
        element.style.setProperty('--edge-light', String(engine.index === index && arriving ? Math.sin(entry * Math.PI) : 0));
      });
      const passage = passageProgress(engine);
      if (portal) {
        const visible = passage !== null && !reduced.matches;
        portal.dataset.visible = String(visible);
        portal.style.opacity = String(visible ? smooth(passage! / .15) * (1 - smooth((passage! - .82) / .18)) : 0);
        portal.style.setProperty('--depth', String(passage === null ? 0 : smooth(passage / .3)));
      }
      halos.forEach((halo, i) => {
        const active = engine.index === i + 1 && engine.observing;
        const t = Math.min(1, engine.elapsed / 1450);
        const key = `${active}:${active ? t : 1}`;
        if (previousPulse[i] === key) return;
        previousPulse[i] = key;
        halo.setAttribute('r', String((active ? 8 + 21 * t : 14) * Math.max(.6, size.width / 1920)));
        halo.style.opacity = String(active ? .12 + .62 * (1 - t) ** 2 : .16);
      });
      if (rootRef.current) {
        rootRef.current.style.setProperty('--camera', String(engine.position));
        const alpha = engine.paused ? 0 : engine.phase === 'RESTARTING' ? Math.min(1, engine.elapsed / 400) : engine.index === 0 && engine.elapsed < 600 ? Math.max(0, 1 - engine.elapsed / 600) : 0;
        rootRef.current.style.setProperty('--curtain', String(alpha));
      }
      frame = requestAnimationFrame(animate);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [engine, size]);

  useEffect(() => {
    let cancelled = false;
    mediaReady.current = false;
    void Promise.all(imageSources.filter(source => source.verified).map(async source => {
      const image = new Image(); image.src = source.localFile;
      // Failed files get the existing named fallback; never deadlock the show.
      try { await image.decode(); } catch { /* Graphic handles image failures. */ }
    })).then(() => { if (!cancelled) mediaReady.current = true; });
    return () => { cancelled = true; };
  }, []);

  const isTraveling = ['TRAVELING', 'APPROACHING_SECTION', 'RESUMING'].includes(snapshot.phase);
  return <div ref={rootRef} className={`exhibition ${snapshot.paused ? 'is-paused' : ''} ${isTraveling ? 'is-traveling' : ''}`} data-phase={snapshot.phase} data-index={snapshot.index}>
    <header className="exhibition-name">Macaé</header>
    <span className="running sr-only">{snapshot.paused ? 'EM PAUSA' : 'EM EXIBIÇÃO'}</span>

    <main>
      <section className={`scene intro ${snapshot.index === 0 ? 'is-active' : ''}`} aria-label="Abertura" data-scene="abertura">
        <svg className="opening-thread" viewBox="0 0 1920 1080" preserveAspectRatio="none" aria-hidden="true">{['aura', 'light', 'core'].map(layer => <path key={layer} className={layer} d="M 120 690 C 500 690 1200 690 1650 690 C 1800 690 1540 842 960 842" />)}</svg>
        <div className="intro-title"><h1>MACAÉ</h1><p className="intro-subtitle">UMA HISTÓRIA EM MOVIMENTO</p></div>
      </section>

      {events.map((event, index) => <section className={`scene event-scene ${index % 2 ? 'reverse' : ''} ${snapshot.index === index + 1 ? 'is-active' : ''}`} key={event.id} data-scene={event.id} aria-label={event.detail}>
        <div className="event-copy">
          <span className="event-number">{String(index + 1).padStart(2, '0')}</span>
          {displayCopy[event.id].period && <p className="event-period">{event.id === 'vila' ? <><span className="date-detail">29 DE JULHO DE</span>{' '}<span className="date-year">1813</span></> : displayCopy[event.id].period}</p>}
          <h2>{displayCopy[event.id].title.map((line, i) => <span key={line} className={i === 1 ? 'italic-line' : ''}>{line}</span>)}</h2>
        </div>
        <div className="event-media"><Graphic event={event} engine={engine} sceneIndex={index + 1} sequence={shownSequences.current[index + 1] ?? 0} /></div>
      </section>)}

      <section className={`scene outro ${snapshot.index === sceneCount - 1 ? 'is-active' : ''}`} data-scene="encerramento" aria-label="Encerramento">
        <h2>MACAÉ</h2>
      </section>
    </main>

    <svg className="timeline" width={size.width} height={size.height * sceneCount} viewBox={`0 0 ${size.width} ${size.height * sceneCount}`} aria-hidden="true">
      <path d={path} className="timeline-atmosphere" />
      <path d={path} className="timeline-halo" />
      <path d={path} className="timeline-inner" />
      <path ref={pathRef} d={path} className="timeline-base" />
      <path d={path} className="timeline-frost" />
      <path d={geometry.rail} className="timeline-rail" />
      <g ref={crystalsRef} className="timeline-crystals" />
      <path ref={trailRef} d={path} className="timeline-trail" />
      <path ref={lightRef} d={path} className="timeline-active-light" />
      {knots.slice(1, -1).map((point, i) => <g key={i} transform={`translate(${point.x} ${point.y})`} className={`timeline-knot ${snapshot.index === i + 1 && !isTraveling ? 'active arrived' : ''}`}><circle r="16" className="knot-halo" /><circle r="4" /></g>)}
      <g ref={sparkRef} className="timeline-spark"><circle className="spark-glow" r="20" /><circle className="spark-inner" r="7" /><circle className="spark-core" r="2.5" /></g>
    </svg>
    <canvas className="ice-atmosphere" ref={iceRef} aria-hidden="true" />

    <PortPassage engine={engine} />
    <Controls snapshot={snapshot} pause={() => engine.pause()} go={index => engine.go(index)} restart={() => engine.restart()} fullscreen={() => void fullscreen()} />
    {snapshot.paused && <div className="pause-notice" role="status"><span>Ⅱ</span> CONTEMPLAR TAMBÉM FAZ PARTE <small>ESPAÇO PARA CONTINUAR</small></div>}
    {notice.text && <div className="notice" role="status" key={notice.id}>{notice.text}</div>}
    <div className="restart-curtain" aria-hidden="true" />
  </div>;
}
