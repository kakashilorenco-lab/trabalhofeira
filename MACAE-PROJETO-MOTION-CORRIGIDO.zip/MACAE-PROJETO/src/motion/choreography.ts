import type { Presentation } from '../engine/Presentation';
import { MOTION } from './config';

export const clamp = (n: number) => Math.max(0, Math.min(1, n));
export const smooth = (n: number) => { const t = clamp(n); return t * t * (3 - 2 * t); };
export const isPortPassage = (engine: Presentation) => engine.index === 5 && engine.from === 4 && ['TRAVELING', 'APPROACHING_SECTION'].includes(engine.phase);
export const passageProgress = (engine: Presentation) => isPortPassage(engine) ? clamp(engine.elapsed / engine.travelMs) : null;

/** Finish the reveal with the camera, never restart it on SECTION_ACTIVE. */
export function sectionEntry(engine: Presentation, index: number, reduced: boolean) {
  if (reduced || engine.index !== index || !['TRAVELING', 'APPROACHING_SECTION'].includes(engine.phase)) return 1;
  const duration = Math.min(MOTION.ENTRY_DURATION, engine.travelMs);
  return smooth((engine.elapsed - engine.travelMs + duration) / duration);
}

/** Editorial geometry, not geographic routes or historical boundaries. */
export function exhibitionPath(width: number, height: number) {
  const anchors = [[.5,.78],[.5,1.5],[.58,2.5],[.4,3.5],[.89,4.12],[.12,5.8],[.62,6.5],[.4,7.5],[.5,8.15]].map(([x,y]) => ({x:x*width,y:y*height}));
  const p = (x:number,y:number) => `${x*width} ${y*height}`;
  const path = `M ${p(.5,.78)} C ${p(.5,1.03)} ${p(.5,1.2)} ${p(.5,1.5)}
    C ${p(.5,1.98)} ${p(.58,2.06)} ${p(.58,2.5)}
    C ${p(.58,2.98)} ${p(.4,3.03)} ${p(.4,3.5)}
    C ${p(.4,3.86)} ${p(.06,3.88)} ${p(.06,4.04)}
    C ${p(.06,4.12)} ${p(.18,4.12)} ${p(.27,4.12)} L ${p(.89,4.12)}
    C ${p(.95,4.12)} ${p(.95,4.25)} ${p(.95,4.38)} L ${p(.95,5.64)}
    C ${p(.95,5.8)} ${p(.82,5.8)} ${p(.72,5.8)} L ${p(.12,5.8)}
    C ${p(.06,5.8)} ${p(.06,5.94)} ${p(.18,6.02)}
    C ${p(.4,6.17)} ${p(.62,6.12)} ${p(.62,6.5)}
    C ${p(.62,6.98)} ${p(.4,7.02)} ${p(.4,7.5)}
    C ${p(.4,7.91)} ${p(.5,7.96)} ${p(.5,8.15)}`;
  return { path, anchors, rail: `M ${p(.12,5.82)} L ${p(.72,5.82)} C ${p(.85,5.82)} ${p(.97,5.8)} ${p(.97,5.64)} L ${p(.97,5.32)}` };
}
