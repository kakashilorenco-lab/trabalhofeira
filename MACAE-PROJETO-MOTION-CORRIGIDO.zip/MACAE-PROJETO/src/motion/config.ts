/** Artistic controls. Durations are milliseconds; densities are particles/second. */
export const MOTION = {
  SCROLL_BASE_TRAVEL_MS: 3400,
  SCROLL_SPEED_MULTIPLIER: 2.8,
  SCROLL_ACCELERATION: 0.18,
  SCROLL_DECELERATION: 0.48,
  SECTION_HOLD_MULTIPLIER: 1,
  SECTION_HOLD_DURATION: 4800,
  SECTION_SETTLE_DURATION: 900,
  ENTRY_DURATION: 900,
  RESUME_DURATION: 180,
  IMAGE_HOLD_DURATION: 4000,
  ICE_GLOW_INTENSITY: 0.9,
  ICE_PARTICLE_DENSITY: 14,
  ICE_PARTICLE_SPEED: 1,
  ICE_MIST_OPACITY: 0.24,
  ICE_PARTICLE_LIMIT: 48,
  ICE_BAND_WIDTH: 168,
  PAPER_TEAR_DURATION: 1200,
  PAPER_TEAR_IRREGULARITY: 12,
  PAPER_TEAR_SHADOW: 0.28,
  PAPER_TEAR_PROPAGATION: 0.22,
  PAPER_TEAR_CURL: 24,
  INTRO_DURATION: 6000,
  OUTRO_DURATION: 5000,
  PORT_PASSAGE_DURATION: 3000,
  RESTART_DURATION: 1400,
  RESTART_OPAQUE_AT: 650,
} as const;

/** Integral of cosine velocity ramps: no discontinuity in position or velocity. */
export function travelProgress(progress: number) {
  const t = Math.max(0, Math.min(1, progress));
  const a = MOTION.SCROLL_ACCELERATION;
  const d = MOTION.SCROLL_DECELERATION;
  const speed = 1 / (1 - (a + d) / 2);
  if (t < a) { const u = t / a; return speed * a * (u - Math.sin(Math.PI * u) / Math.PI) / 2; }
  if (t < 1 - d) return speed * (a / 2 + t - a);
  const u = (t - 1 + d) / d;
  return speed * (a / 2 + 1 - a - d + d * (u + Math.sin(Math.PI * u) / Math.PI) / 2);
}
