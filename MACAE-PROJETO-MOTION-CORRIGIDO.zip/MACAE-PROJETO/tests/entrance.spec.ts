import { test, expect } from '@playwright/test';

test('entrada não mostra estado final antes da animação nem reinicia após a chegada', async ({page}, info) => {
  await page.goto('/'); await page.waitForFunction(()=>window.__exhibition);
  const trajectories=[];
  for(const [from,to] of [[1,2],[2,3],[5,6],[4,5],[3,2]]) {
    const duration=await page.evaluate(({from,to})=>{const e=window.__exhibition!.engine;e.pause(false);e.seek(from);e.go(to);e.pause(true);return e.travelMs;},{from,to});
    const marks=[0,duration*.3,duration*.65,duration*.85,duration-1,duration,duration+250,duration+1200,duration+2000];
    let previous=0;
    const samples=[];
    for(const mark of marks) {
      await page.evaluate(delta=>{const e=window.__exhibition!.engine;e.pause(false);e.tick(delta);e.pause(true);},mark-previous);
      previous=mark;
      await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));
      samples.push(await page.locator('.scene').nth(to).evaluate(el=>({entry:Number(getComputedStyle(el).getPropertyValue('--entry')),opacity:Number(getComputedStyle(el.querySelector('h2')!).opacity),transform:getComputedStyle(el.querySelector('.event-period')!).transform})));
    }
    trajectories.push({from,to,duration,samples});
    expect(samples[0].entry,`entrada ${from} → ${to} preparada antes de aparecer`).toBe(0);
    expect(samples.slice(1,5).some(s=>s.entry>0&&s.entry<1)).toBe(true);
    for(let i=1;i<samples.length;i++) expect(samples[i].entry,`entrada ${from} → ${to}, quadro ${i}`).toBeGreaterThanOrEqual(samples[i-1].entry);
    for(const sample of samples.slice(5)) expect(sample.entry).toBe(1);
    expect(samples[5].transform).toBe(samples.at(-1)!.transform);
  }
  await info.attach('entradas.json',{body:JSON.stringify(trajectories,null,2),contentType:'application/json'});
});

test('voltar à abertura não reinicia a revelação depois do scroll', async ({page})=>{
  await page.goto('/');await page.waitForFunction(()=>window.__exhibition);
  await page.evaluate(()=>{const e=window.__exhibition!.engine;e.pause(false);e.seek(1);e.go(0);e.tick(e.travelMs);e.pause(true);});
  await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));
  const title=page.locator('.intro');
  expect(await title.evaluate(e=>Number(getComputedStyle(e).getPropertyValue('--title-reveal')))).toBe(1);
  await page.evaluate(()=>{const e=window.__exhibition!.engine;e.pause(false);e.tick(100);e.pause(true);});
  await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));
  expect(await title.evaluate(e=>Number(getComputedStyle(e).getPropertyValue('--title-reveal')))).toBe(1);
});
